
import java.util.*;

class practise
{
 public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);

  
  int a[][]=new int[3][3];
  
  int i=a.length;
   int j=a[0].length;

 int size=i*j;
for(i=0;i<a.length;i++)
{
  for(j=0;j<a.length;j++)

  a[i][j]=ob.nextInt();
  }

for(i=0;i<a.length;i++)
{
   for(j=0;j<a.length;j++)
{
   
  System.out.print(a[i][j]+" ");
  }
System.out.println();

} int small=a[1][1];
for(i=0;i<a.length;i++)
{

   for(j=0;j<a.length;j++)

   if(small>a[i][j])
    small=a[i][j];
    
  
  }




System.out.println(" it is sparce matrix"+small);


  
 
   


}
}