import java.util.*;
class rotating
{
  Scanner ob=new Scanner(System.in);

  public void result() {

    
   int a[]={1,2,3,4,5};
  
    int i,j;
    System.out.println("elements in array");
     for(i=0;i<a.length;i++)
   {
     System.out.print(a[i]+" ");

        }

    
   System.out.println("enter number of rotaion");
   int n=ob.nextInt();
 for(i=0;i<n;i++)
{
   int first=a[0];
   for(j=0;j<a.length-1;j++)
  {
          
    a[j]=a[j+1];

    }
      a[a.length-1]=first;}
   System.out.println("clockwise rotation");

  for(i=0;i<a.length;i++)
{
   System.out.print(a[i]+" ");
    }

}

   
	public static void main(String ars[])
	{
		rotating ob=new rotating();
		ob.result();
	}
}
	