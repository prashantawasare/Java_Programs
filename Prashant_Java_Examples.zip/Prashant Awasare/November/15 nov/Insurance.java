import java.util.*;

   class Insurance
   {

     
      public static void main(String args[])

  {


      Scanner x=new Scanner(System.in);

      char ms,gen;
      int age;

      System.out.println("enter marital status for married M or u unmarried");

      ms=x.next().charAt(0);

     if (ms=='m')

  {

     System.out.println("! Congrtulation Driver get insurance");}
   

     else
      {

                   System.out.println("enter gender Male M Female F");

                   gen=x.next().charAt(0);

                   System.out.println("enter age of driver");
                   age=x.nextInt();

           if (gen=='M')
           {

                if (age>32)
  

                   System.out.println("! Congrtulation Driver get insurance");
               else

                System.out.println("! Congrtulation Driver cannot get insurance");
            }
     

       if (gen=='F')
           {

                if (age>26)
  

                   System.out.println("! Congrtulation Driver get insurance");
               else

                System.out.println("! Congrtulation Driver cannot get insurance");
            }
}


}


}
     
     