import java.util.*;

class Else if

  
{

   public static void main(String args[])
{
   Scanner ob=new Scanner(System.in);

    int a=ob.nextInt;
    int b=ob.nextInt;
    int c=ob.nextInt;
 

   if (a>b)
{
   Else if(a<b)
    System.out.println("greatest no a");}
   if (b>c)

{

   Else if(b<c)
System.out.println("greatest no c");}

   




















}
}