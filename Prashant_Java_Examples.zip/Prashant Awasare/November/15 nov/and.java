import java.util.*;

   class and

   {

     public static void main(String[] args)

 {


     Scanner ob=new Scanner(System.in);

     int a=ob.nextInt();
     int b=ob.nextInt();
     int c=ob.nextInt();

    if (a<b  &&  a<c)

     System.out.println("enter lowest number a");

    if (b<a  &&  b<c)

     System.out.println("enter lowest number b");
    if (c<a  &&  c<a)

     System.out.println("enter lowest number c");

}

}
    
    
    