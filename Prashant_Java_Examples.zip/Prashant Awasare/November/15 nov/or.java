import java.util.*;

  class or

 {

   public static void main(String args[])

{

    Scanner ob=new Scanner(System.in);

    

     System.out.println("enter a character");

     char ch=ob.next().charAt(0);

    
     

   if (ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')

    System.out.println("vowel");

  else
   System.out.println("consonent");

}

}
  
     
     