import java.util.*;
 
 class insurance
   

 {


       public static void main(String args[])
    
    {
           Scanner x = new Scanner(System.in);

        
    char ms, gen;
            int age;
System.out.println("Enter Marital Status for Married m or u Unmarried");
    
   ms=x.next().charAt(0);
    
        if(ms=='m')
        System.out.println("! Congratulation Driver get Insurance"); 
           else
             {

                System.out.println(" Enter Gender Male  M  Felae F");
                  gen=x.next().charAt(0);
                System.out.println(" Enter age for Driver");
                  age=x.nextInt();

                   if( gen=='M')
                     {

                         if(age>32)
         System.out.println("! Congratulation Driver get Insurance");
         else 
      System.out.println("Driver cannot get Insurance");
                     }

               if( gen=='F')
                     {

                         if(age>26)
         System.out.println("! Congratulation Driver get Insurance");
         else 
      System.out.println("Driver cannot get Insurance");
                     }



             }  //else



       }// main


  }//class