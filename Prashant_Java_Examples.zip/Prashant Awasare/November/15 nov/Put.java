import java.util.*;
  class Put

  {

   public static void main(String args[])

   {

     Scanner ob=new Scanner(System.in);

     int a,b,c,d,e;

     System.out.println("enter value of a");
     a=ob.nextInt();
     System.out.println("enter value of b");
     b=ob.nextInt();
     System.out.println("enter value of c");
     c=ob.nextInt();
     System.out.println("enter value of d");
     d=ob.nextInt();
     System.out.println("enter value of e");
     e=ob.nextInt();
     

   if (a>b)
   if (a>c)
   if (a>d)
   if (a>e)
   

       System.out.println("a is greater");


   if (b>c)
   if(b>d)
   if (b>e)
   if (b>a)


 System.out.println("b is greater");

     if (c>b)
      if (c>a)
     if  (c>d)
     if (c>e)
       
     
    
 System.out.println("c is greater");

    if (d>e)
    if (d>c)
    if (d>a)
    if (d>b)
    
    
 System.out.println("d is greater");
  if (e>a)
  if (e>b)
  if (e>c)
  if (e>d)
   
   
 System.out.println("e is greater");

}
}
