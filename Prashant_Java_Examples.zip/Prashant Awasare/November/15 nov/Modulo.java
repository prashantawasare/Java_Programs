import java.util.*;



     class Modulo

    {


     public static void main(String args[])

  {   Scanner ob=new Scanner(System.in);

     double n;

     System.out.println("enter value of n");

      n=ob.nextDouble();

      if (n%2==0)

      
        System.out.println("number is even ");


     else

     System.out.println("number is odd");

     }

} 
          
              









