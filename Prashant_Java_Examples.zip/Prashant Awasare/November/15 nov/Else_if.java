import java.util.*;

class If
  {

     public static void main(String ree[])

{

   Scanner ob=new Scanner(System.in);

   int a=ob.nextInt();
   
   int b=ob.nextInt();
  
   int c=ob.nextInt();
   int d=ob.nextInt();
   int e=ob.nextInt();

  if (a>b)

   {

      
     System.out.println(" greater number is a");}

   if (b>c)
  {
     
    System.out.println(" greater number is b");}
  
   if (c>a)
{
    System.out.println("greater number is c");}

    if (d>a)
{  
    System.out.println(" greater number is d");}

  if (e>a)
  {

    
     System.out.println(" greater number is e");}
 
}
}