import java.util.*;

   class bonus_amount
{
   public static void main(String[] argd)
{

    Scanner ob=new Scanner(System.in);

    int
    year,salary;

    System.out.println("how many year of service complete");


    year=ob.nextInt();
    if (year>6)

   { System.out.println("enter a salary of person");

    salary=ob.nextInt();
    Double bonus=0.05*salary;
    

    

        
          
          

           System.out.println("person get bonus"+bonus);

         }
     else  

         
{

         System.out.println("person cannot get bonus");

     }
}

}
     
       






      
    

     

     
     








