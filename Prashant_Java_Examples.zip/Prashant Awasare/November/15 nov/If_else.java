import java.util.Scanner;

  class If_else

  {


    public static void main(String []args)

  {

     Scanner ob=new Scanner(System.in);

     int a=ob.nextInt();
     int b=ob.nextInt();

    if (a>b)
{
   


      
      System.out.println("a is greater");}

     

      else
     System.out.println("b is greater");
  

}
         
}     