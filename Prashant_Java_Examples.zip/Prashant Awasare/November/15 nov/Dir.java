import java.util.*;
  class Dir

  {

     public static void main(String args[])

  {

     Scanner ob=new Scanner(System.in);

      int
      a;

     System.out.println("enter value of a");
     a=ob.nextInt();


  
   
     


    if (a>0)

  System.out.println(" no is positive ");

  else
  System.out.println("no is negative");

}
}