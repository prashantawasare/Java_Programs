import java.util.Scanner;
class alphanumeric
{

   public static void main(String args[])

{

    Scanner ob=new Scanner(System.in);
     
   System.out.println("enter a character");
   char b=ob.next().charAt(0);

   if (b>=65 && b<=95||b>=97 && b<122)
    System.out.println("it is alphabet");
   else if(b>=48 && b<57)

   System.out.println("it is a number");

   else 
   System.out.println("it is symbol");

}

}
   