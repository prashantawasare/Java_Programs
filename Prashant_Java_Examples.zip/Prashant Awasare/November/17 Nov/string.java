import java.util.Scanner;

class string_
{

     public static void main(String[]args)
{

    Scanner ob=new Scanner(System.in);

     string day;
     System.out.println("enter a day");
        day=ob.nextLine();

          

         switch(day)
    {      
        case(1):
        System.out.println("one");
        default:
        System.out.println("two");
}

}
}

   