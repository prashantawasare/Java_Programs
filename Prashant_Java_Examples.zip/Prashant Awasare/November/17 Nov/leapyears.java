import java.util.Scanner;
   class leapyears

  {

     public static void main(String args[])

{
   Scanner ob=new Scanner(System.in);

    System.out.println("enter a year");
    int year=ob.nextInt();


   if (year%4==0)
  {

   
      
       System.out.println("it is leap year");

    }

   else
    System.out.println("it is not leap year");
}
}