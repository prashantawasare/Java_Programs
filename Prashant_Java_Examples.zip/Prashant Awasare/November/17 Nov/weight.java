import java.util.*;

 class Weight

{

   public static void main(String arfs[])

  {

     Scanner ob=new Scanner(System.in);

    int wt=ob.nextInt();

    if (wt<115)

              System.out.println("Flyweight");

    else if(wt>115  && wt<121)
   System.out.println("Bantamweight");

    else if (wt>122 &&   wt<153)
     System.out.println("Featherweight");
    else if (wt>154 &&  wt<189)
    System.out.println("Middleweight");

   else if  (wt>=190)
    System.out.println("Heavyweight");

   else
   System.out.println("invalid");
}
}
     
