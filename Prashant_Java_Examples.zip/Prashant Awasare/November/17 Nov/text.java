import java.util.Scanner;

class integer
 {

  

      public static void main(String args[])

{

   Scanner ob=new Scanner(System.in);

   
   System.out.println("enter a number");
  int number=ob.nextInt();
   
   System.out.println("enter a alphabet");
   char a=ob.next().charAt(0);
   
   
    if (number>=48)
  { System.out.println("it is number");}

    else if (a>=97 && a<=122)
  { System.out.println("it is alphabet");}

  else
   {System.out.println("it is symbol");}

}

}
   
    