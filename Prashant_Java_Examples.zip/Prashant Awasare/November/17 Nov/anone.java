import java.util.*;

class anone
{
   public static void main(String args[])
{

   Scanner ob=new Scanner(System.in);
System.out.println("\n\t\t\tsum\n\t\t\tsub");
System.out.println("enter your choice");
   int n=ob.nextInt();

   if (n==1)

    {int a=ob.nextInt();
    int b=ob.nextInt();
    int sum=a+b;

   System.out.println("sum="+sum);}

  else if(n==2)
    
   { int a=ob.nextInt();
    int b=ob.nextInt();
    int sub=a-b;
System.out.println("sub="+sub);}

else
 {System.out.println("invah");}
}
}