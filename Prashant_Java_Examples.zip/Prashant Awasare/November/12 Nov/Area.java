import java.until.Scanner;
 class Area

   {

     public static void main(String args[])
{
      Scanner ob = new Scanner(System.in);

       double  pi=3.14,area,;
       

        
        

        System.out.print("Enter value of Radius");
        Radius=ob.nextDouble();
        

     
        }

  }
      
        