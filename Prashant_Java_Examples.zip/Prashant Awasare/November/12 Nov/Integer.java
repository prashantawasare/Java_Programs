class Integer
{

   public static void main(String args[])
   {

     int 
     a=34,b=45;
     
     System.out.print("sum="+(a+b));

    }
   }