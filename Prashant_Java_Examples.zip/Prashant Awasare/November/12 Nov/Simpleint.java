class Simpleint
{
   public static void main(String args[])

   {

     double amount,rate,time;
       amount=300;
       rate=10;
       time=5;
     
    System.out.print("amount="+(300)+"\nrate="+(10)+"\ntime="+(5));
    System.out.print("\nsimple interest="+(amount*rate*time/100));


     }
}

