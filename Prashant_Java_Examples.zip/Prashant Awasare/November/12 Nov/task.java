class Int
    {

      public static void main(string args[])
      {
        int
        
        numa=4,numb=3,numbc=5;

         
      System.out.print("value of number="+numa+"value of number"+numb+"value of number"+numbc);
      System.out.print("sum"+(numa+numb+numc));
      }
}