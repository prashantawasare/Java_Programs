class Int
    {

      public static void main(String args[])
      {
        int=a , b, c
        
        a=4,b=3,bc=5;

         
      System.out.print("value of number="+a+"value of number"+b+"value of number"+c);
      System.out.print("sum"+(numa+numb+numc));
      }
}