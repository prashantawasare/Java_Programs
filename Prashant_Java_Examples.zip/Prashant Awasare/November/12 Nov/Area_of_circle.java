import java.util.Scanner;
 class Area_of_circle

   {

     public static void main(String args[])
{
      Scanner ob = new Scanner(System.in);
        double radius=ob.nextDouble(); 
        double pi=ob.nextDouble();
         
        
        
   double Area=pi*radius*radius;
    
            
        

        System.out.println("Area="+(Area));
        
        

     
        }

  }
      
        