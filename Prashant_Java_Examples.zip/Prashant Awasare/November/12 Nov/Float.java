class Float
   {

       public static void main(String args[])


    {
        double
        h=4.4,l=5.6;


      System.out.print("\n\n\t\t\tarea of triangle"+(h*l));

}

}