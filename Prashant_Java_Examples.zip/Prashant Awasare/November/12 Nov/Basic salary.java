class Basic_salary

   {
     public static void main(String args[])
     {
       String name="Prashant";
       Double
       Bs=550000,TA=0.35,DA=0.5,HRA=0.4,GROSS_Sal=TA+DA+HRA;
       
       
       
  System.out.print("\nSalary of Month of Nov");
  
  System.out.print("\n======================");
  
  System.out.print("\nString name="+Prashant);
  
  System.out.print("\nbasicsalary="+BS);
  
  
  System.out.print("\nTA="+TA);
  
  System.out.print("\nDA="+Da);
  
  System.out.print("\nHRA="+HRA);
  
  System.out.print("\nGross_Sal="+(TA+DA+HRA));
  
   }
    }