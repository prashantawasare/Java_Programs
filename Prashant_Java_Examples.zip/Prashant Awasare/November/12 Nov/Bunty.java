class Bunty
{
   public static void main(String args[])

   {

     double 
     a=4, b=5, c=6, d=8;
     System.out.println("sum="+(a+b+c+d));
     System.out.println("Average="+((a+b+c+d)/4));
   }
  }

        