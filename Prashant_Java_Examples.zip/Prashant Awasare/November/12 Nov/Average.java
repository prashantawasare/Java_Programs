class Average
  {

   public static void main(String args[])
   
   {

      double
      a=1,b=5,c=6,d=8;
      System.out.print("numbers="+ (1)+(5)+(6)+(8));
      System.out.print("\nSum="+ (a+b+c+d));
      System.out.print("\nAverage="+(a+b+c+d/4));
    }
 }
     