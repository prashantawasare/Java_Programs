class sum
{
   public static void main(String args[])

   {

     double a,b,c;
     a=4,b=5,c=6,d=8;
     System.out.print("sum="+(a+b+c));
     System.out.print("average="+(a+b+c+)/3);
   }
  }