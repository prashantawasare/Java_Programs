import java.util.Scanner;

class ins

  {

    public static void main(String args[])

   {

     Scanner ob =new Scanner(System.in);

     double Radius,pi;
 
    System.out.print("Enter Radius=");
    Radius=ob.nextDouble();
    System.out.print("Enter pi");
    pi=ob.nextDouble();

     System.out.print("area of circle="+(pi*Radius*Radius));
}

}