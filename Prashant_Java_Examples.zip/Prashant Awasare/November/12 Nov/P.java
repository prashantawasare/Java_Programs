class bunty
  {

     public static void main(String args[])

    {

       System.out.print("\n\n\n\nInformation about me");
       System.out.print("==============================");
       System.out.print("\nNmae\t\t\tPrashant");
       System.out.print("\nroll no\t\t\t324");

}
}