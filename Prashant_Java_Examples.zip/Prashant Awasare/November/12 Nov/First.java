import java.util.Scanner;
class first
  {

    public static void main(String[]args)

   {
     Scanner ob =new Scanner(System.in);

     String Name,City;
      double Sal;
      int id;
         
      
     

     
      System.out.println("Enter Name=");
      Name=ob.nextLine();

      System.out.println("Enter City=");
      City=ob.nextLine();

      System.out.println("Enter Sal=");
      Sal=ob.nextDouble();

      System.out.println("Enter id=");
      id=ob.nextInt();
      
      System.out.print("\n\n\n\t\tEmployee Informtion System");
      System.out.print("\n\t\t=============================");
      System.out.print("\n\t\tName\t\t\tPrashant");
      System.out.print("\n\t\tCity\t\t\tPune");
      System.out.print("\n\t\tSal\t\t\t2300");
      System.out.print("\n\t\tid\t\t\t1324");

   

    }

}
    
      
      
      
      
