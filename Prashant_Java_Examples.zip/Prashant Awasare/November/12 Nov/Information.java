import java.util.Scanner;
class Information
  {

    public static void main(String[]args)

   {
     String Name,Salary,City;
      int id;
         
      
      Scanner ob =new Scanner(System.in);

     
      system.out.println("Enter Name=");
       name=b.nextLIne();

      system.out.println("Enter Salary=");
      salary=b.nextLine();

      system.out.println("Enter City=");
      city=b.nextLine();

      system.out.println("Enter id=");
      id=b.nextInt();

   

    }

}
    
      
      
      
      
