

  
import java.util.*;

class character
{
public static void main(String args[])





{
Scanner x=new Scanner(System.in);


char a;

System.out.println("Enter a character");

a='a';
do


{
   
a=x.next().charAt(0);






}while(a!='z');




}

}