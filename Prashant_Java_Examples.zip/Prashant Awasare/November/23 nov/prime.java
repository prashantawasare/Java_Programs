class prime
{
  public static void main(String args[])
{
  int i=2;
  int n=11;
for(i=2;i<=n;i++)
{
   if(n%i==0)
    break;
     
}
  if(n==i)
System.out.println("prime");
else
System.out.println("not prime");
}
}
