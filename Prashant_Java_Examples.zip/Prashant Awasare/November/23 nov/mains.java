import java.util.*;
class mains
{
public static void main(String args[])
{
   Scanner ob=new Scanner(System.in);
  int a=ob.nextInt();
  int b=ob.nextInt();

  int sum=a+b;

System.out.println("sum="+sum);










}
}