 

//*3: WAP find the factor of a given number even odd factor
  // 10 : 1 2 5 
   //20 :1 2 4 5 10

import java.util.Scanner;

class Factorforeven

{
  public static void main(String []arg)

{
  Scanner sc=new Scanner(System.in);
  
int n=sc.nextInt();
 
 int i=1 ,even=0,odd=0;
  
for(i=1;i<n;i++)
 
 {
   if(n%i==0)

{
    if(i%2==0)
   
   System.out.println(i+"");

}

  }
    
 
  
}

}