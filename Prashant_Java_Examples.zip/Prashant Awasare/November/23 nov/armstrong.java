import java.util.*;
class inputting_armstrongs
{
   public static void main(String args[])
{

   
  
      int i=1,n=122;
      i=n;int c=0;
   while(i!=0)
{
   i=i/10;
   c++;
    }int sum=0;i=n;int rem;
  while(i!=0)
{
   rem=i%10;
   sum=sum+(int)Math.pow(rem,c);
 i=i/10;  }
 if(n==sum)
 System.out.println("armstronng");
 else
  System.out.println("not armstrong");
      }

}     
    
  
 