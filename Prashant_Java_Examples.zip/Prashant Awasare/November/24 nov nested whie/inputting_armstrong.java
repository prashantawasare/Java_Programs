import java.util.*;
class inputting_armstrong
{
   public static void main(String args[])
{

   Scanner ob=new Scanner(System.in);

   System.out.println("enter a number");
   int n=ob.nextInt();
   
  
 
    
  
 int  i=n,c=0,rem;
while(i!=0)
{
  i=i/10;
  c++;
  
}
   
   

   i=n;
 int sum=0;
while(i!=0)
{  
  rem=i%10;
  sum=sum+(int)Math.pow(rem,c);
   i=i/10;
}
   if(n==sum)
   
   System.out.println(" it is armstrong");
else
System.out.println("it is not armstrong");
}
}