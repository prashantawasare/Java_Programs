import java.util.Scanner;
class main
{
  public static void main(String args[])
{ Scanner sc=new Scanner(System.in);
  System.out.println("enetr no");
  int n=sc.nextInt();
  int i=1;
  int c=0;
   int sum=0;
  
 while(i<=n)
  {   
     if(i%2==0)
      
      c++;
 
 
   System.out.print(i+" ");
i++; 

      sum=sum+i;
     
     
   
     
  } 
   System.out.println("\ncount="+c);
   System.out.println("sum="+sum);
   
 


}
}
