class nested_for_star
{
 public static void main(String args[])
{
  int row,col;
    
   
 for(row=1;row<=4;row++)
{

  
  
  for(col=1;col<=5;col++)
  {  
      System.out.print( "* ");

      
}
   
  System.out.println();
 


} 

}

}