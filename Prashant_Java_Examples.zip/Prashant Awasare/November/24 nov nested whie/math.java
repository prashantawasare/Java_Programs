class math
{

  public static void main(String args[])
{
  int i=1,n=20,t=2;
  
  
while(i<=n)
{


   System.out.println(i+"  "+(int)Math.pow(i,t));
   i++;
}
}
}
