class nested_while_
{
 public static void main(String args[])
{
  int row,col;
    
   row=1;
while(row<=3);
{

  
  col=1;
 while(row<=3)

  
  {  
      System.out.print(col+ " ");
      col++;
      
} System.out.println();
row++;
   
 
 


} 

}

}