class nested_while_table
{
 public static void main(String args[])
{
  int row,col;
    
   row=1;
while(row<=10)
{

  
  col=1;
 while(col<=10)

  
  {  
      System.out.print(row*col+ " \t");
      col++;
      
   }
     System.out.println();
     row++;
   
 
 


     } 

  }

}