class pub
{
public static void main(String args[])
{
  int i=1,c=0,sum=0;
  while(i<=100)
{
   if(i%2!=0)
     c++;
    
  System.out.print(i+" ");
   i++;
   sum=sum+i;
}System.out.print("even="+c);
 System.out.print("sum"+sum);
}
}