import java.util.Scanner;
class error
{

   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);

  int i=ob.nextInt();

  

   while(i!=0)

  {

     int rem=i%10;
     int sum=0;
    System.out.print(rem+" ");
     sum=sum+rem;
     i=i/10;
}System.out.println(sum);

}

}