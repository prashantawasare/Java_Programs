
class co
{

   public static void main(String args[])
{

  

   int i=1234;
   int sum=0;
   int c=0;
   int odd=0;
   while(i!=0)

     {   int rem=i%10;
          System.out.println(rem+" ");

          if(rem%2==0)
            c++;
          else
          odd++;
           sum=sum+rem;
           
           
           i=i/10;
           }
     
  System.out.println("the count of even numbers="+c);
  System.out.println("the sum of numbers="+sum);
  System.out.println("the count of odd numbers="+odd);
}

}



