class square
{
 public static void main(String args[])
{

  int i=-12345,square=0,rem;
   
  while(i!=0)

{   if(i>=0)

     System.out.println("not possible");

   else

{     while(i!=0) 

   {  rem=i%10;

    
  

    square=rem*rem;
     i=i/10;
    System.out.println(rem+" "+square);  
   
}
}
}
}

}