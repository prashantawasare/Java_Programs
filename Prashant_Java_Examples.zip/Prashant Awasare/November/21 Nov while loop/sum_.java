import java.util.Scanner;
class sum_
{

   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);

  int i=ob.nextInt();
  int d=0,odd=0,sum=0,l=0,e=0;
  

   while(i!=0)

  {

     int rem=i%10;

    System.out.print(rem+" ");

     i=i/10;
    
   if(rem%2==0)
   d++;
   else
   odd++;
   sum=sum+rem;
   l=l+d;
   e=e+odd;
   
}

   System.out.println("even numbers="+d+" "+l);
   System.out.println("odd numbers="+odd+" "+e);
   System.out.println("total sum="+sum);
   
}

}