class primeseries_s
{
   public static void main(String args[])
{
   
    int i=1;
    int n=150;
    

  for(i=1;i<=n;i++)
  {

         int j;
        
          


   for(j=2;j!=0;j++)

    {    
        if(i%j==0)
        break;



        

      }
      
        
        if(i==j)
        {    System.out.print(i+" ");
            }










          } 
           
       }
   
   }











     