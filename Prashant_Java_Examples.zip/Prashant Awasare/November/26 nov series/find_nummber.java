class find_nummber
{
  public static void main(String ars[])
{
   int i=12345;
   int n=i;
   int rem,r=0,k=5;

while(i!=0)
{
   rem=i%10;
   if(rem==k)
{
   r=5;
   break;
          }
i=i/10;
}
if(r==5)
System.out.println("number found");
else
System.out.println("number not found");
     }
  }


