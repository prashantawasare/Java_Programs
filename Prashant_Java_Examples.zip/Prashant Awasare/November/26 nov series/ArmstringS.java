//armstrong series
import java.util.Scanner;
class ArmstringS
{
  public static void main(String args[])
  {
   Scanner sc=new Scanner(System.in);
   System.out.println("enter start");
   int a=sc.nextInt();
    System.out.println("enter end");
   int b=sc.nextInt();
   while(a<=b)
   {
     int t=a,c=0;
     while(t!=0)
    {
      t=t/10;
      c++;
    }
    t=a;
    int r,sum=0;
    while(t!=0)
    {
      r=t%10;
      sum=sum+(int)Math.pow(r,c);
      t=t/10;
    }
    if(sum==a)
       System.out.print(a+" ");

    a++;
    }
  }
}
