class ternary
{
 public static void  main(String args[])
{
   int a=7,b=6;

    int c=(a>b)?a+b:a-b;
    System.out.println(c);
}
}