class table_
{

   public static void main(String args[])
{

    int row=5;
for(row=5;row>=1;row--)
{
     int col=1;
    for(col=1;col<=row;col++)


  { System.out.print(col+" ");
   }

  System.out.println();
   
         }
for(row=5;row>=1;row--)
{
         int col;
    for(col=1;col<=row;col++)


  { System.out.print(col+" ");
   }

  System.out.println();
   
         }
  
 row=1;
for(row=1;row<=5;row++)
{
     int col=1;
    for(col=1;col<=row;col++)


  { System.out.print(col+" ");
   }

  System.out.println();


}

for(row=4;row>=1;row--)
{
         int col;
    for(col=1;col<=row;col++)


  { System.out.print(col+" ");
   }

  System.out.println();
   
         }













    }
}
