class polindromeseries_
{
   public static void main(String args[])
{
   
    int i=1;
    int n=150;
    

  do
  {

         int j=i;
          int rev=0;


   do

    {

        int rem=j%10;
         rev=rev*10+rem;
         j=j/10;
      }while(j!=0);
        
        if(rev==i)
        {    System.out.println(i+" ");
            }i++;










          } while(i<=n);
           
       }
   
   }











     