class primeseries
{

  public static void main(String args[])
{

     int i=1,n=100,c=0,j;
          

for(i=1;i<=n;i++)

{
     j=2;
    
  
    {

        for(c=0;j<i;j++)
        {   if(i%j==0)

             c++;
             break;
      }  
        
}
   
  if(c==0 && i!=1)
   {
      System.out.println(i);}




   
}


}

 }    

