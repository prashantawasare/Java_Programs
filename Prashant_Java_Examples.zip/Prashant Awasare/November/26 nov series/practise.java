class practise
{
  public static void main(String ss[])
{
  int row,col;
row=1;
while(row<=5)
{
  col=1;
  while(col<=6)
{  
    System.out.print(" * ");
    col++;
}row++;
System.out.println();
  }
  }
}
 