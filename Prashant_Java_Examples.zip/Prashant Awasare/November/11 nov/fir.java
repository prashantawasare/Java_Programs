class fir
{
  
 public static void main(String args[])

 {

    System.out.print("\n\n\ninformation about me");
    System.out.print("\n==========================");
    System.out.print("\nname\t\t\t\t\t\prashant");
    System.out.print("\nroll no\t\t\t\t6546");
    System.out.print("\nbatch name\t\t\t\tnovember");
    System.out.print("\nclass name\t\t\t\tcodenera");
    System.out.print("\nvillage name\t\t\t\tawasarenagar");
   }
}