class int


 {

  public static void main(String args[])

{
           
      int num1=23;
System.out.print("value of number ="+num1);


  
}

}