class Nov_Bat
{
    public static void main(String args[])
    
    {
     
     System.out.println("\n\n\n\t\tEmployee Information");
     
     System.out.println("\n\t\t=========================");

     
     System.out.println("\n\t\tName\t\t\t\tPrashant");

     
     System.out.println("\n\t\tCity\t\t\t\tPune");

     
     System.out.println("\n\t\tSalary\t\t\t\t65474");
     
     System.out.println("n\t\tName\t\t\t\t65268");
       
}
}