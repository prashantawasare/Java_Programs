class area
 {


    public static void main(String args[])
    {

       radius=6.5
       pie=3.14
  System.out.print("area of circle"+area")
    }
  }


     
     
     
    