class Addition
{
    public static void main(String args[])
    {

       int a=25, b=69;
       System.out.println("\n\tSum="+a+b);
       System.out.println("\n\tSum="+(a+b));
       System.out.println("\n\tSub="+(a-b));
       System.out.println("\n\tmul="+(a*b));
     }
   }