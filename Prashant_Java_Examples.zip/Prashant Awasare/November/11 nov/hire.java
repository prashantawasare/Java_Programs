class gt
{
 public static void main(String k[])

 {


     int
     num1=23,num2=34,num3=45;
     
     System.out.print("value of number="+ num1+"value of number="+ num2+"value of number"+ num3);
}
}