class hir
 {

   public static void main(String []k)
   {

      

      System.out.println("\n\n\n\t\t\t*");
       
      System.out.println("\t\t*\t\t*");
      System.out.println("\t*\t\t\t\t*");
      System.out.println("\t\t*\t\t*");
     System.out.println("\t\t\t*");


}
}