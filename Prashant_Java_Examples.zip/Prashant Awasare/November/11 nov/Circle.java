class Circle
{
  public static void main(String args[])
    {
      
      double r=9,area,pie=3.14;

 //System.out.println("value of radius"+r)
   area=pie*r*r;
  
  System.out.println("area of circle"+area);
   }
  }