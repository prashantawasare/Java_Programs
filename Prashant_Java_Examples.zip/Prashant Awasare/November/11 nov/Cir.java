class fire
{
  public static void main(String args[])
  {
    System.out.print("\n\n\n\nemployee infomation")
    System.out.print("\n=======================")
    System.out.print("\nname\t\t\t\tprashant")
    System.out.print("\nroll no\t\t\t5365")
    System.out.print("\nclass name\t\t\tcodenra")
    System.out.print("\nbatch name\t\t\tnovember")
    System.out.print("\nteammates\t\t\t43")
   }


}