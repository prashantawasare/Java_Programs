class Float_variable
{
   public static void main(String args[])
    { 
       
      float num1,num2,num3,sum;

       

        num1=5.8f;
        num2=3.6f;
        num3=6.9f;
        sum=num1+num2+num3;
     System.out.println("Value of num1"+num1+" "+
                        "Value of num2"+num2+" "+
                        "value of num3"+num3);
         System.out.println(" Sum of no"+sum);
        }
    
   }
     
     
   
