



class tr

{
	public static void main(String[] args)
 {
		

      int i=1,c=3;
		
	
	while(i<=10)
	   
  {
	         
	        
       System.out.println(" "+i*c);
	
        i++;
	        ;
	     }





	}


}