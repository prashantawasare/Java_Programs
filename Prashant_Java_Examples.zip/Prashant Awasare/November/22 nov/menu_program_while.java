import java.util.*;
class menu_program_while
{

    public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);

    System.out.println("1.Addition");
    
    System.out.println("2.Subtraction");
    
    System.out.println("3.Multiplication");
   
    System.out.println("4.Division");                                         
    int l=ob.nextInt();
    
    
    
 int i=1;
while(i!=0)
{   System.out.println("enter your choice");
    int l=ob.nextInt();
     i=ob.nextInt():
  switch(l)
 {   
   case 1:
   System.out.println("your choice is addition"+" "+sum);
   int s=ob.nextInt();
   break;
   case 2:
   System.out.println("your choice is subtraction"+" "+sub);
   int r=ob.nextInt();
   break;
   case 3:
   System.out.println("your choice is multiplication"+" "+mul);
   int m=ob.nextInt();
   break;
   case 4:
   System.out.println("your choice is division"+" "+div);
   int d=ob.nextInt();
   break;

  default:
   
   System.out.println("your choice is wrong");
   break;


}
  System.out.println("press 0 to terminates");
   }
}
   
