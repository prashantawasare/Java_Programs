class mai
{
 public static void main(String args[])
{
   int a=23,b=++a + --a + ++a + --a;
System.out.println(a);
System.out.println(b);
}

}