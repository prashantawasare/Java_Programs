import java.util.Scanner;
class terminates_
{
  public static void main(String args[])
{

  Scanner ob=new Scanner(System.in);
    char i;
System.out.println("enter a character");
 
    i=1;
     
while(i!='z')

  {   i=ob.next().charAt(0);
      
      
       
     
     
}

}
 }    
    
     