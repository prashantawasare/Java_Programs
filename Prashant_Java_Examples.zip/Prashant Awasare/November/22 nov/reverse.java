class reverse
{
 public static void main(String args[])
{

  int i=12345,rev=0,rem;
   
  while(i!=0)

{   if(i<=0)

     System.out.println("not possible");

   else

{     while(i!=0) 

   {  rem=i%10;

    rev=rev*10+rem;
  

    
     i=i/10;
    
      
   
}
}
}

    System.out.println(rev);
}

}