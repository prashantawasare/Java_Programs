import java.util.Scanner;
class do_while_break
{

   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);

  int i=ob.nextInt();

  

   do

  {

     int rem=i%10;

    System.out.print(rem+" ");

     i=i/10;
}while(i!=0)

}

}