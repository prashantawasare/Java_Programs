 class traingles_

   {


        public static void main(String args[])
        {


          int row , col;

               for( row=1; row<=6; row++)
                 {

                      
                           for(col=row; col<=6; col++)
                            System.out.print("  ");

                            for(col=1; col<=row; col++)
                            System.out.print(col+" ");
                      

                            

              System.out.println();
              }
     




        }


 }

