class aplphabetic_pattern3
{
   public static void main(String args[])
{

    int row,col;
  for(row=65;row<=70;row++)
 {
    for(col=65;col<=row;col++)
     System.out.print((char)row+" ");
   

     System.out.println();
    }


  }
}
