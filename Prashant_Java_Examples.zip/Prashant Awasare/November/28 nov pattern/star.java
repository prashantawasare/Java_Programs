class star
{
   public static void  main(String ars[])
{
  int row,col;

for(row=1;row<=5;row++)

{
   for(col=row;col<=5;col++)
System.out.print(" ");

   for(col=1;col<=5;col++)
System.out.print("*");


  System.out.println();

         }


    }

}