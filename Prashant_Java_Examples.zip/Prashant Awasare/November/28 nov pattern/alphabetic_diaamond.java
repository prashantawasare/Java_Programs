class alphabetic_diaamond

   {


        public static void main(String args[])
        {


          int row , col;
               int a=65;
               
                for( row=0; row<=6; row++)
                 {

                      
                           for(col=row; col<=6; col++)
                            System.out.print("  ");

                            for(col=0; col<=row; col++)
                            System.out.print((char)(col+a)+" ");
                      for(col=1;col<row;col++)
                      System.out.print((char)(col+a)+" ");
                     
                        System.out.println();
                       
                            }

              for( row=5; row>=0; row--)
                 {

                      
                           for(col=row; col<=6; col++)
                            System.out.print("  ");

                            for(col=0; col<=row; col++)
                            System.out.print((char)(col+a)+" ");
                      for(col=1;col<row;col++)
                      System.out.print((char)(col+a)+" ");

                    
              System.out.println();
                 }
     




        }


 }
