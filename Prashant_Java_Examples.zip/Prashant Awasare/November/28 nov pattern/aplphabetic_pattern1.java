class aplphabetic_pattern1
{
   public static void main(String args[])
{

    int row,col;
  for(row=65;row<=69;row++)
 {
    for(col=65;col<=row;col++)
     System.out.print((char)col+" ");
   

     System.out.println();
    }


  }
}
