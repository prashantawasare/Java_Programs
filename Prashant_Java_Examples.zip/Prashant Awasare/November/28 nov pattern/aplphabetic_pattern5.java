class aplphabetic_pattern5
{
   public static void main(String args[])
{

    int row,col;
  for(row=71;row>=65;row--)
 {
    for(col=row;col>=65;col--)
     System.out.print((char)col+" ");
   

     System.out.println();
    }
   
  for(row=65;row<=71;row++)
 {
    for(col=65;col<=row;col++)
     System.out.print((char)col+" ");
   

     System.out.println();
    }


  }
}