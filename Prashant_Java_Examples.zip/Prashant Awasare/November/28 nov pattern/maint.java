class maint

{
  public static void main(String args[])
{
   int i=1;
   int n=2000;
while(i<=n)

{

    int j=i,c=0;
    while(j!=0)
 {
    

      j=j/10;
      c++;
    }
      j=i;
    int sum=0,rem;
   while(j!=0)
  {
    rem=j%10;
    sum=sum+(int)Math.pow(rem,c);
   j=j/10;



}
  

   if(sum==i)
System.out.print(i+" ");
i++;

}

}
}