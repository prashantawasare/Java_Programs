class aplphabetic_pattern2
{
   public static void main(String args[])
{

    int row,col;
  for(row=71;row>=65;row++)
 {
    for(col=65;col<=row;col++)
     System.out.print((char)col+" ");
   

     System.out.println();
    }


  }
}
