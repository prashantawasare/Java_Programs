import java.util.Scanner;
class pou
  {

    public static void main(String arf[])

 {    Scanner ob=new Scanner(System.in);

int numa=23,numb=34;

   System.out.println("numbers="+(numa)+(numb));

  

}

}
