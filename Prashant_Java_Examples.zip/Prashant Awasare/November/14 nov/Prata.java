import java.util.*;
class Prata
  {


    public static void main(String args[])
    {
       Scanner ob=new Scanner(System.in);
        
         
 
          
   
     
       System.out.println("enter three numbers=");
       Int=ob.nextInt();

      if (a>b)
     
      
        if (a>c)

   System.out.println("enter a greater number=");


    if (b>c){
   if  (b>a)


   System.out.println("enter a greter number=");

    


   if (c>a)

  if (c>b)


    System.out.println("enter a greter number=");

        }
}







            
          
            
       
      

      
  

         

        
   }

 }
       