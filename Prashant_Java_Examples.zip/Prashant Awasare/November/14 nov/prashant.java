import java.util.Scanner;

 class prashant

{

    public static void main(String asd[])

  {
       Scanner ob=new Scanner(System.in);

      String name,city;

      int salary;
      double id;

      System.out.println("enter a name=");
      name=ob.nextLine();
      System.out.println("enter a city=");
      city=ob.nextLine();
      System.out.println("enter a salary=");
      salary=ob.nextInt();
      System.out.println("enter a id=");
      id=ob.nextDouble();

       System.out.println("\n\n\n\t\tEmployee Information");
       System.out.println("\n\t========================");
       System.out.println("\n\t\tname\t\t\t="+((name))+"\n\t\tcity\t\t\t="+((city))+"\n\t\tsalary\t\t\t="+((salary))+"\n\t\tid\t\t\t="
+(id));

    }

} 