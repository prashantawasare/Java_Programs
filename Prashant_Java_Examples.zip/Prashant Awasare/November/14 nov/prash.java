import java.util.Scanner;
 class prash

   {

     public static void main(String args[])

     { Scanner ob = new Scanner(System.in);

       double  pi=3.14,area,;
       

        
        

        System.out.print("Enter value of Radius");
        double a=sc.nextDouble();
        

     
        }

  }
      
        