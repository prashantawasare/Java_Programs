class Poi
{

  public static void main(String rsf[])
  {

     
  int numa=54,numb=23;

   System.out.print("numbers="+(numa));
   System.out.print(" "+(numb));
}

}