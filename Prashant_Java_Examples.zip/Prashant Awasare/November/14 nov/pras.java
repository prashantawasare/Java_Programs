import java.until.Scanner;
 class pras

   {

     public static void main(String args[])
{
      Scanner ob = new Scanner(System.in);

       double  pi=3.14,area,radius;
       

        
        

        System.out.print("Enter value of Radius");
        Double r=sc.nextDouble();
        

     
        }

  }
      
        