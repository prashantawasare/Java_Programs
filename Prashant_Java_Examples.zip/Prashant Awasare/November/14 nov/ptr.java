import java.util.Scanner;
   class ptr
   {public static void main(String afs[])
     
      {

         Scanner ob=new Scanner(System.in);
       
       double pi=3.14,radius,area=pi*radius*radius;

     System.out.print("Enter a radius");
      radius=ob.nextDouble();
     
     System.out.println("area of circle="+(area));
}

}

     