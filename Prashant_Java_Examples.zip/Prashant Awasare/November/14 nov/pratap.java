import java.util.Scanner;

class pratap

    {

      public static void main(String args[])

    {

       Scanner sc=new Scanner(System.in);

       int
     number;

      System.out.print("enter a number ");
      int n=sc.nextInt();    
      System.out.print("enter a number");
      int b=sc.nextInt();
  }
 }