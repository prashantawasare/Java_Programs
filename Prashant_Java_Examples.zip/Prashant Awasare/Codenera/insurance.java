/*  
  Q: Ola Cab wants driver insurance.
      Driver is married then insurance will be cover.
     If driver  is unmarried , male and age >32 then insurance will cover.
     If dirver is unmarried , female and age >26 the insurance will cover.
     Otherwise take third party Insurance.
=====================================================
Scanner x= new Scanner(System.in);
char ch =x.next().charAt(0);
======================================================
  
  
     Driver is married : Insurance will be given.
     Driver Unmarried : Ask Age,gen then check cond

*/

import java.util.*;
  class insurance
    {


       public static void main(String args[])
        {
           Scanner x = new Scanner(System.in);

            char ms, gen;
            int age;
System.out.println("Enter Marital Status for Married m or u Unmarried");
       ms=x.next().charAt(0);
    
        if(ms=='m')
        System.out.println("! Congratulation Driver get Insurance"); 
           else
             {

                System.out.println(" Enter Gender Male  M  Felae F");
                  gen=x.next().charAt(0);
                System.out.println(" Enter age for Driver");
                  age=x.nextInt();

                   if( gen=='M')
                     {

                         if(age>32)
         System.out.println("! Congratulation Driver get Insurance");
         else 
      System.out.println("Driver cannot get Insurance");
                     }

               if( gen=='F')
                     {

                         if(age>26)
         System.out.println("! Congratulation Driver get Insurance");
         else 
      System.out.println("Driver cannot get Insurance");
                     }



             }  //else



       }// main


  }//class


Wap enter a no and check it is divisible by 5 or not?

  Modulo:
      n%5 =  gives rem;
      55%5==0
       print(
  11)55(5
     55
     ---
      0  rem


WAP Enter a number check it is even or odd:

   n%2==0   even  or odd


A company decided to give bonus of 5% to employee if his/her year of service is more than 5 years.
Ask user for their salary and year of service and print the net bonus amount
=========================================================
Logical Operators:
==================

 and  &&   
    0, 1(A.B)
      
   A  B  C
   =  =  =
   0  0  0
   0  1  0
   1  0  0
   1  1  1

 Left  &&  Right

  A, B, C;
   if(a>b  && a>c)
          System.out.println("a is gretr");

WAP Enter three number find the smallest among them . Use && logical operator
     


or   ||

      A+B
     
0, 1 (A+B)
      
   A  B  C
   =  =  =
   0  0  0
   0  1  1
   1  0  1
   1  1  1
   
  Left || Right


WAP enter a character check it is vowel or consonent:
char ch =x.next().charAt(0);

     if(ch=='a'||ch=='e'||ch=='i'|| ch=='o'||ch=='u')
         print(" Vowel");
     else 
         print(consonent)

    






not  !



   
   

     

      

 

   
   
      