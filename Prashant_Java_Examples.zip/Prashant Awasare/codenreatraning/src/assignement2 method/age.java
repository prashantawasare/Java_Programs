Q1.Take input of age of 3 people by user and determine oldest and youngest among them

package codenreatraning;
import java.util.*;
public class age {
	
	int a,b,c;
	Scanner ob=new Scanner(System.in);
	
	public void input()
	{
		System.out.println("enter the age of person");
		a=ob.nextInt();
		System.out.println("enter the age of person");
		b=ob.nextInt();
		System.out.println("enter the age of person");
		c=ob.nextInt();
		
	}
	public void result()
	{
		if(a>b && a>c)
		System.out.println("a is oldest");
		if(b>a && b>c)
			System.out.println("b is oldest");
		 if(c<a && c<b)
		System.out.println("c is youngest");
		
	}
	public static void main(String args[])
	{
		age ob=new age();
		ob.input();
		ob.result();
	}
	
	
	
	
	

}
