
//Q5. Take three numbers from the user and print the smallest number

import java.util.*;
public class smallest {
	
	Scanner ob=new Scanner(System.in);
	
	
	
	
public void display()
{
	 
	System.out.println(" enter a number");
	int a=ob.nextInt();
	System.out.println(" enter a second number");
	int b=ob.nextInt();
	System.out.println(" enter third number");
	int c=ob.nextInt();
	
	if(a<b && a<c) {
		System.out.println("a is smallest");
	}
	if(b<c && b<a)
	{System.out.println("b is smallest");
		
	}
	if(c<b && c<a) {
		System.out.println(" c is smallest");
	}
}
	
	public static void main(String args[])
	{
	
		smallest ob=new smallest();
		ob.display();
	}
		
		
	
		
	
	
	
	
	
	



}



