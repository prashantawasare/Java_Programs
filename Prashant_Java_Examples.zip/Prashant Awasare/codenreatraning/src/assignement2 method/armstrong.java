import java.util.Scanner;
public class armstrong {
	
	Scanner ob=new Scanner(System.in);
	public void input(int n)
	{
		System.out.println("enter the number");
		 n=ob.nextInt();
		
	

	
		int j=n;
		int rem,sum=0,c=0;
		while(n!=0) {
			n=n/10;
			c++;
		}j=n;
		while(j!=0)
		{
			
			rem=j%10;
			sum=sum+(int)Math.pow(rem, c);
			j=j/10;
	      }
		if(sum==n)
			System.out.println(" armstrong");
		else
			System.out.println("it is not armstrong");

}
	public static void main(String arfs[])
	{
		armstrong ob=new armstrong();
		ob.input(0);
	}
}


