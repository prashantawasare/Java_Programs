import java.util.*;
public class palindrome {
	
	Scanner ob=new Scanner(System.in);
	public void input(int n)
	{
		System.out.println("enter the number");
		 n=ob.nextInt();
		
	

	
		int j=n;
		int rem,rev=0;
		while(j!=0)
		{
			rem=j%10;
			rev=rev*10+rem;
			j=j/10;
	      }
		if(rev==n)
			System.out.println(" palindrome");
		else
			System.out.println("it is not palindrome");

}
	public static void main(String arfs[])
	{
		palindrome ob=new palindrome();
		ob.input(0);
	}
}