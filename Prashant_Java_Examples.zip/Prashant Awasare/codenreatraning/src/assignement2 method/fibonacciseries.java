//Q9) Write  a program Fibonacci Series in Java
import java.util.*;
public class fibonacciseries {
	
	Scanner ob=new Scanner(System.in);
	
			
	public void display() {
		int a=0,b=1,c;
		System.out.println(a+" ");
		System.out.println(b+" ");
		
		for(int i=1;i<=10;i++)
		{
			c=a+b;
			System.out.println(c+"");
			a=b;
			b=c;
		}
	}
public static void main(String as[]) {
	
	
	fibonacciseries ob=new fibonacciseries();
	ob.display();
}
}
