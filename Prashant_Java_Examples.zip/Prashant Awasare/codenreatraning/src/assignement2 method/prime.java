
//) Wap to check Prime Number Program in Java
import java.util.*;
public class prime {
	
	Scanner ob=new  Scanner(System.in);
	
	 public void display() {
		 
		 System.out.print("enter a number");
		 int n=ob.nextInt();
		 
		   int i;
		 for( i=2;i<=n;i++)
		 {
		    if(n%i==0)
		     break;
		      
		 }
		   if(n==i)
		 System.out.println("prime");
		 else
		 System.out.println("not prime");
		 }
		 
	 
	 public static void main(String hd[]) {
		 
		 prime ob=new prime();
		 ob.display();
		 
	 }

}
