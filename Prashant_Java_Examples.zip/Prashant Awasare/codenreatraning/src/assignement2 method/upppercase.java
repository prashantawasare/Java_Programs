

Q3.Write a program to check whether a entered character is lowercase ( a to z ) or uppercase ( A to Z ).
import java.util.*;
public class upppercase {
	
	Scanner ob=new Scanner(System.in);
	char l;
	public void input() 
	{
		System.out.println("enter  the character");
		l=ob.next().charAt(0);
		
		
	}
	public void result()
	{
		if(l>='a' && l<= 'z')
		System.out.println("this is lowercase chracterer");	
		else if(l>='A' && l<= 'Z')
		System.out.println("this is uppercase character");
	}
	public static void main(String args[])
	{
		upppercase ob=new upppercase();
		ob.input();
		ob.result();
	}
	
	
	

}
