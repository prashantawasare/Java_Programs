

Q4.Write a Java program to get a number from the user and print whether it is positive or negative.

import java.util.Scanner;
public class positivenegative {
	
	 
		int no;
		Scanner ob=new Scanner(System.in);
		
		public void input() 
		{
			System.out.println("enter  the number");
			no=ob.nextInt();
			
			
		}
		public void result()
		{
			if(no>=0)
			System.out.println("this is positive number");	
			else if(no<=0)
			System.out.println("this is negative number");
		}
		public static void main(String args[])
		{
			 positivenegative ob=new  positivenegative();
			ob.input();
			ob.result();
		}
		
		
		

	}



