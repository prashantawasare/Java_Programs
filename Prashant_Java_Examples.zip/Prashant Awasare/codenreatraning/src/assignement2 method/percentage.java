

Q2.A student will not be allowed to sit in exam if his/her attendence is less than 75%.
    Take following input from user
    Number of classes held
    Number of classes attended.
    And print
    percentage of class attended
    Is student is allowed to sit in exam or not.
package codenreatraning.assignments2class_and_object;
import java.util.*;
public class percentage {
	
	
		double percentage, classheld,classatteended;
;
	
	Scanner ob=new Scanner(System.in);
	public void input()
	{
		System.out.println("enter the class held");
		classheld=ob.nextDouble();
		System.out.println("enter the class classatteended");
		classatteended=ob.nextDouble();
		
				
	}
	public void result()
	{
		percentage=(classatteended/classheld)*100;
		System.out.println("percentage="+percentage);
		
		if(percentage>75)
			System.out.println("person is  allowed to sit in the classroom");
		else
			System.out.println("person is not allowed to sit in the classroom");
	}
	public static  void main(String rgs[])
	{
		percentage	ob=new percentage() ;
		ob.input();
		ob.result();
	}
	

}
