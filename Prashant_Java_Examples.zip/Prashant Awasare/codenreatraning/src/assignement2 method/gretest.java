//Q5. Take three numbers from the user and print the greatest number

import java.util.*;
public class gretest {
	
	Scanner ob=new Scanner(System.in);
	
	
	
	
public void display()
{
	 
	System.out.println(" enter a number");
	int a=ob.nextInt();
	System.out.println(" enter a second number");
	int b=ob.nextInt();
	System.out.println(" enter third number");
	int c=ob.nextInt();
	
	if(a>b && a>c) {
		System.out.println("a is gretest");
	}
	if(b>c && b>a)
	{System.out.println("b is gretest");
		
	}
	if(c>b && c>a) {
		System.out.println(" c is gretest");
	}
}
	
	public static void main(String args[])
	{
	
		gretest ob=new gretest();
		ob.display();
	}
		
		
	
		
	
	
	
	
	
	



}
