//Q7. Write a Java program to find the number of days in a month
import java.util.*;
public class month {
	
	Scanner ob=new Scanner(System.in);
	
	public void display()
	{
		int a=31;
		int b=30;
		int c=28;
		System.out.println("enter a number");
		int n=ob.nextInt();
		switch(n) {
		
		case 1:
			System.out.println("january="+a);
			break;
			
		case 2:
			System.out.println("february="+c);
			break;
		case 3:
			System.out.println("march="+a);
			break;
			
		case 4:
			System.out.println("april="+b);
			break;
		case 5:
			System.out.println("may="+a);
			break;
		case 6:
			System.out.println("june="+b);
			break;
			default:
				System.out.println("wrong innput");
				
		}
	}
	public static void main(String stgs[]) {
		
		month ob=new month();
		ob.display();
		
	}

}
