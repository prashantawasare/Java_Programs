Q6. Write a Java program that keeps a number from the user and generates an integer between 1 and 7
  and displays the name of the weekday.

import java.util.*;
public class weeklyday {
	
	
	Scanner ob=new Scanner(System.in);
	
	public void display()
	{
		System.out.println("enter a number");
		int a=ob.nextInt();
		
		switch(a)
		{
		case 1:
			System.out.println("monday");
			break;
		case 2:
			System.out.println("tuesday");
			break;
		case 3:
			System.out.println("wednesday");
			break;	
		case 4:
			System.out.println("thursday");	
			break;
		case 5:
			System.out.println("friday");
			break;
		case 6:
			System.out.println("saturday");
			break;
		case 7:
			System.out.println("sunday");
			break;
			
			default:
				System.out.println("wrong input");
		}
	}
	
    public static void main(String ars[]) {
    	weeklyday ob=new weeklyday();
    	ob.display();
    }
}
