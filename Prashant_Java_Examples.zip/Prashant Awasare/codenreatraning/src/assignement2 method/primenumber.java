Q10) Wap to check Prime Number Program in Java

import java.util.Scanner;
public class primenumber {
	
	Scanner ob=new Scanner(System.in);
	public void input(int n)
	{
		System.out.println("enter the number");
		 n=ob.nextInt();
		
	
      
	
		   int i=2;
		   
		 for(i=2;i<=n;i++)
		 {
		    if(n%i==0)
		     break;
		      
		 }
		   if(n==i)
		 System.out.println("prime");
		 else
		 System.out.println("not prime");
		 }
		 


	public static void main(String arfs[])
	{
		primenumber ob=new primenumber();
		ob.input(0);
	}
}



