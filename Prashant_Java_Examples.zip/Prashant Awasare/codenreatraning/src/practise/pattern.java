package practise;

public class pattern {
	
	public static void main(String sg[])
	{
		int i,j;
		for(i=1;i<=5;i++)
		{
			for(j=i;j<=5;j++)
			
				System.out.print(" ");
			for(j=1;j<=i;j++)
				
				
				if(i==5 || j==i || j==1)
					System.out.print(" *");
				else
					System.out.print("  ");
			
			System.out.println();
		}
	}

}
