package practise;

public class equalitymatrix {
	 public static void main(String arfs[])
	 {       
	    int a[][]={
	               {1,2,3},
	               {3,4,5},
	               {6,7,8}};
	     int b[][]={
	               {1,2,3},
	               {3,4,5},
	               {6,7,9}};

	       int row,row1,col,col1;
	       int i,j;
	        row=a.length;
	        row1=a.length;
	        col=a[0].length;
	        col1=a[0].length;
	        boolean c=true;
	       
	     if(row!=row1 && col!=col1)
	 		{  System.out.println("Matrix is not equal");}

	 		else
	 		 
	          {

	 		for(i=0;i<row;i++)
	 		{
	 		 for(j=0;j<col;j++)
	 			{
	 			if(a[i][j]!=b[i][j])
	 			  {

	 			   c=false;
	 			   break;
	 			  }
	 			}
	 			
	 		}
	 	        if(c==true)
	 		  {System.out.println("Matrix is equal");}
	 		  else

	 			{System.out.println("Matrix is not equal");}
	                    
	               }
	 		
	 	    }
	 	}


