package practise;
import java.util.*;
public class sunday {
	
	Scanner ob= new Scanner(System.in);
	int i,j;
	public boolean input(int n)
	{
		int rem,rev=0;int c=0;
		 
			j=i;c=0;
			while(j!=0)
			{
				
				j=j/10;
				c++;
			}j=i;int sum=0;
			while(j!=0)
			{	rem=j%10;
				sum=sum+(int)Math.pow(rem,c);
	            j=j/10;
			}
			
			if(sum==i)
			
		
		return ;
		
	}
	
	public static void main(String sdd[])
	{
		int n=1000;int i,j;
		sunday ob=new sunday();
		for(i=1;i<=n;i++)
		
	      
		   if( ob.input(n))
	       System.out.println(i);         
	}

}
