package practise;

public class smallestelementinmatrix {
	
	
	public static void main(String  as[])
	{
		int a[][]= {
				{1,2,3},
				{4,5,6},
				{7,8,9}
		};
		
		int i=a.length,j=a[0].length;
		int small=a[1][1];
		
		for(i=0;i<a.length;i++)
		{
			
			for(j=0;j<a.length;j++)
				if(small>a[i][j])
				{
					small=a[i][j];
				}
		}
		System.out.println("smallest element="+small);
		
int gretest=a[1][1];
		
		for(i=0;i<a.length;i++)
		{
			
			for(j=0;j<a.length;j++)
				if(gretest<a[i][j])
				{
					gretest=a[i][j];
				}
		}
		System.out.println("smallest element="+gretest);
	}

}
