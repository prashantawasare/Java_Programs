package practise;

public class pt {
	
	public static void main(String args[])
	{
		
		int i=24,j;
		 
		for(j=2;j<=i;j++)
		{
			if(i%j==0)
				break;
		}
		if(i==j)
			System.out.println("prime");
		else
			System.out.println(" not prime");
		
				
		}
	}


