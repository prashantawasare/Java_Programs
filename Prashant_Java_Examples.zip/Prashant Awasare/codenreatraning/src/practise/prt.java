package practise;
import java.util.*;
public class prt {
	
	
	public static void main(String sjd[])
	{
	
	int i,j;
	int a[]=new int[5];
	Scanner ob=new Scanner(System.in);
	for(i=0;i<a.length;i++)
	{
		a[i]=ob.nextInt();
	}
	
	int c=0;
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j])
				{
					
					System.out.println(a[j]);
					c++;
	
			
			}
			}
			
			
			
		}
		System.out.println(c);
		
		 
	


	      
	     
	
	
		
	}
}
