package practise;

import java.util.Scanner;








public class practise {
	

	
	
	
	int i,k,j;
	Scanner ob=new Scanner(System.in);
	public void result(int a[])
	{
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]<a[j])
				{
					k=a[i];
					a[i]=a[j];
					a[j]=k;
				}
			}
		}
			for(i=0;i<a.length;i++)
			{
				System.out.println(a[i]+" ");
			}

	
	}
	
	
	public static void main(String  arf[]) {
		practise ob=new practise();
		
		int a[]= {9,1,3,2,4,5,6,11,12,10,13};
		ob.result(a);
	
	}
}
