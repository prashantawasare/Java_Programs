package practise;
public class pr1 
{
        
    pr1()
    {
        this(10);
        System.out.println(" Default Constructor is called ");
        
    }
    
    
    pr1(int a)
    {
        
        
        System.out.println(" Parametric Constrcutor is called "+a);
        
    }
     
   
    pr1(int a, int b)
    {
        
        this();
        System.out.println(" Parametric Constrcutor is called "+a+b);
        
    }

     public static void main( String rgs[])
     {
    	 pr1  gg = new pr1(22,33);
         
     }
    
    
    
    
}