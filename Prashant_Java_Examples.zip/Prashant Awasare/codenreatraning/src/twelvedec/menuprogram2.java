package twelvedec;

public class menuprogram2 {

}
