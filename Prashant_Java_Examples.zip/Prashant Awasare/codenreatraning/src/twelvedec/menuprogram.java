package twelvedec;
//-Wap to create four method  add(),sub(),multiply(),divide() and do calculation
//in each method by no return no argument.
import java.util.*;
public class menuprogram {
	
	int i,a=16,b=4,c,d,e,f;
	Scanner ob=new Scanner(System.in);
	
	public int add()
	{
		
		c=a+b;
		return c;
	}
	public int sub()
	{
		
		d=a-b;
		return d;
	}
	public int mul()
	{
		
		e=a*b;
		return e;
	}
	public double div()
	{
		
		f=a/b;
		return f;
	}
	
	public static void main(String ars[])
	{
		menuprogram ob=new menuprogram();
		int sum=ob.add();
		System.out.println("addition"+sum);
		int sub=ob.sub();
		System.out.println("subtraction"+sub);
		int mul=ob.mul();
		System.out.println("multipication"+mul);
		double div=ob.div();
		System.out.println("division"+div);
		
		
		
	}

}
