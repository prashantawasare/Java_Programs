package twelvedec;
import java.util.*;
public class gretest {

	Scanner ob=new Scanner(System.in);
	int a,b,c;
	public void input() {
		
		System.out.println("enter the number 1");
		a=ob.nextInt();
		System.out.println("enter the number 2");
		b=ob.nextInt();
		System.out.println("enter the number 3");
		c=ob.nextInt();
		
	}
	public int disply() {
		if(a>b && a>c)
			return a;
		else if(b>a && b>c)
		  return b;
		else 
	
		return c;
	
	}
	
	public static void main(String args[]) {
		gretest ob=new gretest();
		ob.input();
		int gretest=ob.disply();
		System.out.println(gretest);
	
		
		
	}
}
