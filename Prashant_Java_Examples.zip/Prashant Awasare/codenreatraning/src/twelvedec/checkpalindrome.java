package twelvedec;
//WAP  inter 4 digit number and check it is palindrome of not

import java.util.*;
public class checkpalindrome {

	int i,n,rem,rev;
	Scanner ob=new Scanner(System.in);
	
	public void input()
	{
		System.out.println("enter a number");
		n=ob.nextInt();
	}
	
	public boolean checkpalindrom()
	{
		i=n;
		rev=0;
		while(i!=0)
		{
			
			rem=i%10;
			rev=rev*10+rem;
			i=i/10;
			
		}
		if(rev==i)
		return	 true;
		else
		return false;
	}
	public static void main(String arfs[]) {
		checkpalindrome ob=new checkpalindrome();
		ob.input();
		boolean palindrome=ob.checkpalindrom();
		System.out.println(palindrome);
	}
}
