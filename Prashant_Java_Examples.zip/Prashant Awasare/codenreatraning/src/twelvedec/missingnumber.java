package twelvedec;

//Q5. Write a program in Java for, Given two arrays 1,2,3,4,5 and 2,3,1,0,5 find which number is not present in the second array.
import java.util.*;
public class missingnumber {
	
	public static void main(String args[]) {
	
	
  
     int b[]= {2,3,1,5};
     Arrays.sort(b);int i;	
     System.out.println("given array");
	  for(i=0;i<b.length;i++) {
		  System.out.println(b[i]);
	  }
	   int n=b.length+1;
	   int totalsum=(n*(n+1))/2;
	  

	  int sum=0;
	
	
	  for( i=0;i<b.length;i++)
	{
	   sum=sum+b[i];

	    }
	  System.out.println("missing number="+(totalsum-sum));

	

}
}
