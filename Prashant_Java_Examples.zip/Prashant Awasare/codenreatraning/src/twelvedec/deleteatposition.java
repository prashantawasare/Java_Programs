package twelvedec;

public class deleteatposition {
	
	public static void main(String args[])
	{
	
	int a[]= {1,2,3,4,5};
	
	
	 int pos=1,i;
	
	for(i=0;i<a.length-1;i++)
	{
		a[i]=a[i+1];
	}
	
	for(i=0;i<a.length-1;i++)
	{
		System.out.println(a[i]+" ");
	}

}
}
