package twelvedec;
//take elements in array and return maximum
import java.util.*;
public class maxnumberinarray {

	int i,k;int a[]=new int[5];
	Scanner ob=new Scanner(System.in);
	public void input()
	{
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
		}
		
	}
	
	public int result() 
	{
		
		for(i=0;i<a.length;i++)
		{
			if(a[i]>k)
				k=a[i];
		}
		return k;
	}
	
	
	public static void main(String arg[]) {
		
		maxnumberinarray ob=new maxnumberinarray();
		ob.input();
		int maxnumber=ob.result();
		System.out.println(maxnumber);
		
	}
}


