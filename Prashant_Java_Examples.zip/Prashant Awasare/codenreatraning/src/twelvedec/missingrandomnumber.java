package twelvedec;

public class missingrandomnumber {
	
	public static void main(String asd[])
	{
		int a[]={11,12,13,14,15,16,18};

		  
		   double n=a.length+1;
		   double n2=2;

		  double totalsum=((n/n2)*(a[0]+a[a.length-1]));
		  int sum=0;int i;
		System.out.println("given array");
		for(i=0;i<a.length;i++)
		{
		   System.out.println(a[i]+" ");
		   }
		  for( i=0;i<a.length;i++)
		{
		   sum=sum+a[i];

		    }
		  System.out.println("missing number="+(totalsum-sum));

		     }
		
		
	}


