package twelvedec;
import java.util.*;
public class primenumberofarray {
	
	int i,j;
	Scanner ob=new Scanner(System.in);
	
	public void input(int a[]) {
		System.out.println("enter the array");
		for(i=0;i<a.length;i++) {
			
		
		a[i]=ob.nextInt();
		}
	}
	public void display(int a[]) {
		  
		for(i=0;i<a.length;i++) {
			
		 for(j=2;j<a[i];j++) {
		 
		
			
			if(a[i]%j==0) 
				break;
		 }
			
		 
			if(a[i]==j) 
				 System.out.println(a[i]);
					}
		}
		
	
		
	
	
	
	
	
	
	
public static void main(String as[]) {
		primenumberofarray ob=new primenumberofarray();
		int n=7;
		int a[]= new int[n];
		ob.input(a);
		ob.display(a);
		
	}
}
