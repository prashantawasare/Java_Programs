package twelvedec;
import java.util.*;

public class writtentypewithargument {
	
	Scanner ob=new Scanner(System.in);

	
	
	public int sum() {
		int a,b;
		System.out.println("enter the value of a");
		a=ob.nextInt();
		System.out.println("enter the vlue  of b");
		b=ob.nextInt();
		
		int c=a+b;
		return c;
	}
	public double aoc() {
		double radius,pi;
		System.out.println("enter the value of radius");
		radius=ob.nextDouble();
		System.out.println("enter the value of pi");
		pi=ob.nextDouble();
		double area=pi*radius*radius;
		return area;
	}
	
	public static void main(String arsg[]) {
		writtentypewithargument ob=new writtentypewithargument();
		
		int sum=ob.sum();
		System.out.println("sum="+sum);
		double areaofcircle=ob.aoc();
		System.out.println("area of circle"+areaofcircle);
		
	}

}
