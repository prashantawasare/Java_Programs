package inheritance2;

import inheritance15.class3;

public class pop extends class3
{
	 
	 
	  void scr()
	 {
		 dis();
		 System.out.println("sub"+(a-b))
	 }
	public static void main(String as[])
	 {

   	 class3  ob=new class3();
		
       
	 }

		 
		
		 
	 

	

}
