package inheritance2;

public class class3 {

}
