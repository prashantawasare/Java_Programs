package dec14;

public class thiskeyword {
	
	
	int id;
    String name;
    
    public void  result(int id,String name)
    {
    	this.id=id;
    	this.name=name;
    }
    
   public void display()
   {
	   System.out.println(id+" "+name);
   }
   
   public static void main(String rags[])
   {
	   thiskeyword ob=new thiskeyword();
	    ob.result(12,"prashant");
	   ob.display();
	   
   }
}
