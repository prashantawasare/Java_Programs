package dec14;

public class constructoroverloading {
	
	

	constructoroverloading()
	{
		this(1);
		System.out.println("default caonstructor");
		
	}
	
	constructoroverloading(int a)
	{
		this(1,2);
		System.out.println(a+"parametric constructor is called");
	}
	constructoroverloading(int a,int b)
	{
		
		
		System.out.println(a+b);
	}
	
	public static void main(String as[])
	{
		constructoroverloading ob=new constructoroverloading();
	}
}
