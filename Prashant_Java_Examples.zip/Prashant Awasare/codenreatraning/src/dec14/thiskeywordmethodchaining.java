package dec14;

public class thiskeywordmethodchaining {
	
	
	
	
	
	public void method1()
	{
		System.out.println(" hello ");
	}
	
	public void method2()
	{
		this.method1();
		System.out.println(" hello 2 ");
	}
	public void method3()
	{
		this.method2();
		System.out.println(" hello 3 ");
	}
	public void method4()
	{
		this.method3();
		System.out.println(" hello 4");
	}
	thiskeywordmethodchaining()
	{
		this.method4();
		System.out.println(" hello 5");
	}
	
	public static void main(String rags[])
	{
		thiskeywordmethodchaining ob=new thiskeywordmethodchaining();
	}

}
