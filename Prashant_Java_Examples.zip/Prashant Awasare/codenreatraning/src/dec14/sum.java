package dec14;

public class sum {
	
	
	
	public void sumi(int i,int n)
	{   
		int sum=0;
		for(i=1;i<=100;i++)
		{
			sum=sum+i;
		}
		System.out.println("sum of numbers="+sum);
		
	}
	
	public static void main(String rags[])
	{
		sum ob=new sum();
		
		int n=100;
		ob.sumi(0,0 );
	}

}
