package constructorassignment2;


	
	//Q1.Wap initialise a 3*3 matrix and find the transpose.
	import java.util.*;
	public class question1 {
		
		
		int a[][]=new int[3][3];
		int i,j;
		
		Scanner ob=new Scanner(System.in);
		question1()
		{
			for(i=0;i<a.length;i++)
			{
				for(j=0;j<a.length;j++)
				{
					a[i][j]=ob.nextInt();
				}
			}
		}
	  public void result()
	  {
		  System.out.println("transpose of matrix");
		  for(i=0;i<a.length;i++)
		  {
			  for(j=0;j<a.length;j++)
			  
				  System.out.print(a[j][i]+" ");
			  System.out.println();
		  }
	  }
	  
	  public static void main(String as[])
	  {
		  question1 ob=new question1();
		  ob.result();
	  }
	}



