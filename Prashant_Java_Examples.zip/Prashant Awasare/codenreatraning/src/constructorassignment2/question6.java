package constructorassignment2;
//Q6.Wap initialise a 3*3 matrix and check it is sparse matrix or not.
import java.util.*;
public class question6 {
	
	
	int a[][]= new int[3][3];
	
	
	int i=a.length;
	int j=a[0].length;
    int	size=i*j;
	int c=0;
	Scanner ob=new Scanner(System.in);
	
	question6()
	{
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<a.length;j++)
			{
				a[i][j]=ob.nextInt();
			}
		}	
			System.out.println("given matrix ");
			for(i=0;i<a.length;i++)
			{
				for(j=0;j<a.length;j++)
				{
					System.out.print(a[i][j]+" ");
				}
				System.out.println();
			}
	}
	public void display()
	{ 
		for(i=0;i<a.length;i++)
		  {    
			  for(j=0;j<a.length;j++)
			  {    if(a[i][j]==0)
			    c++;
			   }
			    
		  }
		if(c>size/2)
			   System.out.println("it is sparce matrix");
			   else
			   System.out.println("it is not sparce matrix");

			
		
	}
	
	
			
		
	public static void main(String as[])
	{
		question6 ob=new question6();
		ob.display();
		
	}
	

}
