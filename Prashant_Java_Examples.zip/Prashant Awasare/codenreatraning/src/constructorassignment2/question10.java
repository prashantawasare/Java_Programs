package constructorassignment2;

import java.util.Scanner;

//Q11.initialise 3*3 matrix and search any particular element.
public class question10 {

	

	int a[][]={
			   {1,2,3},
			   {3,4,5},
			   {6,7,8}
	           };
	
	 
	 
	 int i,j;int k,d,p,r;
	 Scanner ob=new Scanner(System.in);
	 question10()
	 {
		 System.out.println(" a matrix");
		 for(i=0;i<a.length;i++)
		 {
			 for(j=0;j<a.length;j++)
			 {
				 System.out.print(a[i][j]+" ");
			 }
			 
			 System.out.println();
		 }

      }
	 
	 public void display()
	 {
		 System.out.println("  enter the element you want to search");
		 k=ob.nextInt();
		 for(i=0;i<a.length;i++)
		 {
			 for(j=0;j<a.length;j++)
			 {
				 if(k==a[i][j])
					 r=1;
			 }
		 }
		 if(r==1)
		 
			 System.out.println(" number found");
		 else 
			 System.out.println("number not found"); 
		 
	 }
	 
	 public static void main(String hd[])
	 {
		 question10  ob=new question10();
		 ob.display();
		 
	 }
}
