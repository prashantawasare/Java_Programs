package constructorassignment2;

//Q4.Wap initialise a 3*3 matrix and find the sum of columns.
public class question4 {
	
	
	int i,j;
	int a[][]= {
			     {1,2,3},
			     {4,5,6},
			     {7,8,5}
	         } ;
	
	int sum=0;
	question4()
	{  
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<a.length;j++)
			{
				sum=sum+a[j][i];
				
			}
			
		}
		System.out.println("sum="+sum);
		
	
	}
	
	public static void main(String as[])
	{
		question4 ob=new question4();
	}

}



