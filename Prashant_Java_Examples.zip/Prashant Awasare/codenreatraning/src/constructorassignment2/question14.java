package constructorassignment2;

import java.util.Scanner;

//Q10.initialise 3*3 matrix and print the element with its index value.
public class question14 {
	
	
	int a[][]={
			   {1,2,3},
			   {3,4,5},
			   {6,7,8}
	           };
	
	 
	 
	 int i,j;
	 Scanner ob=new Scanner(System.in);
	 question14()
	 {
		 System.out.println(" a matrix");
		 for(i=0;i<a.length;i++)
		 {
			 for(j=0;j<a.length;j++)
			 {
				 System.out.print(a[i][j]+" ");
			 }
			 
			 System.out.println();
		 }

}
	 
	 public void display()
	 {
		 
		
		 for(i=0;i<a.length;i++)
		 {
			 for(j=0;j<a.length;j++)
			 {
				
				 
				 System.out.println("elements is="+a[i][j]+" its index is="+i+" "+j);
				 
			 }
			
		 }
		 
		 

		 
	 }
		 
	 public static void main(String as[])
	 {
		 question14 ob=new question14();
		 ob.display();
	 }


}
