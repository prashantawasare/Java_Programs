package constructorassignment2;
/*Q9.Wap initialise a 3*3 matrix and search any  two element and print the condition:
    only 1st element found
     only 2nd element found
     both element found
      not any element found*/
import java.util.*;
public class question9 {
	

	int a[][]={
			   {1,2,3},
			   {3,4,5},
			   {6,7,8}
	           };
	
	 
	 
	 int i,j;int k,d,p,r;
	 Scanner ob=new Scanner(System.in);
	 question9()
	 {
		 System.out.println(" a matrix");
		 for(i=0;i<a.length;i++)
		 {
			 for(j=0;j<a.length;j++)
			 {
				 System.out.print(a[i][j]+" ");
			 }
			 
			 System.out.println();
		 }

    }
	 
	 public void display()
	 {
		 System.out.println(" enter elements you want yo search");
		 k=ob.nextInt();
		 d=ob.nextInt();
		 for(i=0;i<a.length;i++)
		 {
			 for(j=0;j<a.length;j++)
			 {
				 if(k==a[i][j])
					r=1; 
				 if(d==a[i][j])
					 p=1;
				 
			 }
			
		 }
		 if(r==1 && p!=1)
			 System.out.println(" 1st  element found");
		 else if(r!=1 && p==1)
			 System.out.println(" 2nd element found");
		 else if(r==1 && p==1)
			 System.out.println(" both element are found");
		 else if(r!=1 && p!=1)
			 System.out.println(" both elements are not found");
	 }
	 public static void main(String as[])
	 {
		 question9 ob=new question9();
		 ob.display();
	 }
}
