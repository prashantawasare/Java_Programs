package constructorassignment2;

import java.util.Scanner;

//Q14.Wap input a matrix and and find the transpose of matrix using third container.
public class question13 {
	
	int a[][]=new int[3][3];
	int b[][]=new int[3][3];
	int i,j;
	
	Scanner ob=new Scanner(System.in);
	question13()
	{
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<a.length;j++)
			{
				a[i][j]=ob.nextInt();
			}
		}
	}
  public void result()
  { 
	  System.out.println(" a matrix");
	  for(i=0;i<a.length;i++)
	  {
		  for(j=0;j<a.length;j++)
		    
			  System.out.print(a[i][j]+" ");
		  System.out.println();
	  }

	  for(i=0;i<b.length;i++)
	  {
		  for(j=0;j<b.length;j++)
		     b[i][j]=a[i][j];
			  

	  }
	  System.out.println("transpose of a matrix in b matrix");
	  for(i=0;i<b.length;i++)
	  {
		  for(j=0;j<b.length;j++)
			  System.out.print(b[j][i]+" ");
		  System.out.println();
			  

	  }
  }
  
  public static void main(String as[])
  {
	  question13 ob=new question13();
	  ob.result();
  }

}
