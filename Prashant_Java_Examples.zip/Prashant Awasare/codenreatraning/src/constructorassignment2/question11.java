package constructorassignment2;

import java.util.Scanner;

//Q12.initialise 3*3 matrix and print the  sum of any two selected element.
public class question11 {
	
		

		int a[][]={
				   {1,2,3},
				   {3,4,5},
				   {6,7,8}
		           };
		
		 
		 
		 int i,j;int k,d,p=0,r;int sum=0;int c=0;
		 Scanner ob=new Scanner(System.in);
		 question11()
		 {
			 System.out.println(" a matrix");
			 for(i=0;i<a.length;i++)
			 {
				 for(j=0;j<a.length;j++)
				 {
					 System.out.print(a[i][j]+" ");
				 }
				 
				 System.out.println();
			 }

	    }
		 
		 public void display()
		 {
			 System.out.println(" enter elements you want take for sum");
			 k=ob.nextInt();
			 d=ob.nextInt();
			 sum=0;
			 for(i=0;i<a.length;i++)
			 {
				 for(j=0;j<a.length;j++)
				 {
					 if(a[i][j]==k)
					 c=1;
					 if(a[i][j]==d)
						 p=1;
					 
					 
				 }
				
			 }
			 if(c==1 && p==1)
				 sum=k+d;
			 else
				 System.out.println("elements not found");
			 System.out.println(" sum of two selected elemnts"+sum);
			 
			 
		 }
			 
		 public static void main(String as[])
		 {
			 question11 ob=new question11();
			 ob.display();
		 }
	}


