package constructorassignment2;
//Q8.input two matrx and print subtract in third matrix.
public class question8 {

	
	int a[][]={
			   {1,2,3},
			   {3,4,5},
			   {6,7,8}
	           };
	
	 int b[][]= {
			     {9,10,11},
			     {12,13,14},
			     {15,16,17}
	                };
	 int c[][]=new int[3][3];
	 int i,j;
	 question8()
	 {
		 System.out.println(" a matrix");
		 for(i=0;i<a.length;i++)
		 {
			 for(j=0;j<a.length;j++)
			 {
				 System.out.print(a[i][j]+" ");
			 }
			 
			 System.out.println();
		 }
		 
		 System.out.println(" b matrix");
		 for(i=0;i<b.length;i++)
		 {
			 for(j=0;j<b.length;j++)
			 {
				 System.out.print(b[i][j]+" ");
			 }
			 
			 System.out.println();
		 }
		 System.out.println(" sum of matrix");
		 for(i=0;i<c.length;i++)
		 {
			 for(j=0;j<c.length;j++)
			 {
				 c[i][j]=a[i][j]-b[i][j];
				 System.out.print(c[i][j]+" ");
			 }
			 System.out.println();
		 }
	 }
	 
	 public static void main(String as[])
	 {
		 question8 ob=new question8();
		 
	 }
			 
			 
	             
}
