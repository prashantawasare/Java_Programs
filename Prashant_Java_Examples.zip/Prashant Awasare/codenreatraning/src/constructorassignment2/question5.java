package constructorassignment2;
//Q5.Wap initialise a 3*3 matrix and find the element present at odd position.
public class question5 {
	
	
	
	int i,j;
	int a[][]= {
			     {1,2,3},
			     {4,5,6},
			     {7,8,9}
	         } ;
	
	int sum=0;
	public void display()
	{    System.out.println("given matrix ");
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<a.length;j++)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		
	}
	question5()
	{
		System.out.println("element present at odd position in  matrix ");
		for(i=0;i<a.length;i=i+2)
		{
			for(j=0;j<a.length;j=j+2)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		
	
	}
	
	public static void main(String as[])
	{
		question5 ob=new question5();
	}


}
