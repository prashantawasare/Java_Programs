package constructorassignment2;

import java.util.Scanner;

//Q13.Wap input a matrix and find thr sum and average.
public class question12 {
	
	int a[][]={
			   {1,2,3},
			   {3,4,5},
			   {6,7,8}
	           };
	
	 
	 
	 int i,j;int k,d,p,r;int sum=0;
	 Scanner ob=new Scanner(System.in);
	 question12()
	 {
		 System.out.println(" a matrix");
		 for(i=0;i<a.length;i++)
		 {
			 for(j=0;j<a.length;j++)
			 {
				 System.out.print(a[i][j]+" ");
			 }
			 
			 System.out.println();
		 }

 }
	 
	 public void display()
	 {
		 
		 sum=0;double average=0;
		 for(i=0;i<a.length;i++)
		 {
			 for(j=0;j<a.length;j++)
			 {
				 sum=sum+a[i][j];
				 
				 average=sum/9;
				 
			 }
			
		 }
		 System.out.println(" sum of two  elemnts"+sum);
		 System.out.println(" avearge of elemnts"+average);
		 
 
		 
	 }
		 
	 public static void main(String as[])
	 {
		 question12 ob=new question12();
		 ob.display();
	 }

}
