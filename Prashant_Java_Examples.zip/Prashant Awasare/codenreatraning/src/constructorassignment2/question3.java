package constructorassignment2;
//Q3.Wap initialise a 3*3 matrix and find the sum of rows.
public class question3 {
	
	
	int i,j;
	int a[][]= {
			     {1,2,3},
			     {4,5,6},
			     {7,8,9}
	         } ;
	
	int sum=0;
	question3()
	{
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<a.length;j++)
			{
				sum=sum+a[i][j];
			}
		}
		
		System.out.println(sum);
	}
	
	public static void main(String as[])
	{
		question3 ob=new question3();
	}

}
