package constructorassignment2;

//Q7.Wap initialise two 3*3 matrix and find the multiplication in third matrix.
public class question7 {
	
	
	int a[][]= {
			    {1,2,3},
			    {4,5,6},
			    {7,8,9}
	          };
	int b[][]= {
		    {11,12,13},
		    {14,15,16},
		    {17,18,19}
          };
	int c[][]=new int[3][3];
	int i,j,k;
	question7()
	{
		System.out.println(" a matrix");
		
		for(i=0;i<a.length;i++)
		{ 
			for(j=0;j<a.length;j++)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println(); 
		}
		
System.out.println(" b matrix");
		
		for(i=0;i<b.length;i++)
		{
			for(j=0;j<b.length;j++)
			{
				System.out.print(b[i][j]+" ");
			}
			System.out.println(); 
		}
	}
	
	public void result()
	{  System.out.println(" multiplication of matrix");
		for(i=0;i<c.length;i++)
		{  
			for(j=0;j<c.length;j++)
			{
				
				c[i][j]=0;
				for(k=0;k<a.length;k++)
				c[i][j]=c[i][j]+a[i][k]*b[k][j];
				
				System.out.print(c[i][j]+" ");
			}
			
			System.out.println();
		}
	}
	
	public static void main(String as[])
	{
		question7 ob=new question7();
		ob.result();
		
	}
					
			
	}


