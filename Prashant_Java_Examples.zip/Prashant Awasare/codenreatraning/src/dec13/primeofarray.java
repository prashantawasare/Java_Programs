package dec13;
import java.util.*;
public class primeofarray {
	
	int i,j; 
	Scanner o=new Scanner(System.in);
	public boolean prime()
	{
		
		      
			for(j=2;j<i;j++) 
		{
			if(i%j==0)
				break;
			
		}
		if(i==j)
			return true;
		else 
		return	false;
	}
	
	
	public static void main(String rags[])
	
	{	
		checkprime o=new checkprime();
		int a[]= {1,2,3,4,5};
		int i;
		for(i=0;i<a.length;i++)
		{
			if(o.prime(a[i])) {
		
		System.out.println(a[i]);
			}
		
	}

	}
}
