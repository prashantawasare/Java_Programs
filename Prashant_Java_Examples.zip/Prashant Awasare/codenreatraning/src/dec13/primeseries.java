package dec13;

import java.util.Scanner;

public class primeseries {
	
int i,j,n;
Scanner ob=new Scanner(System.in);

	
	public boolean prime(int i)
	{
		
		      
			for(j=2;j<i;j++) 
		{
			if(i%j==0)
				break;
			
		}
		if(i==j)
			return true;
		else 
		return	false;
	}
	
	
	public static void main(String rags[])
	
	{	
		checkprime o=new checkprime();
		
		int i;
		for(i=0;i<=100;i++)
		if(o.prime(i))
		System.out.println(i);
	
		
	}
	


}
