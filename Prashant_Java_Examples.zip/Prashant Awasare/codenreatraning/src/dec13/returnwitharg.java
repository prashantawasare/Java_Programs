package dec13;
import java.util.*;
public class returnwitharg {
	

	
	public int sqr(int n)
	{
		return n*n;
	}
	
	public static void main(String ags[])
	{Scanner ob=new Scanner(System.in);
		returnwitharg o=new returnwitharg();
		System.out.println("enter the value ofn");
		int n=ob.nextInt();
	
	
		System.out.println(o.sqr(n));
		
	}
	
	

}
