package dec13;
import java.util.*;
public class checkprime {
	
	
	int i,j,n;

	
	public boolean prime(int i)
	{
		
		      
			for(j=2;j<i;j++) 
		{
			if(i%j==0)
				break;
			
		}
		if(i==j)
			return true;
		else 
		return	false;
	}
	
	
	public static void main(String rags[])
	
	{	Scanner ob=new Scanner(System.in);
		checkprime o=new checkprime();
		System.out.println(" enter the value");
		int i=ob.nextInt();
		
		if(o.prime(i))
		System.out.println("no is prime");
		else
			System.out.println("no is not prime");
		
	}
	

}
