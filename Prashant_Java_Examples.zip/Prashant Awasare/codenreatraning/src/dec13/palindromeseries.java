package dec13;

import java.util.Scanner;

public class palindromeseries {
	
	int i,j,n;
	Scanner ob=new Scanner(System.in);

		
		public boolean palindrome(int i)
		{
			
			  int rev=0;int rem;
			  int j=i;
			  while(j!=0)
			  {
				 rem=j%10;
				 rev=rev*10+rem;
				 j=j/10;
				 
			  }
			  
				
			if(rev==i)
				return true;
			else 
			return	false;
		}
		
		
		public static void main(String rags[])
		
		{	
			palindromeseries ob=new palindromeseries();
			
			int i;
			for(i=1;i<=100;i++)
			if(ob.palindrome(i))
			System.out.println(i);
		
			
		}
		



}
