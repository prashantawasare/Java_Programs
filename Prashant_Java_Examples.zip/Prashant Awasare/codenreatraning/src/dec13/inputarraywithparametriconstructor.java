package dec13;
import java.util.*;
public class inputarraywithparametriconstructor {
	
	
	int i;	
	
	Scanner ob=new Scanner(System.in);
	
	
	inputarraywithparametriconstructor(int a[],int b[])
	{
	    for(i=0;i<a.length;i++)
	    {
	    	
	    	a[i]=ob.nextInt();
		
	    }
	    for(i=0;i<a.length;i++)
		{
			
			System.out.println(a[i]);
	}
	    for(i=0;i<b.length;i++)
	    {
	    	
	    	b[i]=ob.nextInt();
		
	    }
	    for(i=0;i<b.length;i++)
		{
			
			System.out.println(b[i]);
	}
	}
	public static void main(String arg[])
	{ int a[]=new int[5];
	int b[]=new int[5];
	inputarraywithparametriconstructor ob=new inputarraywithparametriconstructor(a,b);
	
       
	}
	

}
