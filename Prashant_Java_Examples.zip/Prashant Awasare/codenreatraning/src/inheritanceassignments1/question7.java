package inheritanceassignments1;

import java.util.Scanner;
//Q7.Wap to input an array and find the 2nd max element using constructor.
public class question7 {


public static void main(String sd[])
{
	secondmax ob=new secondmax();
	ob.display();
}

}

class input2
{  int i;
Scanner ob=new Scanner(System.in);
int a[]=new int[6];
input2()
{
	System.out.println("elemts in array");
	for(i=0;i<a.length;i++)
	{
		a[i]=ob.nextInt();
	}
	}
}

class  secondmax extends input2
{     
public void display()
{
      
	System.out.println("given array");
	for(i=0;i<a.length;i++)
	{
		System.out.println(a[i]);
	}
	
			
		
		System.out.println("second max"+a[a.length-2]);
		
	
	
	
	
}

}



