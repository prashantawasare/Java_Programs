package inheritanceassignments1;
import java.util.*;
public class question1
//Q1.Java program to print EVEN and ODD elements from an array and also find the count and sum individually.
{
	public static void main(String as[])
	{
		sorting  ob=new sorting();
		ob.display1();
		ob.display2();
		ob.result();
		ob.result2();
	}
	

}

class evenodd

{
	Scanner ob=new Scanner(System.in);
	int i;
	int a[]= {1,2,3,4,5,6};

	
	public void display1() {
		int c=0,sum=0;
		System.out.println("even numbers");
		for(i=0;i<a.length;i++)
		{
			if(a[i]%2==0)
			{
				System.out.println(a[i]);
				c++;
				sum=sum+a[i];
			}
		}
		
		
			System.out.println("sum="+sum);
		System.out.println("count="+c);
	}	
		
		public void display2()
		{   int sum=0,c=0;
			System.out.println("odd numbers");
		for(i=0;i<a.length;i++)
		{
			if(a[i]%2!=0)
			{
				System.out.println(a[i]);
				c++;
				sum=sum+a[i];
			}
		}
		
		
			System.out.println("sum="+sum);
		System.out.println("count="+c);
			
		
		}
		
	
	
}
//Q2. WAP In java Reverse the array 
//input in constructor and final result through the method.
class reverse extends evenodd
{
	int i;
	
	int a[]=new int[5];
	reverse()
	{
		System.out.println("enter elements in array");
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
		}
	}
	public void result()
	{  System.out.println(" array in reverse order");
		for(i=a.length-1;i>=0;i--)
		{ 
			System.out.println(a[i]);
			
		}
	}
}

//Q3. . Write a program to sort the 10 elements from array. 
// input in constructor and final result through the method.
class sorting extends reverse
{
	int i,j,k;
	int a[]=new int[12];
	sorting()
	{
		System.out.println("enter elements in array");
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
		}
	}
	
	public void result2()
	{
		for(i=0;i<a.length-2;i++)
		{
			for(j=i+1;j<a.length-2;j++)
			{
				if(a[i]>a[j])
				{	k=a[i];
				    a[i]=a[j];
				    a[j]=k;
				}
			}
		}
		System.out.println(" sorted 10 elemets from 12 elements");
		for(i=0;i<a.length-2;i++)
		{
			System.out.println(a[i]);
		}
	}
}
