package inheritanceassignments1;

import java.util.Scanner;



class input6
{
	int i,p,t,k,r;
	Scanner ob=new Scanner(System.in);
	
	int a[]=new int[5];
	 input6() {
		System.out.println("enter an array");
		for(i=0;i<a.length;i++) {
			
		
		
		a[i]=ob.nextInt();
		}
		System.out.println("enter element you want tto seach");
		k=ob.nextInt();
		r=ob.nextInt();
		
	}
	
}

class search2numbers extends input6
{
public  void display() {
		
		for(i=0;i<a.length;i++) {
			if(k==a[i]) {
				p=1;
			}
			if(r==a[i]) {
				t=1;
			}
			
		}
		
		
	

	
    if(p==1 && t==1) {
	System.out.println("both number are found");}
	else if(p!=1 && t==1) {
		System.out.println("only t is found");}
		else if(p==1 && t!=1) {
			System.out.println("only p is found");}
			else if(p!=1 && t!=1) {
				System.out.println(" both numbers are not found");
			}
		
		
	
	}
	
}




public class question11{
public static void main(String args[])
{
	search2numbers ob=new search2numbers();
	
	ob.display();
}

}


