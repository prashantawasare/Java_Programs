package inheritanceassignments1;

import java.util.Scanner;

/*Q6.Wap replace 0's from the square of  the next element of array using constructor.
your array is-{2,0,4,8,0,5,0,5,8};*/
public class question6 {



public static void main(String sd[])
{
	square ob=new square();
	ob.display();
}

}

class input1
{  int i;
Scanner ob=new Scanner(System.in);
int a[]={2,0,4,6,8,0,5,0,8};
input1()
{
	System.out.println("elemts in array");
	for(i=0;i<a.length;i++)
	{
		System.out.print(a[i]+" ");
	}
	
}
}

class square extends input1
{     
public void display()
{

	for(i=0;i<a.length;i++)
	{
		if(a[i]==0)
		{
			a[i]=a[i+1]*a[i+1];
		}
		System.out.println(a[i]);
		
	}
	
	
	
}

}


