package inheritanceassignments1;

import java.util.Scanner;

//Q10.Wap enter an array and search any particular element and find the count.
class input5
{  int i;
Scanner ob=new Scanner(System.in);
int a[]=new int[6];
input5()
{
	System.out.println("elemts in array");
	for(i=0;i<a.length;i++)
	{
		a[i]=ob.nextInt();
	}
	}
}

class  search extends input5
{     
public void display()
{
      
	
	for(i=0;i<a.length;i++)
	{
		
		System.out.println(a[i]);
	}
	System.out.println("enter the element you want to search");
	int n=ob.nextInt();
	int c=0;
	for(i=0;i<a.length;i++)
	{
		if(a[i]==n)
		{	System.out.println(" elment found");
			c++;
		  }    
		         
		
		
	}
	
		
	
	  
		
	   
	System.out.println("count"+c);
			
		
	
		
	
	
	
	
}

}





public class question10 
{public static void main(String sd[])
{
	search	 ob=new search();
	ob.display();
}

}
