package inheritanceassignments1;

import java.util.Scanner;

//Q8.Wap to input an array and find the 2nd min element using constructor.
public class question8 {

public static void main(String sd[])
{
	secondmin ob=new secondmin();
	ob.display();
}

}

class input3
{  int i;
Scanner ob=new Scanner(System.in);
int a[]=new int[6];
input3()
{
	System.out.println("elemts in array");
	for(i=0;i<a.length;i++)
	{
		a[i]=ob.nextInt();
	}
	}
}

class  secondmin extends input3
{     
public void display()
{
      
	System.out.println("given array");
	for(i=0;i<a.length;i++)
	{
		System.out.println(a[i]);
	}
	
			
		
		System.out.println("second min"+a[1]);
		
	
	
	
	
}

}


