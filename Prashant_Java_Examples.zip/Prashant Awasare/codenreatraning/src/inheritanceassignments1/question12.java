package inheritanceassignments1;

import java.util.Scanner;


class input7
{
	int i,j;
	Scanner ob=new Scanner(System.in);
    int a[]=new int[5];
	input7()
	{
		System.out.println("enter the array");
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
		}
}
}
class occurance extends input7
	{
		int c=0;
		public void display()
		{
			System.out.println(" enter the number you want to find its occurance");
			int t=ob.nextInt();
			
			for(i=0;i<a.length;i++)
			{   
				
				
					if(a[i]==t)
					{
						c++;
					
						
					}
				}
					
				System.out.println(c);
			
		}
		}

	public class question12
	{
		
		public static void main(String as[])
		{
			occurance ob=new occurance();
			ob.display();
			
			
		}
		
		

	}
		
		
	
	
