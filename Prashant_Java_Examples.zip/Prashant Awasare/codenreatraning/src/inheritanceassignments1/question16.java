package inheritanceassignments1;

/*publicQ5.Given an array of integers arr[], The task is to find the index of first repeating element in it i.e. the 
element that occurs more than once and whose index of the first occurrence is the smallest. 
Examples: 
Input: arr[] = {10, 5, 3, 4, 3, 5, 6}
Output:5*/

class input10
{
	int a[]= {10,5,3,4,3,5,6};
	int i,j,c=0;
    int n=a.length;
	input10()
	{
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}
	
}

class output extends input10
{
	
	public void dis()
	{
		for(i=0;i<a.length;i++)
		{
			
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j])
				{
					
				System.out.println(a[j]);
				c=1;
				j=n;	
				}
				
				
					
			}
			
		}
		
	}
		
		
		
		
	}



class question16
{
	
	public static void main(String afs[])
	{    int a[]={10,5,3,4,3,5,6};
		int n=a.length;
		output ob=new output();
		ob.dis();
		
	}

}
