package inheritanceassignments1;
import java.util.*;
//Q5. How do you find the largest and smallest number in an unsorted integer array size 10. 
//input in constructor and final result through the method. 
public class question5 {
	
	
	public static void main(String sd[])
	{
		maxmin ob=new maxmin();
		ob.display();
	}

}

class input
{  int i;
   Scanner ob=new Scanner(System.in);
   int a[]=new int[5];
	input()
	{
		System.out.println("enter the elements in array");
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
		}
		
	}
}

class maxmin extends input
{     
	public void display()
	{
		int max=0;int c=0;
		for(i=0;i<a.length;i++)
		{
			if(max<a[i])
			c++;
		}
		System.out.println(" max number"+max);
		
		int min=a[0];
		for(i=0;i<a.length;i++)
		{
			if(min>a[i])
			{c++;}
		}
		System.out.println(" min number"+min);
	}
	
}
