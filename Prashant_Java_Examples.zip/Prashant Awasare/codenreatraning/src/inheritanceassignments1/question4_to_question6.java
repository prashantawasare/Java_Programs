package inheritanceassignments1;
import java.util.*;
//Q4..Find the duplicate from the elements Size of array will be 10; 
//input in constructor and final result through the method.

public class question4_to_question6 {
	
	public static void main(String arfs[])
	{
		result ob=new result();
		ob.result1();
	}

}

class duplicate_elments
{
	int i,j;
	int a[]=new int[10],c=0;
	Scanner ob=new Scanner(System.in);
	duplicate_elments()
	{  System.out.println("enter the elments in array");
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
		}
	}
}

class result extends duplicate_elments
{
	
	public void result1()
	{
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j])
				{
					System.out.println(a[j]);
					
					c++;
				}
				
			}
			
			
		}
	}
	}
	

