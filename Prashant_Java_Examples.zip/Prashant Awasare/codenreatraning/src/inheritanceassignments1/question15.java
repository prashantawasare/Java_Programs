package inheritanceassignments1;
/*Q4.Given an array of N integers, and a number sum, the task is to find the number of pairs of integers in the array whose sum is equal to sum.

Examples:  

Input:  arr[] = {1, 5, 7, -1}, sum = 6
Output:  2*/

class intialise
{
	int i,j;
	int a[]= {1,5,7,-1};
	intialise()
	{
	System.out.println("given array");
	for(i=0;i<a.length;i++)
	{
		System.out.println(a[i]);
	}
	}
}

class sum extends intialise
{
	int sum=6,c=0;
	public void display()
	{  System.out.println("double pair");
	for(i=0;i<a.length;i++)
	{
		for(j=i+1;j<a.length;j++)
		{
			if(a[i]+a[j]==sum)
				{System.out.println(a[i]+" "+a[j]);
				c++;}
		}
	}
	
	System.out.println("count "+c);
}
}



















public class question15
{
	
	public static void main(String as[])
	{
		sum ob=new sum();
		ob.display();
	}

}
