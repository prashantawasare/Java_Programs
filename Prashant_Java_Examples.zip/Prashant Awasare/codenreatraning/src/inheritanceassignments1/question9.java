package inheritanceassignments1;

import java.util.Scanner;
//Q9.WAP to replace all the 0’s with 1’s in your array. Your array is [26, 0, 67, 45, 0, 78, 
//54, 34, 10, 0, 34] 


class input4
{  int i;
Scanner ob=new Scanner(System.in);
int a[]=new int[6];
input4()
{
	System.out.println("elemts in array");
	for(i=0;i<a.length;i++)
	{
		a[i]=ob.nextInt();
	}
	}
}

class  replace extends input4
{     
public void display()
{
      
	System.out.println("given array");
	for(i=0;i<a.length;i++)
	{
		if(a[i]==0)
			a[i]=1;
		System.out.println(a[i]);
	}
	
			
		
	
		
	
	
	
	
}

}
public class question9 {
	

public static void main(String sd[])
{
	replace	 ob=new replace();
	ob.display();
}

}



