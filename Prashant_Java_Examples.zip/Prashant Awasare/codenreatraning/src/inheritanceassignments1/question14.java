package inheritanceassignments1;
/*Q3.Given an array arr[] of size N-1 with integers in the range of [1, N], the task is to find the missing number from the first N integers.
Note: There are no duplicates in the list.
Examples: 

Input: arr[] = {1, 2, 4, 6, 3, 7, 8}, N = 8
Output: 5*/

class input8
{   int i;
    int a[]={1,2,3,4,6,7,8};
	input8()
	{
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
	}
}

class missing extends   input8
{
	public void display()
	{
		
	int n=a.length+1;
	  int totalsum=(n*(n+1)/2);
	     int sum=0;
		
		for(i=0;i<a.length;i++)
		{
			sum=sum+a[i];
		}
		
		System.out.println("missing number="+(totalsum-sum));
	}
}

public class question14 {
	
	public static void main(String as[])
	{
		missing ob=new missing();
		ob.display();
	}

}

