package codenreatraning;

public class clockwise {
	
	public static void main(String ss[])
	{
		

		  int a[]={1,2,3,4,5};

		int i,j;
		

		    
		   int n=2;
		 for(i=0;i<n;i++)
		{
		   int first=a[0];
		   for(j=0;j<a.length-1;j++)
		  {
		          
		    a[j]=a[j+1];

		    }
		      a[a.length-1]=first;}
		   System.out.println("clockwise rotation");

		  for(i=0;i<a.length;i++)
		{
		   System.out.print(a[i]+" ");
		    }

		}
		
	}


