package codenreatraning;
import java.util.*;
public class sumof_10equalto30 {



	 
	    public static void main(String[] args) {

	        int a[]= {10,10,10,4,5,6,};

	        

	        int sum=0;

	        for(int k=0;k<a.length;k++)
	        {
	            if(a[k]==10)
	            {
	                sum = sum+a[k];
	            }
	            
	        }

	        if(sum==30)
	        {
	            System.out.println(true);
	        }
	        else
	            System.out.println(false);
	        
	    }
	}


