
//Q2.Wap enter an array and find the sum and count of odd element.
package codenreatraning;
import java.util.Scanner;
public class odd {


 
		
		int i;
		Scanner ob=new Scanner(System.in);
		
		public void display(int a[]) {
			int c=0,sum=0;
			for(i=0;i<a.length;i++)
			{
				if(a[i]%2!=0)
				{
					c++;
					sum=sum+a[i];
				}
			}
			
			
				System.out.println(sum);
			System.out.println(c);
			
			
			
			
		}
	public static void main(String rags[]) {
		odd ob=new odd();
		int a[]= {1,2,3,4,5};
		ob.display(a);
		
	
	}


}
