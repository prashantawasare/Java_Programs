package codenreatraning;


//Q12.Wap input two array and merge in third array.
import java.util.*;
public class merging {
	
	int i;
	Scanner ob=new Scanner(System.in);
	
	public void result(int a[],int b[],int c[]) {
		
		for(i=0;i<a.length;i++) {
			c[i]=a[i];
		}
		for(i=0;i<b.length;i++) {
			c[a.length+i]=b[i];
		}
		for(i=0;i<c.length;i++) {
			
			System.out.println(c[i]);
			
			
			
		}
	}
	
	
	public static void main(String rgs[]) {
		merging ob=new merging();
		
		int a[]= {1,2,3,4,5};
		int b[]= {6,7,8,9,10};
		int c[]=new int[a.length+b.length];
		ob.result(a, b, c);
	}
	
	
	

}
