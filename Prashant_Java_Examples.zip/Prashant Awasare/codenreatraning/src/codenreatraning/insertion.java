package codenreatraning;

public class insertion {
	
	
	public static void main(String qs[])
	{
		
		int pos=1;
		int element=12;int i;
		int a[]= {1,2,3,4,5};
		for(i=a.length-1;i>pos-1;i--)
		{
			a[i]=a[i-1];
		}
		a[pos-1]=element;
		
		
		
		for(i=0;i<a.length;i++)
		{
			
			System.out.println(a[i]);
		}
				}

}
