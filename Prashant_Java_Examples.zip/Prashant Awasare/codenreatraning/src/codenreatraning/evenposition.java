package codenreatraning;

//Q8.Wap enter an array and print the element which is on even position.
import java.util.*;
public class evenposition {
	
	   int i;
	   Scanner ob=new Scanner(System.in);
	   
	   public void result(int a[]) {
		   
		   for(i=1;i<a.length;i=i+2) {
			   
			   System.out.println(a[i]+" ");
		   }
	   }
	   
	    
	   
	   public static void main(String args[]) {
		   int a[]= {1,2,3,4,5};
		   evenposition ob=new evenposition();
		   ob.result(a);
		  
	   }
	

}
