package codenreatraning;
import java.util.*;
public class checkpalindrome {
	
	public static void main(String args[])
	{
		Scanner ob=new Scanner(System.in);
		
		System.out.println("enter the value of n");
		int i=ob.nextInt();
		int rem,rev=0;
		int n=i;
		 while(i!=0) 

		   {  rem=i%10;

		    rev=rev*10+rem;
		  

		    
		     i=i/10;
		    
		      
		   
		}
		
		

		    
	    if(rev==n)
	    	System.out.println(" palindrome");
	    else
	    	System.out.println("not palindrome");
	}

}
