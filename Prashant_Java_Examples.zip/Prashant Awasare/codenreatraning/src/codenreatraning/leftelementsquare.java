
//Q9. WAP to replace all negative value with its immediate left elements square. Means
//     arr[] = [12, 3, -19, 29, 5, -61, 44, 7, -9] 
//     Output array will be [12, 3, 9, 29, 5, 25, 44, 7, 49].
package codenreatraning;
import java.util.Scanner;
public class leftelementsquare {
	
	
	int i,j;
	Scanner ob=new Scanner(System.in);
	
	public void result(int a[]) {
		
		for(i=0;i<a.length;i++) {
			
			 
				
				if(a[i]<=0) {
					a[i]=a[i-1]*a[i-1];
				}
			}
		
		for(i=0;i<a.length;i++) {
			System.out.println(a[i]+" ");
		}
		}
		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static void main(String args[]) {
		leftelementsquare ob=new leftelementsquare();
		int a[]= {12,3,-19,29,5,-61,44,7,-9};
		ob.result(a);
	}

}
