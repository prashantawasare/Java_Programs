//Q.7Wap enter an array and print the element which is on odd position.


	
    package codenreatraning;

	
	import java.util.*;
	public class oddposition {
		
		   int i;
		   Scanner ob=new Scanner(System.in);
		   
		   public void result(int a[]) {
			   
			   for(i=0;i<a.length;i=i+2) {
				   
				   System.out.println(a[i]+" ");
			   }
		   }
		   
		    
		   
		   public static void main(String args[]) {
			   int a[]= {1,2,3,4,5};
			   oddposition ob=new oddposition();
			   ob.result(a);
			  
		   }
		

	}



