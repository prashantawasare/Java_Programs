//.wap to create two method first is input(),and second is result().you have to find 
  //the area of circle by taking input by user with no  return type with no argument.

package codenreatraning;
import java.util.*;
public class areaofcircle {
	
	
	double pi;int r;
	double area;
	Scanner ob=new Scanner(System.in);
	
	public void input()
	{
		pi=ob.nextDouble();
		r=ob.nextInt();
		
	}
	public void result()
	{
		area=pi*r*r;
		System.out.println("area of circle"+area);
	}
	public static void main(String rags[])
	{
		areaofcircle ob=new areaofcircle();
		ob.input();
		ob.result();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
