
/*6-Write a program that would print the information (name, year of joining, salary, address) 
  of three employees by creating a class named 'Employee'. 
   The output should be as follows,
         Name        Year of joining        Address
        abcd            1994               aaaaaaa
         xyz               2000             aaaaaa   
         pqr                1999            aaaaaaa */

package codenreatraning;

public class information {
	
	public void result()
	{
		System.out.println("Name"+"\tYear of joining"+"\t\tAddress");
		System.out.println("Prasant"+"\t\t2016"+"\t\tPune");
		System.out.println("Pratap"+"\t\t2017"+"\t\tNashik");
	    System.out.println("Aksahy"+"\t\t2019"+"\t\tMumabai");
	}
public static void main(String args[])
{
	information ob=new information();
	ob.result();
	
}
}
