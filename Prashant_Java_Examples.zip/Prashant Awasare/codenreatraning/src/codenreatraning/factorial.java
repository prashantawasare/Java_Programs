package codenreatraning;

import java.util.*;

public class factorial {
	
    
	public static void main(String sjd[])
	{
		
		
	Scanner ob=new Scanner(System.in);
	
	
	
	int a,i,fact;
	System.out.println("enter the number");
	a=ob.nextInt();
	fact=1;
	for(i=1;i<a;i++)
	{
		
		fact=fact*i;
	
	System.out.println(fact);
	}

}
}
