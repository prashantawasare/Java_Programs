package codenreatraning;

//Q6.Wap enter an array and find the duplicate element and also count of that.
import java.util.*;
public class duplicateelement {
	
	int i,j,c=0;
	
	Scanner ob=new Scanner(System.in);
	
	public void result(int a[]) {
		
		for(i=0;i<a.length;i++) 
		{
			   
			for(j=i+1;j<a.length;j++)
			{
				
				if(a[i]==a[j]) {
				
				
				System.out.println(a[j]+"");
			     c++;
			}
			}
			
			
		}
	  System.out.println("count of duplicate element  "+c);
		
		
	
		
	}
	

	public static void main(String args[]) {
		duplicateelement ob=new duplicateelement();
		int []a= {1,2,3,3,4,4,5,5,6,7};
		ob.result(a);
	}
}
