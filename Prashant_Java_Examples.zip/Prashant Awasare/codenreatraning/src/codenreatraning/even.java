//Q1.Wap enter an array and find the sum and count of even element.
package codenreatraning;
import java.util.*;
public class even {
	
	int i;
	Scanner ob=new Scanner(System.in);
	
	public void display(int a[]) {
		int c=0,sum=0;
		for(i=0;i<a.length;i++)
		{
			if(a[i]%2==0)
			{
				c++;
				sum=sum+a[i];
			}
		}
		
		
			System.out.println(sum);
		System.out.println(c);
		
		
		
		
	}
public static void main(String rags[]) {
	even ob=new even();
	int a[]= {1,2,3,4,6};
	ob.display(a);
	
}
}
