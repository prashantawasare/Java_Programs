
1.wap to create four method add() sub() multiply()divide()and calculation in ecah method by no return by no argument.
package codenreatraning;
import java.util.Scanner;
public class first {
	
	int a,b;
	int sum,sub,mul;double div;
	Scanner ob=new Scanner(System.in);
	
	public void input()
	{
		System.out.println("enter a number");
		a=ob.nextInt();
		b=ob.nextInt();
		
	}
	public void sum()
	{
		sum=a+b;
	}
	public void sub()
	{
	 sub=a-b;
	 
	   }
	public void mul()
	{
		mul=a*b;
	}
	public void div()
	{
		div=a/b;
	}
	public void display()
	{
		System.out.println("sum="+sum);
		System.out.println("sub="+sub);
		System.out.println("mul="+mul);
		System.out.println("div="+div);

	}
	public static void main(String args[])
	{
		first ob=new first();
		ob.input();
		ob.sum();
		ob.sub();
		ob.div();
		ob.display();
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
