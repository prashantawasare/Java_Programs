wap to print the count of odd numbres

package codenreatraning;
import java.util.*;
public class countodd2 {
	int a,n,c=0;
	int i;
	Scanner ob=new Scanner(System.in);
	
	public void input()
	{
		System.out.println("enter the starting number");
		a=ob.nextInt();
		System.out.println("enter the last number");
		n=ob.nextInt();
		
		
	}
	public void findcount()
	{
	   for   (i=0;i<=n;i++)
		{
			if(i%2!=0)
			c++;
				
			
		}
	}
	public void display()
	{
		System.out.println("count of odd numbers betwwen 1 to n="+c);
		
	}
	public static void main(String ags[])
	{
		countodd2 ob=new countodd2();
		ob.input();
		ob.findcount();
		ob.display();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
