
//Q3. WAP to replace all the 0’s with 1’s in your array. Your array is [26, 0, 67, 45, 0, 78, 
//    54, 34, 10, 0, 34] 
package codenreatraning;
import java.util.*;
public class replace {
	
	int i;
	Scanner ob=new Scanner(System.in);
	public void display(int a[]) {
		
		for(i=0;i<a.length;i++) {
			
			if(a[i]==0) {
				a[i]=1;
			}
				
		}
		
		for(i=0;i<a.length;i++) {
			
			System.out.println(a[i]);
		}
	}
	
	
public static void main(String args[]) {
	replace ob=new replace();
	int a[]= {26,0,67,45,0,78,54,34,10,0,34};
	ob.display(a);
}
}
