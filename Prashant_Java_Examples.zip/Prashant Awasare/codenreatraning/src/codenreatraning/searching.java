//Q4.Wap enter an array and search any particular element and find the count.
package codenreatraning;
import java.util.*;
public class searching {
	
	int i;
	Scanner ob=new Scanner(System.in);
	
	public void display(int a[]) {
		 int k=5;int c=0;
		for(i=0;i<a.length;i++)
		{
			if(k==a[i])
				c++;
		}
		System.out.println("number found="+k);
		System.out.println("count of numbers="+c);
		
	}
	
	
	
	
	
	
	
	public static void main(String args[]) {
		
		searching  ob=new searching();
		int a[]= {1,2,3,4,5};
		ob.display(a);
	}

}
