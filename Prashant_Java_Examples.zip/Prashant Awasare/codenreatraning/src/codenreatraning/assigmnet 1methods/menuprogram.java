package codenreatraning;

import java.util.Scanner;

public class menuprogram {
	
	
	int n,radius=4,sidea=4,height=4,base=3,length=5,breadth=6,areaofsquare,areaofreactangle;
	double pi=3.14,areaofcircle,areaoftraingle;
	Scanner ob=new Scanner(System.in);
	public void input()
	{
		areaofcircle=pi*radius*radius;
		areaofsquare=sidea*sidea;
		areaofreactangle=length*breadth;
		areaoftraingle=(height*base)/2;
		System.out.println("enter your choice");
		n=ob.nextInt();
		switch(n)
		{
		case 1:
		
		System.out.println("are of cirle="+areaofcircle);
		break;
		
		case 2:
		
		System.out.println("areaofsquar"+areaofsquare);
		break;
		case 3:
		System.out.println("areaofreactangle"+areaofreactangle);
		break;
		case 4:
		System.out.println("area of traingle"+areaoftraingle);
		break;
		default:
		System.out.println("wrong input");
		break;
		
			
	}
	}
	
	public static void main(String ars[])
	{
		menuprogram ob=new menuprogram();
		ob.input();
		
	}

}


