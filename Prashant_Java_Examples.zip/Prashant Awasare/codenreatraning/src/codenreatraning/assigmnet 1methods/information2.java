package codenreatraning;
import java.util.*;
public class information2 {
	
	int rollnum,phonenumber;
	int rollnum2,phonenumber2;

	String address,adress;
	Scanner ob=new Scanner(System.in);
	
	public void input()
	{
		System.out.println("enter roll number of first student");
		rollnum=ob.nextInt();
		System.out.println("enter phone number of first student");
		phonenumber=ob.nextInt();
		System.out.println("enter the address of first student");
		address=ob.next();
		System.out.println("enter roll number of second student");
		rollnum2=ob.nextInt();
		System.out.println("enter phone number of second student");
        phonenumber2=ob.nextInt();
		System.out.println("enter the address of second student");
		adress=ob.next();
	}
	public void dispaly()
	{
		System.out.println("information about student");
		System.out.println("Name"+"\troll number"+"\tphone number"+"\taddress");
		 System.out.println("Shyam"+"\t"+rollnum+"\t\t"+phonenumber+"\t\t"+address);
		 System.out.println("Jhon"+"\t"+rollnum2+"\t\t"+phonenumber2+"\t\t"+adress);
		 
	}
	public static void main(String ars[])
	{
		information2 ob=new information2();
		ob.input();
		ob.dispaly();
	}
	

}
