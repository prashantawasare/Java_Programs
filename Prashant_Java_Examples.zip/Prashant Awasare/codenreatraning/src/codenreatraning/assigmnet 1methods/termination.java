package codenreatraning;
import java.util.Scanner;
public class termination {
	

	


		
		
		int n,radius=4,sidea=4,height=4,base=3,length=5,breadth=6,areaofsquare,areaofreactangle;
		char ch;
		double pi=3.14,areaofcircle,areaoftraingle;
		Scanner ob=new Scanner(System.in);
		
				public void input()
		{
			
			
			
			
			do
			{	
				
				System.out.println("enter your choice");
		     	n=ob.nextInt();
		     
			
			switch(n)
			{
			case 1:
				areaofcircle=pi*radius*radius;
			System.out.println("are of cirle="+areaofcircle);
			break;
			
			case 2:
				areaofsquare=sidea*sidea;
			System.out.println("areaofsquar"+areaofsquare);
			break;
			case 3:
				areaofreactangle=length*breadth;
			System.out.println("areaofreactangle"+areaofreactangle);
			break;
			case 4:

				areaoftraingle=(height*base)/2;
			System.out.println("area of traingle"+areaoftraingle);
			break;
			default:
			System.out.println("wrong input");
			break;
			}
			
			System.out.println("enter y to terminate or press any letter to continue");
			  ch=ob.next().charAt(0);	
		
			}while(ch=='z');
		}
		
		
		public static void main(String ars[])
		{
		
			System.out.println("*******Menu program********");
			System.out.println("1.Area of circle"+"\n2.Area of reactangle"+"\n3.Area of square"+"\n4.Area of triangle ");
			
		

			menuprogram ob=new menuprogram();
		   
			ob.input();
			
			
		}

	}





