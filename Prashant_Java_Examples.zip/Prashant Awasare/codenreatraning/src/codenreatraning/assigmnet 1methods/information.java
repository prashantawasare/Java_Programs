package codenreatraning;

public class information {
	
	public void result()
	{
		System.out.println("Name"+"\tYear of joining"+"\t\tAddress");
		System.out.println("Prasant"+"\t\t2016"+"\t\tPune");
		System.out.println("Pratap"+"\t\t2017"+"\t\tNashik");
	    System.out.println("Aksahy"+"\t\t2019"+"\t\tMumabai");
	}
public static void main(String args[])
{
	information ob=new information();
	ob.result();
	
}
}
