package codenreatraning;
import java.util.*;
public class palindromeseries {
	
	int i,j=i,n,rem,rev=0;
	Scanner x=new Scanner(System.in);


    
    
    public void palindromeserie()
    {
        
        while(i<=100)
        {
            j=i;rev=0;
            while(j!=0)
            {
            	rem=j%10;
            	rev=rev*10+rem;
             j=j/10;
             
                }
            
            
            if(i==rev)
                System.out.print(i+" ");
            
            
               i++;                 
            
        }
        
        
        
        
    }
    
    
public static void main(String args[])
{
	palindromeseries  x= new palindromeseries();
    
    x.palindromeserie();
       
    
}
     



}
	


