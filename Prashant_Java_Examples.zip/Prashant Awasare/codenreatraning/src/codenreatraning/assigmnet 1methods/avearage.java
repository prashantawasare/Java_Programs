package codenreatraning;
import java.util.*;
public class avearage {
	
	int a,b,c;
	double average;
	Scanner ob=new Scanner(System.in);
	
	public void input()
	{
		System.out.println("enter first number");;
		a=ob.nextInt();
		System.out.println("enter first number");;
		b=ob.nextInt();
		System.out.println("enter first number");;
		b=ob.nextInt();
		
	}
	public void result() 
	
	{
		average=(a+b+c)/3;
		System.out.println("aveage of first three numbers"+average);
		
	}
	public static void main(String rsgs[])
	{
		avearage ob=new avearage();
		ob.input();
		ob.result();
		
	}
	
	
	

}
