package codenreatraning;

public class pattern 
{
	
	  public static void main(String args[])
	{
	  int i,j;
	for(i=1;i<=9;i++)
	{
	 for(j=i;j<=9;j++)
	 System.out.print(" ");
	 for(j=1;j<=i;j++)
	  

	  if(j==i || j==1 )
	  System.out.print(" *");
	 else
	 System.out.print("  ");
	  

	  System.out.println();

	     }


	   for(i=9;i>=1;i--)
	{
	 for(j=i;j<=9;j++)
	 System.out.print(" ");
	 for(j=1;j<=i;j++)
	  

	  if( j==i || j==1 )
	  System.out.print(" *");
	 else
	 System.out.print("  ");
	  

	  System.out.println();}
	  }
	}

