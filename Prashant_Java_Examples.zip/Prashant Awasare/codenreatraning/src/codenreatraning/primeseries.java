//write a program to print prime series

package codenreatraning;
import java.util.*;
public class primeseries {
	
	int i,n=100,j=2;
	Scanner ob=new Scanner(System.in);
	
	public void result()
	{
		for(i=1;i<=100;i++)
		{
			for(j=2;j<=i;j++)
			{
				if(i%j==0)
				break;
			}if(i==j)
				System.out.println(i+" ");
			
			
		}
	}
	
public static void main(String args[])
{
	primeseries ob=new primeseries();
	
	ob.result();
}
}
