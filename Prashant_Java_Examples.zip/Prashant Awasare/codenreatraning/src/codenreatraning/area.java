//1.wap to create two method first is input(),and second is result().you have to find 
 // the area of circle by taking input by user with no  return type with no argument.

package codenreatraning;
import java.util.*;
public class question1 {
	
	
	int radius=4,sidea=4,height=4,base=3,length=5,breadth=6,areaofsquare,areaofreactangle;
	double pi=3.14,areaofcircle,areaoftraingle;
	Scanner ob=new Scanner(System.in);
	public void result()
	{
		areaofcircle=pi*radius*radius;
		areaofsquare=sidea*sidea;
		areaofreactangle=length*breadth;
		areaoftraingle=(height*base)/2;
		
	}
	public void display()
	{
		System.out.println("are of cirle="+areaofcircle);
		System.out.println("areaofsquar"+areaofsquare);
		System.out.println("areaofreactangle"+areaofreactangle);
		System.out.println("areaoftraingle"+areaoftraingle);
	}
	public static void main(String ars[])
	{
		area ob=new area();
		ob.result();
		ob.display();
	}

}
