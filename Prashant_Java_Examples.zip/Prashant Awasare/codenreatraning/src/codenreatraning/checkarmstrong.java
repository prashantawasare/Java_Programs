package codenreatraning;
import java.util.*;
public class checkarmstrong {
	
	public static void main(String args[])
	{
		int i,n;
		Scanner ob=new Scanner(System.in);
		System.out.println("enter the number");
		 n=ob.nextInt();
		
	


	      
	      i=n;int c=0;
	   while(i!=0)
	{
	   i=i/10;
	   c++;
	    }int sum=0;i=n;int rem;
	  while(i!=0)
	{
	   rem=i%10;
	   sum=sum+(int)Math.pow(rem,c);
	 i=i/10;  }
	 if(n==sum)
	 System.out.println("armstronng");
	 else
	  System.out.println("not armstrong");
	}
		
	
	


}
