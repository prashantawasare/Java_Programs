//Q5.WAP to check if an array of integers contains two specified elements. 
package codenreatraning;
import java.util.*;
public class search2numbers {

	int i,p,t,k,r;
	Scanner ob=new Scanner(System.in);
	
	
	public void input(int a[]) {
		System.out.println("enter an array");
		for(i=0;i<a.length;i++) {
			
		
		
		a[i]=ob.nextInt();
		}
		System.out.println("enter element you want tto seach");
		k=ob.nextInt();
		r=ob.nextInt();
		
	}
	
	public  void display(int a[]) {
		
		for(i=0;i<a.length;i++) {
			if(k==a[i]) {
				p=1;
			}
			if(r==a[i]) {
				t=1;
			}
			
		}
		
		
	

	
    if(p==1 && t==1) {
	System.out.println("both number are found");}
	else if(p!=1 && t==1) {
		System.out.println("only t is found");}
		else if(p==1 && t!=1) {
			System.out.println("only p is found");}
			else if(p!=1 && t!=1) {
				System.out.println(" both numbers are not found");
			}
		
		
	
	}
	
	
	
	
	
	
	
	public static void main(String args[]) {
		search2numbers ob=new search2numbers();
		int n=5;
		int a[]=new int[n];
		ob.input(a);
		ob.display(a);
	}
}
