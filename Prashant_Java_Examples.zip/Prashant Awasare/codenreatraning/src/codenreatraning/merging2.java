package codenreatraning;

//Q13.a[]={10,20,30,40,50}
//   b[]={1,2,3,4,5}
 
//  output array=c[]={10,5,20,4,30,3,40,2,50,1}
import java.util.*;
public class merging2 {
	
	int i,h;
	
	Scanner ob=new Scanner(System.in);
	
	
	public void result(int a[],int b[],int c[]) {

		Scanner ob=new Scanner(System.in);
		int i;
		
		int k=b.length-1;int p=0;
		for(i=0;i<a.length;i++)
		{
			c[p++]=a[i];
			c[p++]=b[k--];
			
		}
		for(i=0;i<c.length;i++)
		{
			System.out.println(c[i]);
		}
		
		
		
	}
			
			
			
			
			
			
	public static void main(String args[]) {
		merging2 ob=new merging2();
		int a[]= {10,20,30,40,50};
		int b[]= {1,2,3,4,5};
		int c[]=new int[a.length+b.length];
		ob.result(a, b, c);
		
	}
	

}
