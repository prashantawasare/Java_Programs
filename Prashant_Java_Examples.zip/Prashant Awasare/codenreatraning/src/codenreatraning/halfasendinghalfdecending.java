package codenreatraning;

//Q14.Wap sort half array in accending and half in decending order
 //   input= int [] a={9,1,3,5,6,11,22,66,10,19}.
//    output={1,3,5,6,9,10,66,22,19,11,10},
import java.util.*;
public class halfasendinghalfdecending {
	
	int i,k,j;
	Scanner ob=new Scanner(System.in);
	public void result(int a[])
	{
		for(i=0;i<a.length/2;i++)
		{
			for(j=i+1;j<a.length/2;j++)
			{
				if(a[i]>a[j])
				{
					k=a[i];
					a[i]=a[j];
					a[j]=k;
				}
			}
		}
			for(i=0;i<a.length/2;i++)
			{
				System.out.println(a[i]+" ");
			}
			for(i=a.length/2;i<a.length;i++)
			{
				for(j=a.length/2;j<a.length;j++)
				{
					if(a[i]<a[j])
					{
						k=a[i];
						a[i]=a[j];
						a[j]=k;
					}
				}
			}
				for(i=a.length-1;i>=a.length/2;i--)
				{
					System.out.println(a[i]+" ");
				}
		
		
		}
	
	
	
	
	public static void main(String  arf[]) {
		halfasendinghalfdecending ob=new halfasendinghalfdecending();
		
		int a[]= {9,1,3,5,6,11,22,66,10,19};
		ob.result(a);
	
	}
	

}
