package codenreatraning;
//Q11.Wap enter an array and print it in reverse order.
import java.util.*;
public class reverseorder {
	
	
	int i;
	Scanner ob=new Scanner(System.in);
	
	public void result() {
		
		for(i=a.length-1;i>=0;i--) {
			
			System.out.println(a[i]+" ");
		}
		
		
	
	  }
	public static void main(String args[]) {
		reverseorder ob=new reverseorder();
		int a[]= {1,2,3,4,5};
		ob.result();
	}


}