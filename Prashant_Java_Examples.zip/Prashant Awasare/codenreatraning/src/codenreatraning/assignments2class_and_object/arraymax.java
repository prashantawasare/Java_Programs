package codenreatraning.assignments2class_and_object;
import java.util.*;
public class arraymax {
	
	
	int a[]=new int[10];
	int i,j,k=0;
	Scanner ob=new Scanner(System.in);
	
  public void input()
  {  System.out.println("enter the array");
    for(i=0;i<a.length;i++)
	  a[i]=ob.nextInt();
	  
  }
  public void result() 
	  
  {	  k=0;
	  for(i=0;i<a.length;i++)
	  {
		 for(j=i+1;j<a.length-1;j++)
		 { 
			  
		     if(a[i]>a[j])
		     { k=a[i];
		    	 a[i]=a[j];
		    	 a[j]=k;
		     }
		 }
	  }
		   
			  System.out.println("max number"+a[a.length-1]);
			  System.out.println("min number"+a[0]);
			   
		   
	  
	  
	   
  }
  
  public static void main(String args[])
  {
	  arraymax ob=new arraymax();
	  ob.input();
	  ob.result();
	  
  }
  }

