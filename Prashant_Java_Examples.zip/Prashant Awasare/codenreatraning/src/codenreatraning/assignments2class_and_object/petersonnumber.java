package codenreatraning.assignments2class_and_object;
import java.util.*;
public class petersonnumber {
	
	int i,j;int n;int rem,fact,sum;
	Scanner ob=new Scanner(System.in);
	
	public void input()
	{
		
		System.out.println("enter the number");
		i=ob.nextInt();
	}
	
	public void result()
	{n=i;sum=0;
		for(n=i;i!=0;i=i/10)
		{
			rem=i%10;
			fact=1;
			
			for(j=1;j<=rem;j++)
			{
				fact=fact*j;
			}
			sum=sum+fact;
		}
		
		if(sum==n)
			System.out.println("it is peterson number");
		else
			System.out.println("it is not peterson number");
	}
	
	public static void main(String arfs[])
	{
		petersonnumber ob=new petersonnumber();
		ob.input();
		ob.result();
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
