package interviewquestion;
import java.util.*;
public class question3 {
	
	public static void main(String ags[])
	{
		Scanner ob=new Scanner(System.in);
		int i,k=0;int a[]=new int[5];
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
		}
		
	
	
	
		
		for(i=0;i<a.length;i++)
		{
			if(a[i]>k)
				k=a[i];
		}
		
		System.out.println(k);
	}

}
