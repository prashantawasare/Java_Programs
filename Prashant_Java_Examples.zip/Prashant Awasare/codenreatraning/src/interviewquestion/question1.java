package interviewquestion;

import java.util.Scanner;

public class question1 {
	
	
	public static void main(String rags[])
	{
		int i;int a[]=new int[6];
		Scanner ob=new Scanner(System.in);
		

		
			for(i=0;i<a.length;i++)
			{
				a[i]=ob.nextInt();
			}
		
		
		  System.out.println(" second max elemet");
			for(i=0;i<a.length;i++);
			{
				System.out.println(a[a.length-2]);
			}
		}
		
	}


