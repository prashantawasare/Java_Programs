package interviewquestion;

import java.util.Scanner;

public class question2 {
	
	public static void main(String args[])
	
	{
		int i;int a[]= {1,2,3,4,5};
		Scanner ob=new Scanner(System.in);
		
	
			
			for(i=a.length-1;i>=0;i--) {
				
				System.out.println(a[i]+" ");
			}
			
			
		
		  }
	}


