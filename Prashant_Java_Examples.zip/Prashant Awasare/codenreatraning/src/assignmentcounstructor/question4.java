package assignmentcounstructor;

import java.util.Scanner;

//Q4.WAP tt enter a no and check it is pelindrome or not?
public class question4 {
	
	
	   int i,j,n,rem,rev;
	Scanner ob=new Scanner(System.in);
	question4()
	{
		System.out.println("enter the value of number");
		i=ob.nextInt();
		
		j=i;rev=0;
		while(j!=0)
		{
			rem=j%10;
			rev=rev*10+rem;
			j=j/10;
			
		}
		
			
		
	}
	
	public void display()
	
	{if(rev==i)
		System.out.println("palindrome");
	else
		System.out.println(" not palindrome");
	}
	

	
	public static void main(String args[])
	
	{
		question4 ob=new question4();
		ob.display();
	}
	

}
