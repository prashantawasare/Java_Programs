package assignmentcounstructor;

/*Q15. How do you find the largest and smallest number in an unsorted integer array size 10. 
 input in constructor and final result through the method.*/
import java.util.*;
public class question15 {
	
	int i,j,k;int a[]=new int[10];
	Scanner ob=new Scanner(System.in);
	
	
	question15()
	{
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
			
		}
	}
	
	
	public void result() 
	  
	  {	  k=0;
		  for(i=0;i<a.length;i++)
		  {
			 for(j=i+1;j<a.length-1;j++)
			 { 
				  
			     if(a[i]>a[j])
			     { k=a[i];
			    	 a[i]=a[j];
			    	 a[j]=k;
			     }
			 }
		  }
			   
				  System.out.println("max number"+a[a.length-1]);
				  System.out.println("min number"+a[0]);
				   
	  }
	public static void main(String aggs[])
	{
		question15 ob=new question15();
		ob.result();
		
	}

}
