package assignmentcounstructor;
//Q2.Wap enter 5 digit  no and print only even no.

import java.util.Scanner;

public class question2 {


	   int i,j,n,rem,rev;
	Scanner ob=new Scanner(System.in);
	question2()
	{
		System.out.println("enter the value of number");
		i=ob.nextInt();
		
		j=i;rev=0;
		while(j!=0)
		{
			rem=j%10;
		    
			
			
		
		
		if(rem%2==0)
			System.out.println("even numbers"+rem);	
		j=j/10;
		}
	}
	
	
	
	

	
	public static void main(String args[])
	
	{
		question2 ob=new question2();
		
	}
	
	
}
