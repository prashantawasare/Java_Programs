package assignmentcounstructor;

/*Q13. . Write a program to sort the 10 elements from array. 
 input in constructor and final result through the method.*/
import java.util.*;
public class question13 {
	int a[]=new int[10];int i,k,j;
	Scanner ob=new Scanner(System.in);
	question13()
	{
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
		}
		
	}
	
	public void result()
	{
		for(i=0;i<a.length;i++) 
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					k=a[i];
					a[i]=a[j];
					a[j]=k;
				}
			}
			
			
		}
		System.out.println("sorting");
		for(i=0;i<a.length;i++)
		{
			 System.out.println(a[i]+" ");
		}
	}
	public static  void main(String ags[])
	{
		question13 ob=new question13();
		ob.result();
		
	}

}
