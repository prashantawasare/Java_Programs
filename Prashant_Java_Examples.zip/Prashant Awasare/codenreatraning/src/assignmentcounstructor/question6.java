package assignmentcounstructor;

import java.util.Scanner;

//Q6.Wap print all even no between 1 to n and find the count.
public class question6 {
	

	 int i,n,c;
		Scanner ob=new Scanner(System.in);
		question6()
		{
			c=0;n=100;
			for(i=1;i<=n;i++)
			{	
				if(i%2==0)
				{	System.out.println(i);
					c++;}
			   
			}
			
				
				System.out.println("count numbers of even numbers"+c);
			
			
			
			
			
		}
		
		

		
		public static void main(String args[])
		
		{
			question6 ob=new question6();
			

}

}
