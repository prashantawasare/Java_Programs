package assignmentcounstructor;

import java.util.Scanner;

/*Q12. WAP In java Reverse the array 
 input in constructor and final result through the method. */
public class question12 {
	
	int i,j;int a[]=new int[10];
	Scanner  ob=new Scanner(System.in);
	
	question12()
	{
		for(i=0;i<a.length;i++)
		
			
		
		a[i]=ob.nextInt();
		
		
		
	}
	public void  result() 
	{
		
		System.out.println( "print in reverse order");
		for(i=a.length-1;i>=0;i--)
		{
			System.out.println(a[i]+" ");
			
		}
	}
	
	public static void main(String args[])
	{
		question12 ob=new question12();
		ob.result();
	}


}
