package assignmentcounstructor;
//Q10.Wap input a no and print factorial.
import java.util.*;
public class question10 {
	
	
	int i,fact,n;
	Scanner ob=new Scanner(System.in);
	question10()
	{
		System.out.println("enter the value of n");
		n=ob.nextInt();
	}
	public void result()
	{    fact=1;
		for(i=1;i<=n;i++)
		{
			fact=fact*i;
		
		}
		System.out.println(fact+" ");
	}
	
	
	public static void main(String ras[])
	{
		question10 ob=new question10();
		ob.result();
	}

}
