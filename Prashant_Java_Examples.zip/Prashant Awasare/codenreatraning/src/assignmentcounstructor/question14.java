package assignmentcounstructor;

import java.util.Scanner;

//Q14..Find the duplicate from the elements Size of array will be 10; 
//input in constructor and final result through the method.
import java.util.*;
public class question14 {
	
int i,j,c=0;int a[]=new int[10];
	
	Scanner ob=new Scanner(System.in);
	
	question14()
	{
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
		}
	}
	
	public void result()
	{
		System.out.println("duplicates elements in array");
		for(i=0;i<a.length;i++)
		{
			   
			for(j=i+1;j<a.length;j++)
			{
				
				if(a[i]==a[j])
				{
				
				
				System.out.println(a[j]+"");
			    
			}
			}

       }
	}
	
	public static void main(String ags[])
	{
		question14 ob=new question14();
		ob.result();
		
	}
}
