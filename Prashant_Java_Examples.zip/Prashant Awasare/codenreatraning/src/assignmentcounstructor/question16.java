package assignmentcounstructor;
//Q16.Wap replace 0's from the square of  the next element of array using constructor.
//your array is-{2,0,4,8,0,5,0,5,8};
import java.util.*;
public class question16 {
	
	
	int i;int a[]= {2,0,4,8,0,5,5,8};
	Scanner ob=new Scanner(System.in);
	
	question16()
	{
		for(i=0;i<a.length;i++)
		{
			if(a[i]==0)
			{
				a[i]=a[i+1]*a[i+1];
			}
		}
		
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]+" ");
			
			
		}
	}
	
	
	public static void main(String rfs[])
	{
		question16 ob=new question16();
	}

}
