package assignmentcounstructor;
//Q17.Wap to input an array and find the 2nd max element using constructor.
import java.util.*;
public class question17 {
	
	
	int i;int a[]=new int[6];
	Scanner ob=new Scanner(System.in);
	
	question17()
	{
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
		}
	}
	
	public void result()
	{   System.out.println(" second max elemet");
		for(i=0;i<a.length;i++);
		{
			System.out.println(a[a.length-2]);
		}
	}
	
	public static void main(String ags[])
	{
		question17 ob=new question17();
		ob.result();
	}
	

}
