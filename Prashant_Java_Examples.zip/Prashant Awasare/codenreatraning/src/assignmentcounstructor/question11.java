package assignmentcounstructor;
/*Q11.Take 10 integer inputs from user and store them in an array. Now, copy all the 
elements in an another array,finally print copied array but in reverse order.  
input in constructor and print final result through the method.*/
import java.util.*;
public class question11 {
	
	int i,j;int a[]=new int[10];int b[]=new int[a.length];
	Scanner  ob=new Scanner(System.in);
	question11()
	{
		for(i=0;i<a.length;i++)
		{
			
		
		a[i]=ob.nextInt();
		}
		
		
	}
	public void result()
	
	{
		
		for(i=0;i<a.length;i++)
		{
	      b[i]=a[i];
		}
		System.out.println("copied array from a and print in reverse order");
		for(i=a.length-1;i>=0;i--)
		{
			System.out.println(b[i]+" ");
			
		}
	}
	
	public static void main(String args[])
	{
		question11 ob=new question11();
		ob.result();
	}

}
