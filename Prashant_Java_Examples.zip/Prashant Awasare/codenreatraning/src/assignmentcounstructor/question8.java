package assignmentcounstructor;
//Q8.Write a program to find power of a number using for loop.
import java.util.*;
public class question8 {
	
	int n,c,d;
	Scanner ob=new Scanner(System.in);
	question8()
	{
		System.out.println("enter the value of n");
		n=ob.nextInt();
		System.out.println("enter the power");
		c=ob.nextInt();
		d=(int)Math.pow(n, c);
		System.out.println(d);
	}
	

	
	public static void main(String ats[])
	
	{
		question8 ob=new question8();
	}

}
