package assignmentcounstructor;
//Q5.Wap print all pelindrome no between 10 to 200.
import java.util.*;
public class question5 {
	
	 int i,j,n,rem,rev;
		Scanner ob=new Scanner(System.in);
		question5()
		{
			
			for(i=10;i<=200;i++)
			{		
			  j=i;rev=0;
			while(j!=0)
			{
				rem=j%10;
				rev=rev*10+rem;
				j=j/10;
				
			}
			if(rev==i)
				System.out.println(i);
			}
			
			
			
			
		}
		
		

		
		public static void main(String args[])
		
		{
			question5 ob=new question5();
			

}
}
