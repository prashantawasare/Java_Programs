package assignmentcounstructor;
//Q3.Wap enter 5 digit  no and print only odd no.
import java.util.Scanner;

public class question3 {
	 int i,j,n,rem;
		Scanner ob=new Scanner(System.in);
		question3()
		{
			System.out.println("enter the value of number");
			i=ob.nextInt();
			
			j=i;
			while(j!=0)
			{
				rem=j%10;
			    
				
				
			
			
			if(rem%2!=0)
				System.out.println("odd numbers"+rem);	
			j=j/10;
			}
		}
		
		
		
		

		
		public static void main(String args[])
		
		{
			question3 ob=new question3();
			
		}
		

}
