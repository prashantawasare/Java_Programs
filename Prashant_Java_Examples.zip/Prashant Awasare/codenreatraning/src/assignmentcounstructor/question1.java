package assignmentcounstructor;
//Q1.Wap enter and print its reverse no.
import java.util.*;
public class question1 {
	
	
	
	   int i,j,n,rem,rev;
	Scanner ob=new Scanner(System.in);
	question1()
	{
		System.out.println("enter the value of number");
		i=ob.nextInt();
		
		j=i;rev=0;
		while(j!=0)
		{
			rem=j%10;
			rev=rev*10+rem;
			j=j/10;
			
		}
		
			
		
	}
	
	public void display()
	
	{
		System.out.println("reverse number"+rev);
	}
	

	
	public static void main(String args[])
	
	{
		question1 ob=new question1();
		ob.display();
	}
	
	
}
