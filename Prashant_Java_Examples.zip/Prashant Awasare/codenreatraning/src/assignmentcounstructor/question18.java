package assignmentcounstructor;

import java.util.Scanner;

//Q18.Wap to input an array and find the 2nd min element using constructor.
public class question18 {
	
	int i;int a[]=new int[6];
	Scanner ob=new Scanner(System.in);
	
	question18()
	{
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
		}
	}
	
	public void result()
	{   System.out.println(" second min elemet");
		for(i=0;i<a.length;i++);
		{
			System.out.println(a[1]);
		}
	}
	
	public static void main(String ags[])
	{
		question18 ob=new question18();
		ob.result();
	}
	

}
