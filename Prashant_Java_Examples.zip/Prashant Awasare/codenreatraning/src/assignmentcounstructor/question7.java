package assignmentcounstructor;

import java.util.Scanner;

//Q7.Wap print all odd no between 1 to n and find the count.
public class question7 {
	
	int i,n,c;
	Scanner ob=new Scanner(System.in);
	question7()
	{
		c=0;n=100;
		for(i=1;i<=n;i++)
		{	
			if(i%2!=0)
			{	System.out.println(i);
				c++;}
		   
		}
		
			
			System.out.println("count numbers of odd numbers"+c);
		
		
		
		
		
	}
	
	

	
	public static void main(String args[])
	
	{
		question7 ob=new question7();
		

}


}
