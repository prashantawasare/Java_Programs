package assignmentcounstructor;
//Q9.Wap print all prime no between 1 to 100.
public class question9 {
	
	
	int i,j;
	
	
	question9()
	
	{
		       for(i=1;i<=100;i++)
		       {
					for(j=2;j<i;j++) 
				{
					if(i%j==0)
						break;
					
				}
				if(i==j)
					System.out.println(i);
		       }
	}
	
	public static void main(String args[])
	{
		question9 ob=new question9();
		
	}

}
