
public class frquency {
	
	
	public static void main(String sdf[]) {
		
		
		int i,j;
	    int a[]= {1, 2, 1, 2, 5};
	    int b[]=new int [a.length];
	    int p=-1;
	   int c=1;
		for(i=0;i<a.length;i++)
	    {
		c=1;
		for(j=i+1;j<a.length;j++)
	   {
		if(a[i]==a[j])
		{
		  c++;
		 b[j]=p;
			}
	   }
		
		if(b[i]!=p)
		  b[i]=c;
	    }	 
	   
		
			  
		for(i=0;i<a.length;i++)
		{
			 if(b[i]!=p)
		{
			
			 System.out.println(a[i]+"="+b[i]); 
				  }
				  
			  }
	
		
	}

	}
