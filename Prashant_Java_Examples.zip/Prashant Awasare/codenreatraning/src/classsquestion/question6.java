package classsquestion;
//Q12.Wap input two array and merge in third array.
import java.util.*;
public class question6 {
	
	int i;
	Scanner ob=new Scanner(System.in);
	
	public void input(int a[],int b[])
	{
		System.out.println("a array");
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
		}
		System.out.println("b array");
		for(i=0;i<b.length;i++)
		{
			b[i]=ob.nextInt();
		}
		
		
	}
	
	public void result(int a[],int b[],int c[])
	{
		for(i=0;i<a.length;i++)
		{
			c[i]=a[i];
		}
		
		for(i=0;i<b.length;i++)
		{
			c[a.length+i]=b[i];
		}
		System.out.println("merging of two array");
		for(i=0;i<c.length;i++)
		{
			System.out.println(c[i]);
		}
	}
	
	public static void main(String args[]) 
	{
		int a[]=new int[5];
		int b[]=new int[6];
		int c[]=new int[a.length+b.length];
		 question6 ob=new  question6();
		 ob.input(a, b);
		 ob.result(a, b, c);
	}

}
