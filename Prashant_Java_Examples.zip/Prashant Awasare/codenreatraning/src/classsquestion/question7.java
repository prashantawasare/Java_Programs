package classsquestion;
/*Q13.a[]={10,20,30,40,50}
b[]={1,2,3,4,5}

output array=c[]={10,5,20,4,30,3,40,2,50,1*/
public class question7 {
	
	int i;
	
	public int result(int a[],int c[],int b[])
	{
		int s=b.length-1;int h=0;
		for(i=0;i<a.length;i++) {
			
			c[h]=a[i];
			h++;
			c[h]=b[s];
			
			s--;
			h++;
		}
		for(i=0;i<c.length;i++)
		{
			System.out.println(c[i]);
		}
		
		return 1;
	}
	
public static void main(String args[])
{
	int a[]= {10,20,30,40,50};
	int b[]= {1,2,3,4,5};
	int c[]=new int[a.length+b.length];
	question7  ob=new question7();
	ob.result(a, c, b);

}
}

