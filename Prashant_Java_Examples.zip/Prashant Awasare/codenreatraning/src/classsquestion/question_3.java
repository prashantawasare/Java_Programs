package classsquestion;
//Q1.Given a sorted array arr[] and a number x, write a function that counts the occurrences of x in arr[]
import java.util.*;
public class question_3 {
	
	
	int i,j;
	Scanner ob=new Scanner(System.in);
	
	question_3(int a[])
	{
		System.out.println("enter the array");
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
		}
		int c=0;
		
		System.out.println(" enter the number you want to find its occurance");
		int t=ob.nextInt();
		
		for(i=0;i<a.length;i++)
		{   
			
			
				if(a[i]==t)
				{
					c++;
				
					
				}
			}
				
			System.out.println(c);
		
		
		
	
		
		
	}
	
	public static void main(String sa[])
	{
		int a[]= new int[5];
		
		question_3 ob=new question_3(a);
	}
}
