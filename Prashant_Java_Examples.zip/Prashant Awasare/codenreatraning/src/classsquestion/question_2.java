package classsquestion;
/*Q4.Given an array of N integers, and a number sum, the task is to find the number of pairs of integers in the array whose sum is equal to sum.

Examples:  

Input:  arr[] = {1, 5, 7, -1}, sum = 6
Output:  2*/
public class question_2 {
	
	int i,j;
	question_2(int a[])
	{
		int sum=6;int c=0;
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]+a[j]==sum)
					{System.out.println(a[i]+" "+a[j]);
					c++;}
			}
		}
		
		System.out.println("count "+c);
	}
	
	public static void main(String as[])
	{
		int a[]= {1,5,7,-1};
		question_2 ob=new question_2(a);
		
	}

}
