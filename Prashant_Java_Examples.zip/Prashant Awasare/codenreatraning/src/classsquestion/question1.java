package classsquestion;
//Q7.Wap enter an array and print the element which is on odd position.
public class question1 {
	
	int i;
	public void result(int a[])
	{
		System.out.println("elemnts presents at odd position");
		for(i=0;i<a.length;i=i+2)
		{
			System.out.println(a[i]);
		}
	}
	
	public static void main(String args[])
	
	{
		question1 ob=new question1();
		int a[]= {1,2,3,4,5};
		ob.result(a);
		
	}

}
