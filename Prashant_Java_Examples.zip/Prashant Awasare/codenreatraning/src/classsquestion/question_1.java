package classsquestion;
/*Q3.Given an array arr[] of size N-1 with integers in the range of [1, N], the task is to find the missing number from the first N integers.
Note: There are no duplicates in the list.
Examples: 

Input: arr[] = {1, 2, 4, 6, 3, 7, 8}, N = 8
Output: 5*/
public class question_1 {
	
	
	int i;

	question_1(int a[])
	{	int n=a.length+1;
	  int totalsum=(n*(n+1)/2);
	     int sum=0;
		
		for(i=0;i<a.length;i++)
		{
			sum=sum+a[i];
		}
		
		System.out.println("missing number="+(totalsum-sum));
	}
	
	public static void main(String as[])
	{
		int a[]= {1,2,3,4,6,7,8};
		question_1 ob=new question_1(a);
	}

}
