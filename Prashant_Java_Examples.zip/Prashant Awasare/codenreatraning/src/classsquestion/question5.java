package classsquestion;
//Q11.Wap enter an array and print it in reverse order
import java.util.*;
public class question5 {
	
	
	int i;
	Scanner ob=new Scanner(System.in);
	public void input(int a[])
	{
		for(i=0;i<a.length;i++)
		{
			a[i]=ob.nextInt();
		}
	}
	
	public void displ(int a[])
	{  System.out.println("array in reverse order");
		for(i=a.length-1;i>=0;i--)
		{
			System.out.println(a[i]+" ");
		}
	}
	
	public static void main(String args[])
	{   int a[]=new int[6];
		question5 ob=new question5();
		ob.input(a);
	    ob.displ(a);
	    
	}

}
