package classsquestion;
/*Q2.An array contains both positive and negative numbers in random order. Rearrange the array elements so 
that all negative numbers appear before all positive numbers.
 Examples : 

Input: -12, 11, -13, -5, 6, -7, 5, -3, -6
Output: -12 -13 -5 -7 -3 -6 11 6 5*/
public class question_4 {
	
	
	int i,j,k=0;
	question_4(int a[])
	{
		for(i=0;i<a.length;i++)
		{
			
			for(j=i+1;j<a.length;j++)
			if(a[i]>a[j])
				
			{
				k=a[i];
				a[i]=a[j];
				a[j]=k;
			}
			
			
		}
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		
	}
	
	public static void main(String as[])
	{
		
		int a[]= {-12,11,-13,-5,6,-7,5,-3,-6};
		question_4 ob=new question_4(a);
		
	}

}
