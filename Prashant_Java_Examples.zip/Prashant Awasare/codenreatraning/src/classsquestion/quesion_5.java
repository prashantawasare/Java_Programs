package classsquestion;
/*Q5.Given an array of integers arr[], The task is to find the index of first repeating element in it i.e. the 
element that occurs more than once and whose index of the first occurrence is the smallest. 
Examples: 
Input: arr[] = {10, 5, 3, 4, 3, 5, 6}
Output: 5*/
import  java.util.*;
public class quesion_5 
{
	
	int i,j,c=0;
	
	quesion_5 (int a[],int n)
	{
		for(i=0;i<a.length;i++)
		{
			
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j])
				{
					System.out.println(i+" "+a[j]);
					c=1;
					i=n;j=n;
				}
				
				
			}
		}
		if(c==0)
		{
			System.out.println("not repeating elemet ");
		}
	}
	
	public static void main(String args[])
	{
		int a[]= {10,5,3,4,3,5,6};
		int n=a.length;
		quesion_5  ob=new quesion_5 (a,n);
		
	}

}

		


	


