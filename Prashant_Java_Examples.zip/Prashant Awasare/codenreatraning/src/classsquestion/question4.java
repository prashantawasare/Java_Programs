package classsquestion;

import java.util.Scanner;


public class question4 {
	

	int i;
	   Scanner ob=new Scanner(System.in);
	   
	   public void result(int a[]) {
		   
		   for(i=0;i<a.length;i=i+2) {
			   
			   System.out.println(a[i]*a[i]+" ");
		   }
	   }
	   
	    
	   
	   public static void main(String args[]) {
		   int a[]= {1,2,3,4,5};
		   question4 ob=new question4();
		   ob.result(a);
		  
	   }

}



