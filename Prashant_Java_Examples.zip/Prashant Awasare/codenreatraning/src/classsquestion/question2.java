package classsquestion;
//Q8.Wap enter an array and print the element which is on even position
public class question2 {
	
	int i;
	public void result(int a[])
	{
		System.out.println("elemnts presents at even position");
		for(i=1;i<a.length;i=i+2)
		{
			System.out.println(a[i]);
		}
	}
	
	public static void main(String args[])
	
	{
		question1 ob=new question1();
		int a[]= {1,2,3,4,5,7};
		ob.result(a);
		
	}

}



