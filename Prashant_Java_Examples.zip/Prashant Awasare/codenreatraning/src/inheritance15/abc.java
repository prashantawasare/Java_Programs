package inheritance15;
import java.util.*;
public class abc {
	
	
	int a,b;
	Scanner ob=new Scanner(System.in);
	 void input()
	{
		System.out.println(" enter the two number");
		a=ob.nextInt();
		b=ob.nextInt();
	}

}

