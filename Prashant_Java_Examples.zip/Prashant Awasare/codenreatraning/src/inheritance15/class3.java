package inheritance15;
import java.util.*;


 public class class3 extends xyz 
 {
	
	
     void dis()
	{
		display();
		System.out.println("multiplication="+a*b);
	}
     

	
	 }

