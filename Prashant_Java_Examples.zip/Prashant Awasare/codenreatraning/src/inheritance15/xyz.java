package inheritance15;

public class xyz extends abc
 {
	 
 void display()
	 {
		input();
		 System.out.println(a+" "+b);
		 System.out.println("addition="+(a+b));
	 }
	 
	 

}
