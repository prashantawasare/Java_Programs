package inheritance15;

public class inheritance2 extends inheritance {
	
	
		
		   public void display()
		   {  System.out.println(a+" "+b);
			   System.out.println(a+b);
		   }
		  public static void main(String da[])
		  {
			  
			  inheritance2 ob=new inheritance2();
			  
			  ob.input();
			  ob.display();
					  
			  
			  
		  }
		}


