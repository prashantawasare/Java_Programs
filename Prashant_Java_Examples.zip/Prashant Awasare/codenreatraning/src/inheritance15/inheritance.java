package inheritance15;
import java.util.*;
 class inheritance {
	
	
	Scanner ob=new Scanner(System.in);
	int a,b;

	public void input()
	{
		
		System.out.println("enter the two number");
		int a=ob.nextInt();
		int b=ob.nextInt();
		
	}
	

}

 public class inheritance2 extends inheritance {
		
		
		
	   public void display()
	   {  System.out.println(a+" "+b);
		   System.out.println(a+b);
	   }
	  public static void main(String da[])
	  {
		  
		  inheritance2 ob=new inheritance2();
		  
		  ob.input();
		  ob.display();
				  
		  
		  
	  }
	}

