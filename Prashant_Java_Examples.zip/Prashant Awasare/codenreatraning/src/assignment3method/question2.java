package assignment3method;

import java.util.Scanner;

/*Q2.

Using return type with no-argument
Create a menu program
1. Insertion of Array
2. Deletion of Array
3. Serachig of Element in Array
4. Reverse Of an array. */
public class question2 {
	
	int i,j,n,pos,element,k;int a[]= {1,2,3,4,5};
	Scanner ob=new Scanner(System.in);
	public void diplay()
	{
		System.out.println("1.insertion of array\n2.deletion of array\n3.searching of element in array\n4.reverse of an array");
	}
	
	
	
	public int result()
	{
	  System.out.println("enter your choice");
	  
	  n=ob.nextInt();
	  switch(n)
	  {
	  case 1:
		   pos=1;
		  element=23;
		  for(i=a.length-1;i>pos-1;i--)
		  {
	  
	         a[i]=a[i-1];
		  }
		  a[pos-1]=element;
	    for(i=0;i<a.length;i++)
	    {
	    	System.out.println(a[i]);
	    }
	    
	    break;
	    
	  case 2:
		  pos=1;
		  for(i=pos;i<a.length-1;i++)
	  {
		  a[i]=a[i+1];
	  }
		  for(i=0;i<a.length-1;i++)
		  {
			  System.out.println(a[i]);
		  }
		  break;
	  case 3:
		  k=3;
		  System.out.println("number found");
		  for(i=0;i<a.length;i++)
		  {
			  if(a[i]==k)
				  System.out.println(k);
		  }
		 
		  break;
	  case 4:
		  for(i=a.length-1;i>=0;i--)
		  {
			  System.out.println(a[i]);
			  
		  }
		  break;
	  default:
		  System.out.println("wrong input");
		  
	}
	  return 2;
	
	}
	
	public static void main(String args[])
	{
		question2  ob=new question2();
		ob.diplay();
		ob.result();
		
		
	}
	


}
