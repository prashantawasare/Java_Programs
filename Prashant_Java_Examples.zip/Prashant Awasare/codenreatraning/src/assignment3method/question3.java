package assignment3method;

import java.util.Scanner;

/*Q3.

Using no- return type with no-argument
Create a menu program
1. Insertion of Array
2. Deletion of Array
3. Serachig of Element in Array
4. Reverse Of an array. */
public class question3 {
	int i,j,n,pos,element,k;int a[]= {1,2,3,4,5};
	Scanner ob=new Scanner(System.in);
	public void diplay()
	{
		System.out.println("1.insertion of array\n2.deletion of array\n3.searching of element in array\n4.reverse of an array");
	}
	
	
	public void result() {
		
		 System.out.println("enter your choice");
		  
		  n=ob.nextInt();
	  switch(n)
	  {
	  case 1:
		 System.out.println("your choice is insertion");
		   pos=1;
		  element=23;
		  
		  for(i=a.length-1;i>pos-1;i--)
		  {
	  
	         a[i]=a[i-1];
		  }
		  a[pos-1]=element;
		  
	    for(i=0;i<a.length;i++)
	    {
	    	System.out.println(a[i]);
	    }
	    
	    break;
	    
	  case 2:
		  pos=1;
		  System.out.println(" your choice is deletion");
		  for(i=pos;i<a.length-1;i++)
	  {
		  a[i]=a[i+1];
	  }
		  for(i=0;i<a.length-1;i++)
		  {
			  System.out.println(a[i]);
		  }
		  break;
	  case 3:
		  k=3;
		  System.out.println("number found");
		  for(i=0;i<a.length;i++)
		  {
			  if(a[i]==k)
				  System.out.println(k);
		  }
		 
		  break;
	  case 4:
	
		  System.out.println(" your choice reverse");
		  for(i=a.length-1;i>=0;i--)
		  {
			  System.out.println(a[i]);
			  
		  }
		  break;
	  default:
		  System.out.println("wrong input");
		  
	}
	 
	
	}
	
	public static void main(String args[])
	{
		question2  ob=new question2();
        ob.diplay();
		ob.result();
	}
	



}
