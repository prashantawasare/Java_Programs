package accessmodifier;

public class two
{
	


	
	public static void main(String ahs[])
	{
		two ob=new two();
		ob.disp();
	}

}
