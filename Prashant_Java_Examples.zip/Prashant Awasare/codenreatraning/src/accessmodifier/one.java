package accessmodifier;
import java.util.*;
public class one {
	
	Scanner ob=new Scanner(System.in);
		
	public static void main(String gd[])
	{
		four ob=new four();
		ob.disp();
	}

}


class four extends one
{
	Scanner ob=new Scanner(System.in);
	private int id=1;
	
	private String name;
	private void input()
	{
		System.out.println("enter id=");
		id=ob.nextInt();
		System.out.println("enter name");
		name=ob.next();
	}
	
	public void disp()
	{ input();
		System.out.println("id="+id);
		System.out.println("name"+name);
	}
}

