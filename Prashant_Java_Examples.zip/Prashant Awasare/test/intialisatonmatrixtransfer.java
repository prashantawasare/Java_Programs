class intialisatonmatrixtransfer
{
  public static void main(String as[])
{
   int a[][]={
             {3,4,5},
             {4,5,6},
             {7,8,9}
           };

     int  row=a.length;
    int col=a[0].length;
   
    int size=row*col;
      System.out.println("Size of matrix="+size);
   for(row=0;row<3;row++)
  {
     for(col=0;col<3;col++)
    
    System.out.print(a[col][row]+" ");
    
      System.out.println();
    }
  }
}
            
             