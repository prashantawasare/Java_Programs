class IfExample
{
    public static void main(String s[])
    {
        if( 1 < 2 )
        {
            System.out.println("1 is less than 2");
        }
        else
            System.out.println("2 is less than 1");
            System.out.println("Hello From IfExample");
        
    }
}