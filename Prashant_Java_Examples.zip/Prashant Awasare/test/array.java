import java.util.Scanner;
class array
{
  public static void main(String ass[])
{
   Scanner ob=new Scanner(System.in);

   int i;
   int a[]={1,2,3,4,5,6,7,9,11,12};
  System.out.println("enter elements in array");
for(i=0;i<a.length;i++)
{
     System.out.print(a[i]+" ");}

   
     int j,c=0;
  System.out.println("\nprime numbers");
 for(i=0;i<a.length;i++)
{   
 
        j=a[i];int rem,sum=0;
   while(j>0)
   {
      rem=j%10;
     sum=sum*10+rem;

      j=j/10;
         }
        if(sum==a[i])
       System.out.print(a[i]+" ");
  }			


     }
}
