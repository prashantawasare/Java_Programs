//Q.1 Find the sum of each  row and colum

class intiaisesum
{
public static void main(String ars[])
{
  int a[][]={
              {3,4,5},
              {7,8,9},
              {9,8,11}
              };

     int i=a.length;
      int j=a[0].length;
       
     for(i=0;i<3;i++)
    {     int sum=0;
       for(j=0;j<3;j++)
       {  sum=sum+a[i][j];
       System.out.print(a[i][j]+" ");
        }

    
     
        System.out.println("sum="+sum);     
   }
     System.out.println();
}
}