class question9
{
 public static void main(String arsg[])
{
  int a[]={1,2,3,4,5,7};



    System.out.println("squrae of elment which  is at  evevn position");
   for(int i=1;i<a.length;i=i+2)

{
   System.out.println(a[i]*a[i]+" ");

   }
   

    }
}