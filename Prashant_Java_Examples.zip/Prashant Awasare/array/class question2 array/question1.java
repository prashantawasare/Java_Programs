class question1
{
 public static void main(String ggs[])
{
  

 int i,c=0;
for(i=1;i<=100;i++)
{
   
    
   int j=i,rem,rev=0;

  while(j!=0)
{
   
rem=j%10;
rev=rev*10+rem;
  j=j/10;

   }
    if(rev==i)
   System.out.print(i+" ");
  
     }
   }
}