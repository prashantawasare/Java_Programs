class question3
{
 public static void main(String ggs[])
{
  

 int a[]={26,0,67,45,0,78,54,34,10,0,34};

  

  int i;
for(i=0;i<a.length;i++)
{
  if(a[i]==0)
  a[i]=1;

   }
   for(i=0;i<a.length;i++)
{
  System.out.print(a[i]+" ");

    }
}
}
  
