class question4
{
  public static void main(String as[])
{
  
   int a[]={1,2,3,4,5,6};
   
    int i,k=4,c=0;
 

for(i=0;i<a.length;i++)
{
  if(k==a[i])

  c++;

  }
 System.out.println("number found="+k);
  
  System.out.println("count="+c);

     }
}