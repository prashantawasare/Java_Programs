class question7
{
  public static void main(String as[])
{
  
   int a[]={1,2,2,3,4,5,5};

  int b[]=new int[a.length];

   int i,j,k=-1,count=0;

 for(i=0;i<a.length;i++)
{
    
  for(j=i+1;j<a.length-1;j++)
{
   if(a[i]!=a[j])
   a[j]=a[i];
   
    
  System.out.println(a[j]+" ");
        
     count++;   }
 }System.out.println(count+" ");
 
  

}
}
   
    
 
   

