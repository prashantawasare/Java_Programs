class question8
{
 public static void main(String arsg[])
{
  int a[]={1,2,3,4,5,7};



    System.out.println("squrae of elment which  is at  odd position");
   for(int i=0;i<a.length;i=i+2)

{
   System.out.println(a[i]*a[i]+" ");

   }
   

    }
}