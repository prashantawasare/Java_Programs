class question6
{
  public static void main(String as[])
{
  
   int a[]={1,2,3,4,5,6};
   
    int i,num1=4,num2=5;
 
   int r=0,p=0; 
for(i=0;i<a.length;i++)
{
  if(num1==a[i])
    r=1;
  if(num2==a[i])
   p=1;
  }

 if(r==1 && p!=1)
 System.out.println("num1 is found");
  else
  {
     if(r==1 && p==1)
    System.out.println("both numbers are found");
    
    else if(r!=1 && p==1)
   System.out.println("num2 is found");
   else
   System.out.println("both numbers are  not found");


    

   

    














  }
 
     }
}