class question10
{
 public static void main(String arsg[])
{
  int a[]={12,3,-19,29,5,-61,44,7,-9};

    int i;
   for( i=0;i<a.length;i++)

{    if(a[i]<0)
     {a[i]=a[i-1]*a[i-1];
       }
      
   System.out.print(a[i]+" ");}

   

    }
}