class question2
{
 public static void main(String ggs[])
{
  

 int i,c=0;
for(i=1;i<=100;i++)
{
   
    
   
  int j;
  for(j=2;j<=100;j++)
   
  { if(i%j==0)
     break;}
  
  

   
    if(i==j)
   System.out.print(i+" ");
  
     }
   }
}