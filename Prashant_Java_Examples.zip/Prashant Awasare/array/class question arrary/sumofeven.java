import java.util.Scanner;
class sumofeven
{
  public  static void main(String rgs[])
{
  Scanner ob=new Scanner(System.in);
int i;
int[]a=new int[5];
for(i=0;i<5;i++)
{
   a[i]=ob.nextInt();

   }int even=0,sum=0;
  
 for(i=0;i<5;i++)
{
  if(a[i]%2==0)
 
  sum=sum+a[i];
   
   }

System.out.println("sum of even  numbers="+sum);
 }
}