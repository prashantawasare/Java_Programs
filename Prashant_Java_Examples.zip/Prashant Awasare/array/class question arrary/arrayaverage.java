import java.util.Scanner;
class arrayaverage
{
  public  static void main(String rgs[])
{
  Scanner ob=new Scanner(System.in);
int i;
int[]a=new int[5];
for(i=0;i<5;i++)
{
   a[i]=ob.nextInt();

   }double sum=0,average=0;
 for(i=0;i<5;i++)
{
  sum=sum+a[i];
  average=sum/5;
   
   }
System.out.println("sum="+sum);
System.out.println("average="+average);

 }
}