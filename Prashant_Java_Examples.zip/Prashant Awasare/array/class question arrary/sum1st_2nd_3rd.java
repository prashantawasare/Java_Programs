import java.util.Scanner;
class sum1st_2nd_3rd
{
  public  static void main(String rgs[])
{
  Scanner ob=new Scanner(System.in);
int i;
int[]a=new int[5];
for(i=0;i<5;i++)
{
   a[i]=ob.nextInt();

   }int even=0,sum=0;
  
 for(i=0;i<5;i++)
{
  
 
  sum=a[0]+a[1]+a[2];
   
   }

System.out.println("sum of first,2nd and 3rd="+sum);
 }
}