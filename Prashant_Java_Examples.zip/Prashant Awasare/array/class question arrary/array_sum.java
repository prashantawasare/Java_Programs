import java.util.*;
class array_sumintialisaion
{
  public static void main(String ags[])
{
  
  Scanner ob=new Scanner(System.in);

int length;
int i=0;

int []a={1,2,3,4,5}; 
for(i=0;i<a.length;i++)
 {

    

 
 System.out.println(a[i]+" ");
  
       }
    }
}

  
 

 

