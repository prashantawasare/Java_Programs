import java.util.Scanner;

class arrrayeven
{
   public static void main(String ats[])
{
   Scanner ob=new Scanner(System.in);

  int i;
 
 int[] a=new int[10];

   System.out.println("Enter elelments in array=");
   i=0;
for(i=0;i<10;i++)
{
  
    a[i]=ob.nextInt();

    
   
    }
   
   
   
    int odd=0;
    int sum=0;
    int even=0;
  for(i=0;i<10;i++)
 { 

    
    
   
  if(a[i]%2==0)

  
  even++;
  else
  odd++;

   

   }
    System.out.println("even count="+even);
    System.out.println("odd count="+odd);
   
           

}
}
  
    