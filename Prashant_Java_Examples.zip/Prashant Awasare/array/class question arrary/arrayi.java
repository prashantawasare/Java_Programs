import java.util.*;

 class arrayi
{
  public static void main(String asg[])
{
  Scanner ob=new Scanner(System.in);

  int i;
 int[]a=new int[10];
 
  System.out.println("enter elements in array");
   for(i=0;i<10;i++)
{
   a[i]=ob.nextInt();

  }
  System.out.println("elements in array");

  for(i=0;i<10;i++)
{
  System.out.print(a[i]+" ");

     }
  }
}