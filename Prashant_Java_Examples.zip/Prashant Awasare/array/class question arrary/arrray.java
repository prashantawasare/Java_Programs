import java.util.Scanner;

class arrray
{
   public static void main(String ats[])
{
   Scanner ob=new Scanner(System.in);

  int i;
 
 int[] a=new int[10];

   System.out.println("Enter elelments in array=");
   i=0;
while(i<10)
{
  
    a[i]=ob.nextInt();

    
   i++;}
    i=0;System.out.println("elements in array");
  while(i<10)
 { System.out.print((a[i]+" "));
   

   i++;

  }

}
}
  
    