import java.util.Scanner;
class firstandlastsum
{
  public  static void main(String rgs[])
{
  Scanner ob=new Scanner(System.in);
int i;
int[]a=new int[5];
for(i=0;i<5;i++)
{
   a[i]=ob.nextInt();

   }int sum=0;
 for(i=0;i<5;i++)
{
  sum=a[0]+a[4];
   
   }System.out.println("first element "+a[0]);
  System.out.println("last element "+a[4]);

System.out.println("sum="+sum);
 }
}