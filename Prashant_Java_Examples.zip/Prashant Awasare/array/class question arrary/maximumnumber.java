import java.util.Scanner;

class maximumnumber
{
   public static void main(String ats[])
{
   Scanner ob=new Scanner(System.in);

  int i;
 
 int[] a=new int[10];

   System.out.println("Enter elelments in array=");
   i=0;
for(i=0;i<10;i++)
{
  
    a[i]=ob.nextInt();

    
   
    }
   
   
   
    int k=0;
    
  for(i=0;i<10;i++)
 { 

    
    if(a[i]>k)
    k=a[i]

  
      
   

   }
    System.out.println("maximum number="+k);
    
   
           

}
}
  
    