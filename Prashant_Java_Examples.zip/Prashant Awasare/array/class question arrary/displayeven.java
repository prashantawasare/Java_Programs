import java.util.Scanner;
class displayeven
{
  public  static void main(String rgs[])
{
  Scanner ob=new Scanner(System.in);
int i;
int[]a=new int[5];
for(i=0;i<5;i++)
{
   a[i]=ob.nextInt();

   }int even=0;System.out.println("even numbers");
 for(i=0;i<5;i++)
{
  if(a[i]%2==0)
  System.out.print(" "+a[i]);
   
   }


 }
}