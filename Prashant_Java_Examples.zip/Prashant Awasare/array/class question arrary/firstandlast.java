import java.util.Scanner;
class firstandlast
{
  public  static void main(String rgs[])
{
  Scanner ob=new Scanner(System.in);
int i;
int[]a=new int[5];
for(i=0;i<5;i++)
{
   a[i]=ob.nextInt();

   }
 for(i=0;i<5;i++)
{

   
   }System.out.println("first element "+a[0]);
  System.out.println("last element "+a[4]);


 }
}