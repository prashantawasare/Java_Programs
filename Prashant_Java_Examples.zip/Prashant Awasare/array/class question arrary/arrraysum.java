import java.util.Scanner;

class arrraysum
{
   public static void main(String ats[])
{
   Scanner ob=new Scanner(System.in);

  int i;
 
 int[] a=new int[10];

   System.out.println("Enter elelments in array=");
   i=0;
for(i=0;i<10;i++)
{
  
    a[i]=ob.nextInt();

    
   
    }
   
   
   System.out.println("sum of elements");
    int count=0;
    int sum=0;
  for(i=0;i<10;i++)
 { 

    
    
   
   sum=sum+a[i];

  count++;

   

   }
    System.out.println(sum);
    System.out.println(count);
           

}
}
  
    