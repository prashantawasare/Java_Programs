import java.util.Scanner;
class displaysum1st_2nd_3rd
{
  public  static void main(String rgs[])
{
  Scanner ob=new Scanner(System.in);
int i;
int[]a=new int[5];
for(i=0;i<5;i++)
{
   a[i]=ob.nextInt();

   }int even=0,sum=0;
  System.out.println("display 1st,2nd,and third");
 for(i=0;i<5;i++)
{
  
 

   
 }

  System.out.println(a[0]);
 
 System.out.println(a[1]);
 
 System.out.println(a[2]);
}
}