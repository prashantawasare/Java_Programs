class oi
{

  public static void main(String args[])
{
  int a=-23;
while(a<-21)
{
  System.out.print(a);
  a++;
}

}
}