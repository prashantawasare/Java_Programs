class main
{
   public static void main(String args[])

 {    

     char a='f';

     System.out.println("ascii value="+(int)a);

      


    
}
}