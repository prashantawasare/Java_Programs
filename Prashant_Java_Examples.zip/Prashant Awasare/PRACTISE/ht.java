import java.util.*;
class ht
{
 public static void main(String fg[])
{
  Scanner ob=new Scanner(System.in);
   

  int n=ob.nextInt();
      

if(n<0)
System.out.println("not possible");
else
{  int i,rev=0,rem;
        i=n;

   while(i!=0)

    {  
     rem=i%10;

      
     rev=rev*10+rem;
     i=i/10;

       

} 

 System.out.println("rev="+rev);
if(rev==n)
System.out.println("palindrome");
else
System.out.println("not palindrome");






}




}
}