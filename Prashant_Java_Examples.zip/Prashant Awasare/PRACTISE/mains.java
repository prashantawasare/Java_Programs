import java.util.Scanner;
class mains
{

     public static void main(String args[])
{

     Scanner ob=new Scanner(System.in);

  int a,b,c;
System.out.println("enter first side of traingle");

a=ob.nextInt();

 System.out.println("enter second side of traingle");

b=ob.nextInt();
System.out.println("enter third side of traingle");

c=ob.nextInt();


if (a==b && b==c && c==a)

  System.out.println("traingle is equilateral");
  
else if(a!=b && b==c && c!=a)
System.out.println("traingle is iscoseles");

else if(a!=b && b!=c && c!=a)
System.out.println("tringle is scalen");


else
{
System.out.println("traingle is not a traingle")


;


      }
   }

}