class prtiset
{
  public static void main(String ass[])
{

  int row,col;
for(row=1;row<=5;row++)
{
 

for(col=1;col<=row;col++)
   
 System.out.print("*");
 


    System.out.println();
}
for(row=4;row>=1;row--)
{
 for(col=1;col<=row;col++)
 System.out.print("*");



    System.out.println();
}

   for(row=1;row<=5;row++)
{
 
for(col=row;col<=5;col++)
   System.out.print(" ");
for(col=1;col<=row;col++)
   
 System.out.print("*");
 


    System.out.println();
}
for(row=5;row>=1;row--)
{for(col=row;col<=5;col++)
 System.out.print(" ");
 for(col=1;col<=row;col++)
 System.out.print("*");



    System.out.println();
}
}
}