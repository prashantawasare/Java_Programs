import java.util.Scanner;

  class menu_program

     {

        public static void main(String args[])


    {

       Scanner ob=new Scanner(System.in);

      
            System.out.println("\t\t\t\n\t\t\t1.ADD\n\t\t\t2.Sub\n\t\t\t3.Multi\n\t\t\t4.Div");


           
             
        
              int i=1;
             while(i!=0)
           {    
               

             System.out.println("\n\t\t\tEnter your choice");

              int n=ob.nextInt();
               if (n==1)

        {     System.out.println("\t\t\tYour choice is addition");   
             System.out.println("\t\t\tenter a number");
             int a=ob.nextInt();

             System.out.println("\t\t\tenter a number");
             int b=ob.nextInt();
                 int sum=a+b;

              System.out.println("\t\t\tADD="+sum);

                     }

         





           else if (n==2)
         { System.out.println("\t\t\tYour choice is subtraction");   
           System.out.println("\t\t\tenter a number");
             int a=ob.nextInt();

             System.out.println("\t\t\tenter a number");
             int b=ob.nextInt();
              int sub=a-b;
             System.out.println("\t\t\tSub"+sub);

         }


              else if (n==3)

          {  System.out.println("\t\t\tYour choice is multiplication");
             System.out.println("\t\t\tenter a number");
             int a=ob.nextInt();

             System.out.println("\t\t\tenter a number");
             int b=ob.nextInt();

           int mul=a*b;
            System.out.println("\t\t\tMul="+mul);

                   }

        else if (n==4)

{             System.out.println("\t\t\tYour choice is division");
              System.out.println("\t\t\tenter a number");
             int a=ob.nextInt();

             System.out.println("\t\t\tenter a number");
             int b=ob.nextInt();
            


             double Div=a/b; 
            System.out.println("\t\t\tDiv"+Div);      }
    System.out.println("enter 7 to terminate or 0 to countinue");
            int x=ob.nextInt();


          }
}

}