/*Q1.
A
B B
C C C
D D D D
E E E E E*/


class question1
{
  public static void main(String args[])
{
  int row,col;
  int a=64;
for(row=1;row<=5;row++)
{
 for(col=1;col<=row;col++)
   System.out.print((char)(col+a));
   
 System.out.println();
     }

  }
}
