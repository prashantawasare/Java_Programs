class q12
{
   public static void main(String ahfj[])
{
    

   int row,col;
   
for(row=1;row<=5;row++)
{    int t=row;
  for(col=row;col>=1;col--)
 {    
  System.out.print(t+" ");
         t=t+5;}
 System.out.println();


   }

















   
  }
}