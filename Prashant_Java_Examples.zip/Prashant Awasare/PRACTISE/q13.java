class q13
{
   public static void main(String ahfj[])
{
    

   int row,col;
   
for(row=1;row<=5;row++)
{    
  for(col=row;col<=5;col++)

 {  System.out.print(" ");}
    
       int t=1;
    for(col=1;col<=row;col++)    
  {System.out.print(t+" ");
         t=t*(row-col)/(col);}
 System.out.println();


   }

















   
  }
}