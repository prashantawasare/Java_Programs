
class table_
{

   public static void main(String args[])
{

    int row=1;
   for(row=1;row<=5;row++)
    {
      int col=1;
      for(col=1;col<=row;col++)
    {
       System.out.print("*");

      
      }System.out.println();

    }
     row=5;
   for(row=5;row>=1;row--)
    {
      int col=1;
      for(col=1;col<=row;col++)
    {
       System.out.print("*");

      
      }System.out.println();

    }

     row=1;
   for(row=1;row<=5;row++)
    {
      int col=1;
      for(col=1;col<=row;col++)
    {
       System.out.print("*");

      
      }System.out.println();



}row=0;
 for( row=0;row<=5;row++)

  {
      int col;
    for(col=0;col<=4;col++)
{
    if(row==0 || row==5-1 || col==0 || col==5)

    System.out.print(" * ");
   else
   System.out.print(" ");
}
  System.out.println();

}









































    }
}
