import java.util.*;

  class vowel_

   {

     public static void main(String args[])

  {

     Scanner ob=new Scanner(System.in);
     
     char a;

     System.out.println("enter a character");

     a=ob.next().charAt(0);

     if (a=='a')
      
     System.out.println("it is vowel");

    
    else if(a=='e')
      
     System.out.println("it is vowel");
    
    else if(a=='i')
      
     System.out.println("it is vowel");

    else if(a=='o')
      
     System.out.println("it is vowel");
  
    else if(a=='u')
      
     System.out.println("it is vowel");

   else 
    System.out.println("it is consolent");
}
}

      