class prt
{
   public static void main(String sr[])               

{     

   int row,col;

  for(row=5;row>=1;row--)
  {

      for(col=1;col<=row;col++)

    {

        System.out.print(col);
     }

        System.out.println();



    }

  for(row=1;row<=5;row++)
  {

      for(col=5;col>=1;col--)

    {

        System.out.print(col);
     }

        System.out.println();



    }
 for(row=1;row<=5;row++)
  {

      for(col=1;col<=row;col++)

    {

        System.out.print(col);
     }

        System.out.println();



    }
  for(row=5;row>=1;row--)
  {

      for(col=1;col<=row;col++)

    {

        System.out.print(col);
     }

        System.out.println();}






































   }
}