class str

{
public static void main(String args[])

{

  int a=23;
   int b=a++;
    int c=b-- + a++;


System.out.println(a);


System.out.println(b);
System.out.println(c);



}

   }