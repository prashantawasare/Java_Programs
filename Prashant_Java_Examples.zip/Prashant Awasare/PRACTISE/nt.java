class nt
{

    public static void main(String args[])
{




int  row=0;
 for( row=0;row<=5;row++)

  {
      int col;
    for(col=0;col<=4;col++)
{
    if(row==0 || row==5-1 || col==0 || col==4)

    System.out.print("*");
   else
   System.out.print(" ");
}
  System.out.println();

}


     }
  }