class numbers
{
  public static void main(String aaea [])
{

   int i=1;
   int n=10;
     int sum=0;  

   for(i=1;i<=n;i++)

     {

        
        sum=sum+i;
   
      System.out.println(sum);





   }









   


}
}