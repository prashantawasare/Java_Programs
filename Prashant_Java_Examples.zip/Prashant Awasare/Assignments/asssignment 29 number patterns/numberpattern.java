//Q.1print the pattern
   //1
   //12
   //123
   //1234
   //12345

/*class numberpattern
{
  public static void main(String args[])
{
   int row,col;
  for(row=1;row<=5;row++)
  {
     for(col=1;col<=row;col++)
   System.out.print(col+" ");

         s
      System.out.println();

        }

       }

   }

    
==============================================================================================================*/
  //Q.2 print the pattern
     //1
     //22
     //333
     //4444
     //55555


     
      
   /* class numberpattern2
{
  public static void main(String args[])
{
   int row,col;
  for(row=1;row<=5;row++)
  {
     for(col=1;col<=row;col++)
   System.out.print(row+" ");

         
      System.out.println();


        }

       }

   }
===========================================================================================================================*/

//Q.3 Print the pattern
      //1
     // 12
      //123
      //1234
      //12345
      //1234
      //123
      //12
      //1







/*class numberpattern3
{
  public static void main(String args[])
{
   int row,col;
  for(row=1;row<=5;row++)
  {
     for(col=1;col<=row;col++)
   System.out.print(col+" ");

         
      System.out.println();


        }


  for(row=5;row>=1;row--)
  {
     for(col=1;col<=row;col++)
   System.out.print(col+" ");

         
      System.out.println();


        }

       }

   }
 ===================================================================================*/
//Q.4print the pattern
    
      //12345
      //1234
      //123
      //12
      //1
      //1
     // 12
      //123
      //1234
      //12345

/*class numberpattern4
{
  public static void main(String args[])
{
   int row,col;
  for(row=5;row>=1;row--)
  {
     for(col=1;col<=row;col++)
   System.out.print(col+" ");

         
      System.out.println();


        }


  for(row=1;row<=5;row++)
  {
     for(col=1;col<=row;col++)
   System.out.print(col+" ");

         
      System.out.println();


        }

       }

   }
==================================================================================================*/
//Q.5print the pattern
    
      //54321
      //4321
      //321
      //21
      //1
      //1
     // 21
      //321
      //4321
      //54321




/*class numberpattern5
{
  public static void main(String args[])
{
   int row,col;
  for(row=5;row>=1;row--)
  {
     for(col=row;col>=1;col--)
   System.out.print(col+" ");

         
      System.out.println();


        }


  for(row=1;row<=5;row++)
  {
     for(col=row;col>=1;col--)
   System.out.print(col+" ");

         
      System.out.println();


        }

       }

   }
==========================================================================================================*/
//Q.6 print the pattern
  //   1
  //  1 2
  // 1 2 3
  //1 2 3 4
// 1 2 3  4 5

class numberpattern6
{
  public static void main(String args[])
{
   int row,col;
  for(row=1;row<=5;row++)
  {
     for(col=1;col<=5;col++)
    
   System.out.print(" ");
   
     for(col=row;col<=row;col++)
    
   System.out.print(col);
for(col=1;col<row;col++)
    
   System.out.print(col);


         
      System.out.println();


        }
      }
   }
//======================================================================================================
//Q.7print the pattern
/*class numberpattern7
{
  public static void main(String args[])
{
   int row,col;
  for(row=1;row<=5;row++)
  {
     for(col=5;col>=row;col--)
    
   
   System.out.print(col);


         
      System.out.println();


        }
      }

   }
//==============================================================================================*/
//Q.8print the pattern
/*class numberpattern8
{
  public static void main(String args[])
{
   int row,col;
  for(row=5;row>=1;row--)
  {
     for(col=5;col>=row;col--)
    
   
   System.out.print(col);


         
      System.out.println();


        }
      }

   }
//==============================================================================================*/

//Q.9 print the pattern

/*class numberpattern9
{
  public static void main(String args[])
{
   int row,col;
  for(row=5;row>=1;row--)
  {
     for(col=1;col<=row;col++)
   System.out.print(col+" ");

         
      System.out.println();

        }

       }

   }
========================================================================================*/
//Q.10 print the pattern
/*class numberpattern10
{
  public static void main(String args[])
{
   int row,col;
     int count=0;
  for(row=1;row<=5;row++)
  {        
     for(col=1;col<=row;col++)
    {     count=count+1;  
   System.out.print(count+" ");}
  

         
      System.out.println();

        }

       }

   }
=================================================================================*/
//Q.11 print the pattern
/*class numberpattern11
{
  public static void main(String args[])
{
   int row,col;
     
  for(row=1;row<=5;row++)
  {        
     for(col=row;col>=1;col--)
    {      
   System.out.print(col+" ");}
  

         
      System.out.println();

        }

       }

   }
=================================================================================*/
//Q.12 print the pattern
/*class numberpattern12
{
  public static void main(String args[])
{
   int row,col;
     
  for(row=1;row<=5;row++)
  {       int count=row; 
     for(col=1;col<=row;col++)
    {      
   
   System.out.print(count+" ");
     count=count+6-col;
  }

         
      System.out.println();

        }

       }

   }
//=================================================================================*/

    

    //Q.13 print the pattern
/*class numberpattern11
{
  public static void main(String args[])
{
   int row,col;
     
  for(row=1;row<=5;row++)
  {        
     for(col=row;col>=1;col--)
    {      
   System.out.print(col+" ");}
  

         
      System.out.println();

        }

       }

   }
=================================================================================*/

    

    

    

    