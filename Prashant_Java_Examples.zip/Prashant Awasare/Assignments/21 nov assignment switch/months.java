//Q.4 WAP enter a month no print month name and no of days using switch case.

import java.util.*;
class months
{

    public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);
   
   System.out.println("enter a month number");
   int month=ob.nextInt();



    switch(month)
{
    case 1:

   System.out.println("january");
   System.out.println("31 days in january");
   break;

  case 2:

   System.out.println("february");
   System.out.println("28 days in february");
   break;
   case 3:

   System.out.println("march");
   System.out.println("31 days in march");
   break;

   case 4:

   System.out.println("april");
   System.out.println("30 days in april");
   break;

   case 5:

   System.out.println("may");
   System.out.println("31 days in may");
   break;

   case 6:

   System.out.println("june");
   System.out.println("30 days in june");
   break;


   case 7:

   System.out.println("july");
   System.out.println("31 days in july");
   break;

   case 8:

   System.out.println("august");
   System.out.println("31 days in august");
   break;

case 9:

   System.out.println("january");
   System.out.println("31 days in september");
   break;
case 10:

   System.out.println("january");
   System.out.println("31 days in october");
case 11:

   System.out.println("january");
   System.out.println("31 days in november");
   break;
case 12:

   System.out.println("january");
   System.out.println("31 days in december");
   break;

default:
System.out.println("wrong choice");
 break;
}
  }

}











