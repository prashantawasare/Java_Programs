//Q.2 WAP to display menu program and perform task according input using switch case
//1.Area of circle 2.Area of Rectangel 3.Area of Square 4.Area of Traingle

    import java.util.Scanner;
    class menu_program_
{

   public static void main(String args[])
{

   Scanner ob=new Scanner(System.in);

    System.out.println("1.Area of circle");
   System.out.println("2.Area of rectangle");
  System.out.println("3.Area of square");
   System.out.println("4.Area of traigle");
   System.out.println("enter your choice");
   int a=ob.nextInt();

  switch(a)
{

  case 1:
         System.out.println("Your choice is find area of circle");
         int r=ob.nextInt();
         double pi=3.14;
         double area_circle=pi*r*r;
         System.out.println("Area of circle"+area_circle);
         break;
case 2:
         System.out.println("Your choice is find area of reactangle");
         int l=ob.nextInt();
         int b=ob.nextInt();
         double area_rectangle=l*b;
         System.out.println("Area of rectangle"+area_rectangle);
         break;
case 3:
         System.out.println("Your choice is find area of square");
         int c=ob.nextInt();
         
         double area_square=a*a;
         System.out.println("Area of square"+area_square);
         break;

case 4:
         System.out.println("Your choice is find area of traingle");
         int b_=ob.nextInt();
         int h_=ob.nextInt();
         
         double area_traingle=b_*h_/2;
         System.out.println("Area of traingle"+area_traingle);
         break;
   
    default:
     System.out.println("wrong choice");}
}
}




