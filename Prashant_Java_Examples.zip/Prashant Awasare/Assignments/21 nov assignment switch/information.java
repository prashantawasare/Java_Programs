//Q.5 WAP to enter record of 5 student serach student using thier id and display full information using switch case.

import java.util.*;
class information
{

    public static void main(String args[])
{
    String name,salary,city;
      int id;
         
      
      Scanner ob =new Scanner(System.in);

     

      System.out.println("Enter id=");
      id=ob.nextInt();


      switch(id)

  {                    

    case 1:
            
     
       System.out.println("Student name=Prashant");
       
       System.out.println("Student height=5.6");
       
       System.out.println("Student weight=67");
       
       System.out.println("Student division=A");
            break;

    
    case 2:
            
     
       System.out.println("Student name=Akashay");
       
       System.out.println("Student height=5.6");
       
       System.out.println("Student weight=61");
       
       System.out.println("Student division=B");
            break;


    
    case 3:
            
     
       System.out.println("Student name=Amit");
       
       System.out.println("Student height=5.1");
       
       System.out.println("Student weight=58");
       
       System.out.println("Student division=C");
        break;


    case 4:
            
     
       System.out.println("Student name=Pratap");
       
       System.out.println("Student height=5.7");
       
       System.out.println("Student weight=77");
       
       System.out.println("Student division=D");
            break;

   
    case 5:
            
     
       System.out.println("Student name=Prasad");
       
       System.out.println("Student height=6.1");
       
       System.out.println("Student weight=64");
       
       System.out.println("Student division=E");
            break;
  
default: 
System.out.println("wrong input");
break;

      

}
      
  

      


      


      


      












}
}