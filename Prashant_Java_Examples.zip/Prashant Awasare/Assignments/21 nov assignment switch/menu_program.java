//Q.1 WAP to diplay menu program and perform task according input using switch case.1.Add 2.Sub.3.Mul.Div.
 
import java.util.*;
class menu_program
{

    public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);

    System.out.println("1.Addition");
    
    System.out.println("2.Subtraction");
    
    System.out.println("3.Multiplication");
   
    System.out.println("4.Division");
    
    System.out.println("enter your choice");
    int l=ob.nextInt();
    
     int a=ob.nextInt();
     int b=ob.nextInt();
    int sum=a+b;
   int sub=a-b;
   int mul=a*b;
   double div=a/b;
  switch(l)
 {   
   case 1:
   System.out.println("your choice is addition"+" "+sum);
   break;
   case 2:
   System.out.println("your choice is subtraction"+" "+sub);
   break;
   case 3:
   System.out.println("your choice is multiplication"+" "+mul);
   break;
   case 4:
   System.out.println("your choice is division"+" "+div);
   break;

  default:
   
   System.out.println("your choice is wrong");
   break;

}
   }
}
   
