//Q.8;Print this pattern
    //*
    //**
    //***
    //****
    //*****
    //*****
    //****
    //***
    //**
    


class star_pattern8
{
	public static void main(String args [])
	{




       int i=1;
           
for(i=1;i<=5;i++)
{
    
    int j=1;
   for(j=1;j<=i;j++)
  { 
     System.out.print("*");

    }
   System.out.println();


}
  i=1;
           
for(i=5;i>=1;i--)
{
    
    int j=1;
   for(j=1;j<=i;j++)
  { 
     System.out.print("*");

    }
   System.out.println();


}













               }



}
