
//Q.3
class starpattern4

   {


        public static void main(String args[])
        {


          int row , col;

               for( row=6; row>=1; row--)
                 {

                      
                           for(col=row; col<=6; col++)
                            System.out.print("  ");

                            for(col=1; col<=row; col++)
                            System.out.print("*"+" ");
                      

                            

              System.out.println();
              }
     




        }


 }