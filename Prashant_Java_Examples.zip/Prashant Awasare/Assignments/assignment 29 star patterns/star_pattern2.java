//Q.2;Print this pattern
    //*****
    //****
    //***
    //**
    //*


class star_pattern
{
	public static void main(String args [])
	{




       int i=5;
      
for(i=5;i>=1;i--)
{
    
    int j=1;
   for(j=1;j<=i;j++)
  { System.out.print("*");

    }
   System.out.println();


}













               }



}
