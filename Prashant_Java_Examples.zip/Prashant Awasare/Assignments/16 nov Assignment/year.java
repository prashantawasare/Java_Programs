import java.util.Scanner;
class year

{

    public static void main(String args[])


{

  Scanner ob=new Scanner(System.in);

  double year,amount,rate;

   System.out.print("enter year");
   year=ob.nextDouble();
   

   System.out.print("enter a amount");
   amount=ob.nextDouble();
   System.out.print("enter a rate");
   rate=ob.nextDouble();




  while(year<=3)
{
   double si=(amount*rate*year)/100;

 
  
  System.out.println("\t"+(int)year);
   System.out.println("\t\t\t Amount"+amount);
  
   System.out.println("\t\t\tRate"+rate);
   
   System.out.println("\t\t\tsimple interest"+si);

 year++;

}



}

}



   

   

   
   
  

   


