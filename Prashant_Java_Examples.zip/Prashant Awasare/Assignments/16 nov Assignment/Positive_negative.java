//Q.1 Writ a program input an no to check no is positive or negative

import java.util.*;

  class Positive_Negative
  {

     public static void main(String []args)

   {  Scanner ob=new Scanner(System.in);

      System.out.println("enter a number");
      int a=ob.nextInt();

       if (a>0)

          System.out.println("Number is positive");
      
      else

         System.out.println("Number is negative");

}
}
