//Q.4 Write a program to print 10 is less than 15.

import java.util.Scanner;

class  less_than

  {

    public static void main(String args[])

{   Scanner ob=new Scanner(System.in);

   int a=ob.nextInt();
   int b=ob.nextInt();

    if (a<b)

      System.out.println("10 is less than 15");
else
     System.out.println("10 is grtater than 15");
   }
}