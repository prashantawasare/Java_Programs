//Q.6 Take two int values from user and print greatest among them.
import java.util.Scanner;
 class Gretest
{

   public static void main(String  args[])

   {   Scanner ob=new Scanner(System.in);
      System.out.println("Enter a first number");
      int a=ob.nextInt();
      System.out.println("Enter a second number");
      int b=ob.nextInt();
     
       if (a>b)

        System.out.println("First number is greatest");

      else
       System.out.println("First number is not greatest");
}
}
