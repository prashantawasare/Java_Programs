//Q.10 Wap enter a no and check it is divisible by 5 or not.
import java.util.Scanner;
class Divisible
{
   public static void main(String args[])

{
  Scanner ob=new Scanner(System.in);

     int a=ob.nextInt();
     

    if (a%5==0)
      
      
      System.out.println("no is divisible byy 5");
     

    else

     
       System.out.println("no is not divisible by 5 ");
   
    
}
}