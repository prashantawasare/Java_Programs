//Q.13 Write a program to input marks of five subjects Physic,chemistry,Biology
     //Mathmatics and computer.Calculate percentage and grade according to following:
   
   import java.util.Scanner;

     class Percentage

      {

        public static void main(String [] args)

     {

        Scanner ob=new Scanner(System.in);

         System.out.println("enter a marks of physics");
          int a=ob.nextInt();

         System.out.println("enter a marks of chemistry");
          int b=ob.nextInt();

         System.out.println("enter a marks of biology");
         int c=ob.nextInt();

         System.out.println("enter a marks of mathematics");
          int d=ob.nextInt();

        System.out.println("enter a marks of computer");

          int e=ob.nextInt();

           double percen=((a+b+c+d+e)/5);

            if (percen>90)
                
              System.out.println("Grade A"+" "+percen);

         else if(percen>80)
         
              System.out.println("Grade B"+" "+percen);

          else if (percen>70)
      
              System.out.println("Grade c"+" "+percen);

          else if (percen>60)

             System.out.println("Grade D"+" "+percen);

          else if (percen>40)
            System.out.println("Grade E"+" "+percen);

         else if (percen<40)

          System.out.println("Grade E"+" "+percen);

}

}
             

              

    