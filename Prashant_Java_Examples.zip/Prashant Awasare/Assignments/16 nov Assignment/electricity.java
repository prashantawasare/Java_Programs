//Q.15 Write a program to input electricity unit charges and calculate total elsectrcity bill according to the given condition;
    // For first 50 units RS .0.50/unit
   //  For next 100 units Rs.0.75/unit
   //  For next 100 units Rs.1.20/unit
   //  An additional surcharge of 20% is added to the bill.

  import java.util.Scanner;
  class electricity

 {
    public static void main(String args[])

   {

      Scanner ob=new Scanner(System.in);

   System.out.println("enter first  unit");
    int a=ob.nextInt();
   
      System.out.println("enter second  unit");
    int b=ob.nextInt();
    
     System.out.println("enter third  unit");
    int c=ob.nextInt(); 

     if (a>=50 )
{
        double amount=a*0.50;
         double surcharge=amount*0.20;
         double total_bill=amount+surcharge;
         System.out.println("amount"+amount);
        System.out.println("total electricity charges"+total_bill);}



   else if(b>=150)
   {    

      double amount=b*0.75;
      double surcharge=amount*0.20;
      double total_bill=amount+surcharge;
     System.out.println("amount"+amount);
     System.out.println("total electricity charges"+total_bill);}

   else if(c>=250)

  {
     double amount=c*1.20;

    double surcharge=amount*0.20;
      double total_bill=amount+surcharge;  
   

      
        System.out.println("amount"+amount);
        System.out.println("total electricity charges"+total_bill);}

}

}

    
    
    
    

    

       

      