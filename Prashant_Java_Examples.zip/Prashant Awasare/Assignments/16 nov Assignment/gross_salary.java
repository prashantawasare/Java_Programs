//Q.14 Write a program to input basic salary of an employee and calculate its gross
     //salary according to following;
      //Basic salrary<=10000: HRA =20%   DA=80%;
      // Basic salrary<=20000: HRA =25%   DA=90%;
      // Basic salrary>20000: HRA =30%   DA=95%;

    import java.util.Scanner;

    class gross_salary

     {

        public static void main(String args[])
    {

        Scanner ob=new Scanner(System.in);

        System.out.println("enter basic salary");
         int BS=ob.nextInt();

      double HRA,DA,GS;

         if(BS<=10000)
{
             HRA=0.2*BS;
             DA=0.8*BS;
             GS=HRA+DA+BS;
           System.out.println("HRA of employee"+HRA);
            System.out.println("DA of employee"+DA);
             System.out.println("Gross salary="+GS);}

  
 else if(BS<=20000)

   {          HRA=0.25*BS;
             DA=0.90*BS;
             GS=BS+DA+HRA;

       System.out.println("HRA of employee"+HRA);
            System.out.println("DA of employee"+DA);

            System.out.println("Gross salary="+GS);}


   else if(BS>=20000)

         {   HRA=0.30*BS;
            DA=0.95*BS;
            GS=HRA+DA+BS;

           System.out.println("HRA of employee"+HRA);
            System.out.println("DA of employee"+DA);

           System.out.println("Gross salary="+GS);}

   
}

}
      