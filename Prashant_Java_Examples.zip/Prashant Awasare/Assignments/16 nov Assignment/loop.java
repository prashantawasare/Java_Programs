import java.util.Scanner;
class loop
{

     public static void main(String args[])
{

    Scanner ob=new Scanner(System.in);

  int i=ob.nextInt();

while (i<=100)

{

     if(i%2!=0)
  System.out.print(i+" ");
  i++;

}

  }

  }