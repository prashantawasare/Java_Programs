import java.util.Scanner;
class loops
{

   public static void main(String args[])

{
     Scanner ob=new Scanner(System.in);
     int i;
     System.out.println("enter a number");
       i=ob.nextInt();

    while(i<=300)
    { 
      System.out.print(i+" ");
     i++;}


}

}