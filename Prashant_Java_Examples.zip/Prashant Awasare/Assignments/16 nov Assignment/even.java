//Q.11 Wap enter a no and check it is even or odd.
  import java.util.*;

   class even 
{
   public static void main(String args[])
   {

     Scanner ob=new Scanner(System.in);

     int a=ob.nextInt();

     if (a%2==0)

       System.out.println("Number us even");

    else

     System.out.println("number is odd");

}

}
 

   