//Q.2  Wap input an no and check it is even or  odd.

   import java.util.*;
 
  class Even_or_Odd

{

   public static void main(String args[])

{

    Scanner ob=new Scanner(System.in);

     System.out.println("enter a number");
     int a=ob.nextInt();
   
     if (a%2==0)

         System.out.println("number is even");

    else
     System.out.println("number is odd");

}

}