//Q.8 A company decided to give bonus of 5% to employee if his/her year of service is more than 5 years
//Ask user for their salary and year of service and print their net bonus amount.
   import java.util.Scanner;

   class bonus
{

  public static void main(String args[])

  {


    Scanner ob=new Scanner(System.in);

     int bs=ob.nextInt();
     int year=ob.nextInt();

    if (year>5)
      {
      Double bonus=bs*0.005;
      System.out.println("You got a bonus"+bonus);
     }

    else 

     {
       System.out.println("you did not get bonus");
   
    }


}
}
    