//Q.5 Wap to take value of  length and bredth of rectangle from user and check if it is square.
import java.util.Scanner;
class Length_Breadth
 {

    public static void main(String args[])
{
     Scanner ob=new Scanner(System.in);

     System.out.println("Enter length of  rectangel");
     int a=ob.nextInt();

     System.out.println("Enter breadth of  reactangle");
     int b=ob.nextInt();

    if (a==b)

     System.out.println("It is square");

    else

    System.out.println("It is not square");

}

}