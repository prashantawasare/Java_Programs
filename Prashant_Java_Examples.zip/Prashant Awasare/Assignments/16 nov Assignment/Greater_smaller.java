//Q3.Wap input two no and check greater and smaller among them.

   import java.util.Scanner;

 class Greater_or_smaller
{

  public static void main(String args[])
  {

     Scanner ob=new Scanner(System.in);

     int a=ob.nextInt();
     int b=ob.nextInt();
    
  if (a>b)

    System.out.println("a is greater");

    if (b>a)

   System.out.println("b is greater");

   if (a<b)

   System.out.println("a is smaller");

   if (b<a)

    System.out.println("b is smaller");
}
} 