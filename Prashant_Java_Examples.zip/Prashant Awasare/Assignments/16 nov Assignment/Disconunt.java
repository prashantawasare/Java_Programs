 //Q.7 A shop will give discount of 10% if the cost of purchased quantity is more than 1000.
    //Ask user for quantity
    //Suppose,one unit wil cost 100.
    //Judge and print total cost for user.

 import java.util.Scanner;
  class Shop

{

   public static void main(String args[])
{

   Scanner sc=new Scanner(System.in);

    
  
   System.out.println("enter  quantity");
   int q=sc.nextInt();

    double amount=q*100;

    if (amount>1000)
        {  double discount=amount*0.10;
          double total=amount-discount;
    System.out.println("You got a discount"+discount);
    
    System.out.println("your purchase amount"+amount);
   System.out.println("total cost for user"+total);
}



     else  
     {System.out.println("you did not got a discount"+amount);}
}
}

