//Q.12 Write a program enter three sides of traingle and check which type of traingel it is



import java.util.Scanner;
 
  class Trinagles

   {

   public static void main(String[]args)

    {
      Scanner ob=new Scanner(System.in);


      System.out.println("enter first side of traingle");
      int a=ob.nextInt();

      System.out.println("enter second sides of traigle");
      int b=ob.nextInt();

      System.out.println("enter third sides of trainge");
      int c=ob.nextInt();

      if (a==b  &&  b==c && a==c)

         System.out.println("traingle is equilteral");

      else if (a!=b &&    b==c && a!=c)

         System.out.println("traigle is isosceles ");
      
     else if (a!=b && b!=c && c!=a)

          System.out.println("traingle is scalene");

      else 
     System.out.println("not a traingle");
}

} 