//Q2.Wap enter an array and search any particular element and found the count of that.





class question2
{
  public static void main(String args[])
{
    

   int a[]={1,2,3,4,5};

    int i,k=5,c=0;
for(i=0;i<a.length;i++)
{
   if(k==a[i])
    c++;
  
    }
     System.out.print("number found");
  System.out.println("\ncount="+c);
}
}