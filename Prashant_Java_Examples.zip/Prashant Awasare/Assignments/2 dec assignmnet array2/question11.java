//Q11.a[]={10,20,30,40,50}
   //b[]={1,2,3,4,5}
 
  //output array=c[]={10,5,20,4,30,3,40,2,50,1}







import java.util.*;
class question11
{
   public static void main(String args[])
{
  int i,j;
 int[]a={1,2,3,4,5,6,7};
 int []b={8,9,10,11,12,13,14,15};
 int c=a.length+b.length;
 int []d=new int[c];
for(i=0;i<a.length;i++)
 {   
     d[i]=a[i];
    
   
        } 
    
   for(i=0;i<b.length;i++)
 { 
   
   d[a.length+i]=b[i];


      }
  for(i=0;i<d.length;i++)
  {
    System.out.print(d[i]+" ");

        }

      
      
                         }
       
    
       
 


                  }