//Q9. Wap enter an array and print element present at even position and  find their square.






import java.util.*;
class question9
{
   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);
int i,length;
int a[]=new int[]{6,2,3,4,5,7,9,10};
 int c=0,square=0;
for(i=1;i<a.length;i=i+2)
 {   
 
   square=a[i]*a[i];
     
   System.out.println(square); 
   } 
    


      
      
 }
       
    
       
 


   }