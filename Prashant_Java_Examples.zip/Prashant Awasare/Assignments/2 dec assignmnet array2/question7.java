//Q7.Wap enter an array and search any two element and print the result.





class question7
{
  public static void main(String args[])
{
    

   int a[]={1,2,4,6,5};

    int i,k=1,c=5,r=0,t=0;
for(i=0;i<a.length;i++)
{    

    if(k==a[i])
    t=1;
    if(c==a[i])
    r=1;}
  if(t==1 && r==1)
  { System.out.println("both numbers  found");}
    else
   {
     if(t==1 && r!=1)
     System.out.println("first number found ");
     else if(t!=0 && r==1)
     System.out.println("second number found");


  }
}
}