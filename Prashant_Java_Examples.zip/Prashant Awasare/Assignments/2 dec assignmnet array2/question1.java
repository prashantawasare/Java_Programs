//Q1.Wap enter an array and search any particular element.



class question1
{
  public static void main(String args[])
{
    

   int a[]={1,2,3,4,5};

    int i,k=5;
for(i=0;i<a.length;i++)
{
   if(k==a[i])
    
  System.out.print("number found");
    }
  }
}