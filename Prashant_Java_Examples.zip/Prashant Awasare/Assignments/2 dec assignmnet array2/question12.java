//Q12.Wap sort half array in accending and half in decending order
    //input= int [] a={9,1,3,5,6,11,22,66,10,19}.
    //output={1,3,5,6,9,10,66,22,19,11,10},




class acending
{
   public static void main(String sd[])
{
    int []a={9,1,3,5,6,11,22,66,10,19};

     int  temp,i,j;
  for( i=0;i<a.length/2;i++)
{
    for( j=i+1;j<a.length;j++)
   {     
      if(a[i]<a[j])
   {
      temp=a[i];
      a[i]=a[j];
      a[j]=temp;}

     }

   }

     
  for( i=0;i<a.length/2;i++)
{
    for( j=i+1;j<a.length;j++)
   {     

      if(a[i]>a[j])

   {
      temp=a[i];
      a[i]=a[j];
      a[j]=temp;}

     }

   }for(i=0;i<a.length;i++)

   {
     System.out.println(a[i]);}

                 }

             }