//Q8. Wap enter an array and print element present at odd position and  find their square.






import java.util.*;
class question8s
{
   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);
int i,length;
int a[]=new int[]{6,2,3,4,5};
 int c=0,square;
for(i=0;i<a.length;i=i+2)
 {   
 
   square=a[i]*a[i];
     
    System.out.println(square);
   } 
    


      
      
 }
       
    
       
 


   }