//Q3.Wap enter an array and sort that in accending order.


class question3
{
  public static void main(String args[])
{
    

   int a[]={1,2,4,6,5};

    int i,c;
for(i=0;i<a.length;i++)
{    int j;
   for(j=i+1;j<a.length;j++)
    {
      if(a[i]>a[j])
      {
         c=a[i];
         a[i]=a[j];
         a[j]=c;
         }
     }
 }
  
    for(i=0;i<a.length;i++)
  {

     System.out.println(a[i]);}
  
}
}