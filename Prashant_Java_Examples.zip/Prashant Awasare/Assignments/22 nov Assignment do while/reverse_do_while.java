//5:Find the Reverse of IT;
      //12345
      //54321
class reverse_do_while
{
 public static void main(String args[])
{

  int i=12345,rev=0,rem;
   
 

{   if(i<=0)

     System.out.println("not possible");

   else

    do 

   {  rem=i%10;

    rev=rev*10+rem;
  

    
     i=i/10;
    
      
   
} while(i!=0);

}

    System.out.println(rev);
}

}