//2: Count the Even odd in  The Same program ;
import java.util.Scanner;
class even_or_odd_do_while
{

   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);

  int i=ob.nextInt();
  int d=0,odd=0;
  

   do
  {

     int rem=i%10;

    System.out.print(rem+" ");

     i=i/10;
    
   if(rem%2==0)
   d++;
   else
   odd++;
   
}
   while(i!=0);

   


   System.out.println("\neven numbers="+d);
   System.out.println("odd numbers="+odd);
   
}

}