//6: Check Palindrome Number:
       //Those number which is equal to the reverse of itself is called 
     //Palindrome number.

class palindrome_do_while
{
 public static void main(String args[])
{

  int n=121;
   if(n<0)
    
   
  System.out.println("not possible");
  
else

{ 
   int i,rem,rev=0;
    i=n;
    

   

    
   do
   { 
      rem=i%10;

    rev=rev*10+rem;
    

  

    
     i=i/10;
    
      
   
}while(i!=0);  



    System.out.println("rev"+rev);
     if(rev==n)
     System.out.println("panlindrome");
 
    else
     System.out.println("not panlindrome");
}
     
}

}