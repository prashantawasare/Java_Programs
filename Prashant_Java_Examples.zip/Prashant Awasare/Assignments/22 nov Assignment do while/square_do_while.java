//4: 12345
     // Find the Quare of each Number :
      //5  25
     // 4   16
      //3   9
     // 2   4
      //1   1
class square_do_while
{
 public static void main(String args[])
{

  int i=12345,square=0,rem;
   
  

{   if(i<=0)

     System.out.println("not possible");

   else

     do

   {  rem=i%10;

    
  

    square=rem*rem;
     i=i/10;
     
   System.out.println(rem+" "+square);

  } while(i!=0);
    

 }
}

 }