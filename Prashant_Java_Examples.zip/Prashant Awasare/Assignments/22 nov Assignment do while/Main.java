 class sum_do_while
{
	public static void main(String[] args) 
	{
	  int n =12345;
	     if(n<0)
	        System.out.println(" Not Possible ");
	        else 
	         {
	             
	             int i , sum =0, rem ;
	             i=n;//initilaization;
	           do
	            {
	                 rem=i%10;
	                 sum=sum+rem;
	             
	          
	                i=i/10;
	              
	                
	            } while(i!=0);
	            
	            
	            System.out.println("Sum ="+sum);
	             
	             
	             
	             
	             
	             
	         }
	}
}
