 //3: Find the sum of all numbers
class sum_do_while
{

   public static void main(String args[])
{

  

   int i=1234;
   int sum=0;
   int c=0;
   
     do

     {   int rem=i%10;
          System.out.print(rem+" ");

          if(rem%2==0)
            c++;



          
          
           sum=sum+rem;
           
           
           i=i/10;
           }while(i!=0);
  System.out.println("\nthe sum of numbers="+sum);
  
}

}



