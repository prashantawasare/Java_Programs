//Q15.Wap enter an array and find the no in array  which is equal to the sum of 1st and last element.






class  question15
{
  public static void main(String arg[])
  {

     int i,length;
   int a[]={1,2,3,6,4,5};
    
      int sum=0;
   for(i=0;i<a.length;i++)
  {  
       sum=a[0]+a[5];
   
  
    
     }for(i=0;i<a.length;i++)
      {
        if (a[i]==sum)
        System.out.print(a[i]+" ");
   
     
    
}
      
     




}
}

