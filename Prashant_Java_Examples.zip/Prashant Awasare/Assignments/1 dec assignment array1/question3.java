//Q3.Wap to input an array and and print the  sum of  even no.






import java.util.*;
class question3
{
   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);
int i,length;
int a[]=new int[5];
for(i=0;i<a.length;i++)
{
   a[i]=ob.nextInt();

     }


   int sum=0,even=0;
   for(i=0;i<a.length;i++)
  {   
     if(a[i]%2==0)
    {    even++;
      sum=sum+a[i];
     }
     
   }
    
    System.out.println("sum evevn numbers="+sum);
      
   
     
    
    
    System.out.println("count of evevn numbers="+even);
   




      }
 


   }