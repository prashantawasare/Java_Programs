//Q6. Wap enter an array and print element present at odd position and also find count.






import java.util.*;
class question6
{
   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);
int i,length;
int a[]=new int[]{6,2,3,4,5};
 int c=0;
for(i=0;i<a.length;i=i+2)
 {   
 
    System.out.println(a[i]);
     
    c++;
   } 
    


      
      
 
       
    
       
        System.out.println("count of element present at odd position="+c);
    
    


      }
 


   }