//Q5. Wap enter an array and print element present at even position and also find count.






import java.util.*;
class question5
{
   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);
int i,length;
int a[]=new int[]{6,2,3,4,5};
 int c=0;
for(i=1;i<a.length;i=i+2)
 {   
 
    System.out.println(a[i]);
     
    c++;
   } 
    


      
      
 
       
    
       
        System.out.println("count of even numbers present at even numbers="+c);
    
    


      }
 


   }