//Q9.WAP to check if an array of integers contains two specified elements.






import java.util.Scanner;
class question9_
{
public static void main(String arg[])
{
    Scanner ob=new Scanner(System.in);
    int i,j=2,c=0,x,y,r=0,k=0;
    int[]a=new int[5];
    System.out.println("size of the array="+a.length);
     System.out.println("enter the elements");
     for(i=0;i<a.length;i++)
     {
    a[i]=ob.nextInt();
     }
    System.out.println("enter the nos you want to search");
    x=ob.nextInt();
    y=ob.nextInt();
   for(i=0;i<a.length;i++)
    {
   if(x==a[i])
   r=1;
   if(y==a[i])
    k=1;
    }
   if(r==1 && k!=1)
    System.out.println(" x  is  found and y is not found"); 
     else
     {
      if(r==1 && k==1)
         System.out.println(" both are found");

     else if(r!=1 && k==1)
        System.out.println(" x is   notfound and y is  found");
    else
        System.out.println("both element not found");
}
}
}
