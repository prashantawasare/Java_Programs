//Q2.Wap to input an array and find its average of first 5 element.




import java.util.*;
class question2
{
   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);
int i,length;
int a[]=new int[10];
for(i=0;i<a.length;i++)
{
   a[i]=ob.nextInt();

     }


   double sum=0,average=0;
   for(i=0;i<a.length;i++)
  {   
  
   sum=a[0]+a[1]+a[2]+a[3]+a[4];
  average=sum/5;

     }System.out.println("average of first five elements="+average);






      }
 


   }