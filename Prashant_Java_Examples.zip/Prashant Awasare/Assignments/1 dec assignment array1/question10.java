//Q10.Wap enter an array and find the duplicate element and also count of that.







import java.util.*;
class question10
{
   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);
int i,length;
int a[]={6,2,3,4,5,6,2,3};
 int c=0; 
for(i=0;i<a.length;i++)
 {   

   for(int j=i+1;j<a.length;j++)
     if(a[i]==a[j])
      c++;
      
     
     
   } 
    
    System.out.println(c+" ");


      
      
 
       
    
       
        
    
    


      }
 


   }