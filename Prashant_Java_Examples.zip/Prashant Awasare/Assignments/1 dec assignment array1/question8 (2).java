//Q8.Wap enter an array and search any particular element and find the count.






import java.util.*;
class question8
{
   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);
int i,length;
int a[]=new int[]{6,2,3,4,5};
 int c=0; int k=6;
for(i=0;i<a.length;i++)
 {   
     if(a[i]==k)
    {  c++;
    
     
    System.out.println("number found");}
   } 
    

   System.out.println("count="+c);
      
      
 
       
    
       
        
    
    


      }
 


   }