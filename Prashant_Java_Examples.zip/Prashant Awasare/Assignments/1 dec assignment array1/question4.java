//Q4.Wap to input an array and and print the  sum and count of odd  no.






import java.util.*;
class question4
{
   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);
int i,length;
int a[]=new int[5];
for(i=0;i<5;i++)
{
   a[i]=ob.nextInt();

     }


   int sum=0,odd=0;
   for(i=0;i<5;i++)
  {   
     if(a[i]%2!=0)
      
    { odd++;
     
   sum=sum+a[i];
   }
   
   
     }    System.out.println("count of odd numbers="+odd);
    
    System.out.println("sum of odd numbers="+sum);
    




      }
 


   }