/*Q1.Wap to input an array and find
  no of positive no.
  no of negative no.*/



import java.util.*;
class question1
{
   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);
int i,length;
int a[]=new int[5];
for(i=0;i<5;i++)
{
   a[i]=ob.nextInt();
}
System.out.println("postive numbers=");
System.out.println("negative numbers=");

for(i=0;i<5;i++)
  if(a[i]>0)
 { System.out.print(" "+a[i]);}
  else
  {System.out.print("\n"+a[i]);
}


}
}