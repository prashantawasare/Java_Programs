//Q12.Wap enter an array and print the square of the element which is on even position.







import java.util.*;
class question12
{
   public static void main(String args[])
{
  Scanner ob=new Scanner(System.in);
int i,length;
int a[]=new int[]{6,2,3,4,5};
 int c=0;int v=0; 
for(i=1;i<a.length;i=i+2)
 {   
     v=a[i]*a[i];
      
      System.out.print(v+" ");
     
    
   } 
    


      
      
 
       
    
       
        
    
    


      }
 


   }