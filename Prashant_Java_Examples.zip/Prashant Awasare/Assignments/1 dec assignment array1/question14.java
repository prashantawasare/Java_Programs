//Q14.Wap enter an array and print it in reverse order.



class question14
{
 public static void main(String []args)
{
  int a[]={12,3,4,5,62,9};
      int i;
   for(i=a.length-1;i>=0;i--)
{
     System.out.print(a[i]+" ");
     }

   }
}