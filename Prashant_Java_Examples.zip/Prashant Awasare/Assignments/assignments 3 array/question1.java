//Q1.Wap enter an array and print the square of the element which is present at even position

 class square
{
   public static void main(String hsbd[])
{
   int a[]={1,2,3,4,5,7};

    int i;

  for(i=0;i<a.length;i=i+2)

{
    System.out.println(a[i]*a[i]);

      }


    }
}