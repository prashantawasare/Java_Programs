//Q6.Wap input an array and rotate it in anti clock wise by any no give by user.



import java.util.Scanner;


class anticlockwise
{
   public static void main(String arfs[])
{
  

   Scanner ob=new Scanner(System.in);

     int a[]=new int[5];

     int i,j;
System.out.println("enter elements in array");
    for(i=0;i<a.length;i++)
{
   a[i]=ob.nextInt();

    }

  System.out.println("enter the number of rotation");
     int n=ob.nextInt();

 for(i=0;i<n;i++)
{    

      int last=a[a.length-1];
   for(j=a.length-1;j>0;j--)
  {    
   a[j]=a[j-1];}
   
     a[0]=last;
  }

 
 System.out.println("left roatation");


  for(i=0;i<a.length;i++)
{    
   System.out.print(a[i]+" ");

    }


}
}


