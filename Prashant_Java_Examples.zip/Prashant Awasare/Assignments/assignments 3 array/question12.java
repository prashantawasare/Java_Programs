//Q12. Write a Java program to compute the average value of an array of integers except the largest and smallest values.




class question12
{
  public static void main(String ag[])
{
   int a[]={1,11,3,5,7,2,4};

   int i,k,j;

for(i=0;i<a.length;i++)
{
   for(j=i+1;j<a.length;j++)
  if(a[i]>a[j])
{
   k=a[i];
   a[i]=a[j];
   a[j]=k;
  }
      }int sum=0;
       double average;
for(i=1;i<a.length-1;i++)
{
  sum=sum+a[i];}
  average=sum/5;
  System.out.print("average of numbers except  the largest and smallest values="+average);

     

   }
}

   