//Q13. Wap enter an array and find the frequency(duplicate elements) on each characters.


 class question13 
{
   public static void main(String[] args) 
  {

 
		
		 
   int i,j;

  int a[]= {1,2,1,4,2,4,5,5};

  int b[]=new int[a.length];
   
    int c=-1;
 
    for( i=0;i<a.length;i++)
  {
      int count=1;
    for( j=i+1;j<a.length;j++)
    {
       if(a[i]==a[j])
      {
        count++;
        b[j]=c;
       }

     }
    

     if(b[i]!=c)
     {
   
       b[i]=count;

        }
   }
   System.out.println("array without duplicate element");
   for(i=0;i<b.length;i++)
    {
        if(b[i]!=c)
      {System.out.println(a[i]+" "+b[i]);}

       }

    }
}
   








	  


