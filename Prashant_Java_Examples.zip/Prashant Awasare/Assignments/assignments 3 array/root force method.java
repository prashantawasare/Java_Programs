//Q13. Wap enter an array and find the frequency(duplicate elements) on each characters.
//root force method

 class question13 
{
	 public static void main(String[] args) 
	 {
		 int i,j;
		 int a[]= {1,2,1,4,2,4,5,5};
		
		 
		  System.out.println("duplicate elements in array");
		  for(i=0;i<a.length-1;i++)
		  {
			    
			  for(j=i+1;j<a.length;j++)
			  {
				  if(a[i]==a[j] && i!=j)
				  {
					System.out.println(a[i]); 
					  
				  }
			  }


               }











	  
}
}
