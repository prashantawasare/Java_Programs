//Q4.Wap sort half array in accending and half in decending order
  // input= int [] a={9,1,3,5,6,11,22,66,19,10}.
 //output={1,3,5,6,9,10,66,22,19,11,10},

class acendings
{
   public static void main(String sd[])
{
    int []a={9,1,3,5,6,11,22,66,10,19};

     int c ,i,j,d;
  for( i=0;i<a.length/2;i++)
{
    for( j=i+1;j<a.length/2;j++)
   {     
      if(a[i]>a[j])
   {
      c=a[i];
      a[i]=a[j];
      a[j]=c;}

     }

   }for(i=0;i<a.length/2;i++)
   {
       System.out.println(a[i]);
       }

     
  for( i=a.length/2;i<a.length;i++)
{
    for( j=a.length/2;j<a.length;j++)
   {     

      if(a[i]<a[j])

   {
      d=a[i];
      a[i]=a[j];
      a[j]=d;}

     }

   }for(i=a.length-1;i>a.length/2;i--)

   {
     System.out.println(a[i]);}

                 }

             }