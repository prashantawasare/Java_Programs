//Q2.Wap input two array and merge in third array.
import java.util.*;
class merge
{
   public static void main(String args[])
{
  int i,j;
 int[]a={1,2,3,4,5,6,7};
 int []b={8,9,10,11,12,13,14,15};
 
 int []d=new int[a.length+b.length];
for(i=0;i<a.length;i++)
 {   
     d[i]=a[i];
   

   
        } 
for(i=0;i<b.length;i++)
 { 
    d[a.length+i]=b[i];
   

      }
    
   
  for(i=0;i<d.length;i++)
  {
    System.out.print(d[i]+" ");

        }

      
      
                         }
       
    
       
 


                  }