//Q6.Wap input an array now delete  element from array, position is taken from user.

import java.util.Scanner;
class question6
{
  public static void main(String df[])
{
   Scanner ob=new Scanner(System.in);
   int a[]=new int[5];

    int i,j;

for(i=0;i<a.length;i++)
{
   a[i]=ob.nextInt();

    }System.out.println("elements in array");
for(i=0;i<a.length;i++)
{
  System.out.print(a[i]+" ");

    }
   System.out.println("enter position you wants to remove");




  int  o=ob.nextInt();
  


  for(i=o;i<a.length;i++)
{


  
      if (o==[i])
     {
       for( j=i;j<a.length-1;j++)
      {
         a[j]=a[j+1];
        }break;
      }
          
   }

for(i=0;i<a.length-1;i++)
{

    System.out.print(a[i]+" ");

    }

  }
}