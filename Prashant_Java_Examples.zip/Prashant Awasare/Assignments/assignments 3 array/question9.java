//Q9. Write a Java program to find max number in an array.

class question9
{
  public static void main(String as[])
{
   int a[]={1,2,3,45,5,8,9};

    int k=0;
for(int i=0;i<a.length;i++)
{
    if(a[i]>k)
     k=a[i];

     }System.out.println("maxmum number="+k);

         }
  }
   