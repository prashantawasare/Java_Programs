//Q8.Wap input an array and delete all duplicate element from array.


class question8
{


   public static void main(String ard[])
{
   int a[]={1,2,3,3,4,4,5,6,7};
    int b[]=new int[a.length];
   
    int c=-1;int j,i;
 
    for( i=0;i<a.length;i++)
  {
      int count=1;
    for( j=i+1;j<a.length;j++)
    {
       if(a[i]==a[j])
      {
        count++;
        b[j]=c;
       }

     }
    

     if(b[i]!=c)
     {
   
       b[i]=count;

        }
   }
   System.out.println("array without duplicate element");
   for(i=0;i<b.length;i++)
    {
        if(b[i]!=c)
      {System.out.println(a[i]+" ");}

       }

    }
}
   
  


   
















                              
                  




      