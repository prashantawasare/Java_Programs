//Q5.Wap input an array now delete  element from array, element is taken from user.

import java.util.Scanner;
class question5
{
  public static void main(String df[])
{
   Scanner ob=new Scanner(System.in);
   int a[]=new int[5];

    int i,j;

for(i=0;i<a.length;i++)
{
   a[i]=ob.nextInt();

    }System.out.println("elements in array");
for(i=0;i<a.length;i++)
{
  System.out.print(a[i]+" ");

    }
   System.out.println("enter element you wants to remove");




  int  b=ob.nextInt();
  

  for(i=0;i<a.length;i++)
{


  
      if (b==a[i])
     {
       for( j=i;j<a.length-1;j++)
      {
         a[j]=a[j+1];
        }break;
      }
          
   }

for(i=0;i<a.length-1;i++)
{

    System.out.print(a[i]+" ");

    }

  }
}