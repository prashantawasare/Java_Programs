//Q14.Wap to input 3*3  matrix and print it.



import java.util.Scanner;
class twodarray3
{
  public static void main(String args[])
{
   Scanner ob=new Scanner(System.in);
  
   int[][]arr=new int[3][3];

    int row,col;
 for(row=0;row<3;row++)
{
   for(col=0;col<3;col++)

   arr[row][col]=ob.nextInt();

   }
     for(row=0;row<3;row++)
{
   for(col=0;col<3;col++)
    System.out.print(arr[row][col]+" ");
   
     System.out.println();

    }


   }
}