//Q11. Write a Java program to get the difference between the largest and smallest values in an array of integers.
// The length of the array must be 2 and above.


class question11
{
  public static void main(String ag[])
{
   int a[]={1,11,34,56,78,23,43};

   int i,k,j;

for(i=0;i<a.length;i++)
{
   for(j=i+1;j<a.length;j++)
  if(a[i]>a[j])
{
   k=a[i];
   a[i]=a[j];
   a[j]=k;
  }
      }
for(i=0;i<a.length;i++)
{
  System.out.print(a[i]+" ");}

  System.out.print("\ndifference betwwen largest and smallest value="+(a[0]-a[a.length-1]));

     

   }
}

   