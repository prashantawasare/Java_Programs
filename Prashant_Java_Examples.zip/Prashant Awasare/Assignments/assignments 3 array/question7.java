//Q7.Wap input an array and rotate it in  clock wise by any no give by user.




import java.util.Scanner;


class clockwise
{
   public static void main(String arfs[])
{
  

   Scanner ob=new Scanner(System.in);

     int a[]=new int[5];

     int i,j;
System.out.println("enter elements in array");
    for(i=0;i<a.length;i++)
{
   a[i]=ob.nextInt();

    }

  System.out.println("enter the number of rotation");
     int n=ob.nextInt();

 for(i=0;i<n;i++)
{    
      int first=a[0];
   for(j=0;j<a.length-1;j++)
  {    
   a[j]=a[j+1];}
   
     a[a.length-1]=first;
  }

 
 System.out.println("right roatation");


  for(i=0;i<a.length;i++)
{    
   System.out.print(a[i]+" ");

    }


}
}


