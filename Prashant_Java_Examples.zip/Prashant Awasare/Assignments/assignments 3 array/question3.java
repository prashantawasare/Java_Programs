//Q3.a[]={10,20,30,40,50}
   //b[]={1,2,3,4,5}
 
  //output array=c[]={10,5,20,4,30,3,40,2,50,1}

class merging
{
   public static void main(String args[])
{
  int i,j;
 int[]a={10,20,30,40,50};
 int []b={1,2,3,4,5};
 
 int []c=new int[a.length+b.length];
  int h;
int s=b.length-1;
for(i=0;i<a.length;i++)
 {   
     
    c[h]=a[i];
    h++;
    c[h]=b[s];
    h++;
    s--;

     }

   for(h=0;h<a.length;h++)
{
  System.out.println(c[h]);


            }
           
               
      
                         
          


                  


















                                    }
         
                               }