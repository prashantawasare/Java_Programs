//Q10.Wap input an array now insert any element at any position ,
    //element and position is taken by user.


import java.util.Scanner;
class question10
{
  public static void main(String df[])
{
   Scanner ob=new Scanner(System.in);
   int a[]=new int[5];

    int i,j;

for(i=0;i<a.length;i++)
{
   a[i]=ob.nextInt();

    }System.out.println("elements in array");
for(i=0;i<a.length;i++)
{
  System.out.print(a[i]+" ");

    }
   System.out.println("enter  index position");
   
   int  pos=ob.nextInt();

for(i=a.length-1;i>pos-1;i--)
{

     a[i]=a[i-1];

       }
      System.out.println("enter element you want to enter");
      int element=ob.nextInt();
           a[pos-1]=element;

     for(i=0;i<a.length;i++)
{
  System.out.print(a[i]+" ");

            }


           }
}