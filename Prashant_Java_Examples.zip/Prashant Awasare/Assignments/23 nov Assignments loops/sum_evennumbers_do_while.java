//Q8. Write a program to find sum of all even numbers between 1 to n.

class sum_evennumbers_do_while
{

  public static void main(String args[])
  {

    int i=1,even=0,sum=0;
     int  n=10;
do
{  
   if(i%2==0)
     
    
   sum=even+i;
    i++;
  
}while(i<=10);
System.out.println(sum);
}
}
      