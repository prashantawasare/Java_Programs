//Q6. Write a program to print all odd number between 1 to 100.
class oddnumber_while
{

  public static void main(String args[])
{
   int i=1;
    

 while(i<=100)
  {
    if(i%2!=0)
    System.out.print(" "+i);
    i++;
}

    
}
}
