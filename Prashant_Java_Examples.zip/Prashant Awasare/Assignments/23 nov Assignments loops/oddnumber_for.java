//Q6. Write a program to print all odd number between 1 to 100.
class oddnumber_for
{

  public static void main(String args[])
{
   int i=1;
    

for(i=1;i<=100;i++)
  {
    if(i%2!=0)
    System.out.print(" "+i);
    
} 

    
}
}
