//Q6. Write a program to print all odd number between 1 to 100.
class oddnumber_while_
{

  public static void main(String args[])
{
   int i=200;
    

 while(i<=300)
  {
    if(i%2!=0)
    System.out.print(" "+i);
    i++;
}

    
}
}
