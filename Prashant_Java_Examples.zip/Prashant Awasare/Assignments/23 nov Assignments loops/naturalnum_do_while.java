//Q4. Write a program to print all natural numbers in reverse (from n to 1).

class naturalnum_do_while
{

  public static void main(String args[])
{

   int i;
   int n=100;
       i=n;
do
{
System.out.print(i+" ");
    i--;
    
}while(i>=1);
  
}
}  