//Q3. Write a program to print all natural numbers from 1 to n. - using while loop

class naturalnum_for
{

  public static void main(String args[])
{

   int i=1;
    int n=100;
for(i=n;i>=1;i--)
{

  System.out.print(i+" ");
    
    
}
}
}  