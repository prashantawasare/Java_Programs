//Write a program to find sum of all odd natural numbers between 1 to n.
import java.util.Scanner;
class SumNatural_odd
{
  public static void main(String args[])
{
  Scanner sc=new Scanner(System.in);
  System.out.println("enetr no");
  int n=sc.nextInt();
  int sum=0;
  int i=1;
  while(i<=n)
  {   if(i%2!=0)
    sum=sum+i;
    i++; 
  }
  System.out.println("sum is"+sum);


}
}
