//Q8. Write a program to find sum of all even numbers between 1 to n.

class sum_evennumbers_for
{

  public static void main(String args[])
  {

    int i=1,even=0,sum=0;
     int  n=10;
for(i=1;i<=100;i++)
{  
   if(i%2==0)
     
    
   sum=even+i;
    
  
}
System.out.println(sum);
}
}
      