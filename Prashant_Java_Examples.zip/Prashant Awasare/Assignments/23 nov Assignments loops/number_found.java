class number_found 

{
  public static void main(String args[])
{
  int i=12345;
  
  int rem,k=5,r=0;
while(i!=0)
{
  rem=i%10;
  rem=k;
   r=76;

   break;

}

  if(r==76)

System.out.println("nummber  found");
else
System.out.println("number not found");


}

}