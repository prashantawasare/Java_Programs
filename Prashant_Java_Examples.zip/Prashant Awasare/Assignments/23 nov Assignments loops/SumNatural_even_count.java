//Q12.Wap take input first and last no and display all odd numbers between them and find sum and count. 

import java.util.Scanner;
class SumNatural_even_count
{
  public static void main(String args[])
{
  Scanner sc=new Scanner(System.in);
  System.out.println("enetr no");
  int n=sc.nextInt();
  int sum=0;
  int i=1;
  int c=0;
  while(i<=n)
  {   if(i%2==0)
     {
        
 System.out.print(i+" ");
  i++;
    sum=sum+i;
     c++;}
      
     
  }
   System.out.println("\ncount="+c);
  System.out.println("\nsum is"+sum);


}
}
