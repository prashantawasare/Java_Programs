//Q8. Write a program to find sum of all even numbers between 1 to n.

class sum_evennumbers
{

  public static void main(String args[])
  {

    int i=1,even=0,sum=0;
     int  n=100;
while(i<=100)
{

   if(i%2==0)
     
   even++;
   sum=sum+even;

}
System.out.println(sum);
}
}
      