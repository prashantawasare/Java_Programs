//Q11.Wap enter your name and print it five times.

class name_for
{

public static void main(String args[])
{

   int a=0;
for(a=0;a<=5;a++)
{
  System.out.println("prashant");
  
}
}
}