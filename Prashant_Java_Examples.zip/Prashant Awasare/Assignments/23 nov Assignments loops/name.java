//Q11.Wap enter your name and print it five times.
class name
{

public static void main(String args[])
{

   int a=0;
while(a<=5)
{
  System.out.println("prashant");
  a++;
}
}
}