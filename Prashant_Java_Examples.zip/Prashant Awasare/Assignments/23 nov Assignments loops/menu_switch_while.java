//Q14..WAP to add multiple  number, ask user to take  input as their need. 
   //press 0 to terminate inputting after that calculate sum of that inputted number.

import java.util.*;
  class menu_switch_while
  {
   public static void main(String []args)
     {
   Scanner x = new Scanner(System.in);
   int ch,i;
   double num1,num2;	
   System.out.println("\n1.ADD\n2.SUB\n3.Multiply\n4.Divide");
   
  i=1;
while(i!=0)
{

   System.out.println("Enter your choice");
   ch=x.nextInt();
   
   switch(ch)
   {
    case 1:
       { System.out.println("Addition");
       System.out.println("Enter Two Number = ");
        num1=x.nextDouble();
        num2=x.nextDouble();
       System.out.println("Additition of num1+num2 = " +(num1+num2)); }
    break;
   
   case 2:
     { System.out.println("Substraction");
      System.out.println("Enter Two Number = ");
      num1=x.nextDouble();
      num2=x.nextDouble();
      System.out.println("Substraction of num1-num2 = " +(num1-num2));}
   break;
   case 3:
     { System.out.println("Multiplication");
      System.out.println("Enter Two Number = ");
      num1=x.nextDouble();
      num2=x.nextDouble();
      System.out.println("Multiplication of num1*num2 = " +(num1*num2));}
  break;
   case 4:
     { System.out.println("Division");
      System.out.println("Enter Two Number = ");
      num1=x.nextDouble();
      num2=x.nextDouble();
      System.out.println("Division of num1/num2 = " +(num1/num2)); }
   break;
  default:
    System.out.println("Wrong Input");
  }   System.out.println("Enter 0 To terminate and 1 to continue=");
   i=x.nextInt();   

   }//while
  
  }
  }
