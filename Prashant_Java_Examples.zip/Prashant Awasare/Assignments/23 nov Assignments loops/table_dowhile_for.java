//Q.15 Wap to take input a no and print table
class table_dowhile_for
{

  public static void main(String args[])
{
  int i=1,c=2;
for(i=1;i<=10;i++)
{
  System.out.println(" "+i*c);
  
}

}

}