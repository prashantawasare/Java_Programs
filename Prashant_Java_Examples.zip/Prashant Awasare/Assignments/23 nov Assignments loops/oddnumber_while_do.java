//Q10. Write a program to print all odd number between 200 to 300.
class oddnumber_while_do
{

  public static void main(String args[])
{
   int i=200;
    

 do
  {
    if(i%2!=0)
    System.out.print(" "+i);
    i++;
} while(i<=300);

    
}
}
