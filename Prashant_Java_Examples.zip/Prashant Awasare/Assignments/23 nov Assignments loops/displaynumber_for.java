//Q.1 Using for loop display numbers from 1 to 100.

class displaynumber_for
{
   public static void  main(String args[])
{

  int i;
for(i=1;i<=100;i++)      
{
   System.out.print(i+" ");
     
}


}
}
