
//Q3. Write a program to print all natural numbers from 1 to n. - using while loop

class naturalnumbers_
{

  public static void main(String args[])
{

   int i=1;
    int n=100;
while(i<=n)
{

    
}
  System.out.print(i+" ");
    i++;
}
}  