//Q10. Write a program to print all odd number between 200 to 300.
class oddnumber_while_
{

  public static void main(String args[])
{
   int i=200;
    

 while(i<=300)
  {
    if(i%2!=0)
    System.out.print(" "+i);
    i++;
}

    
}
}
