//Q11.Wap enter your name and print it five times.

class name_do_while
{

public static void main(String args[])
{

   int a=0;
do
{
  System.out.println("prashant");
  a++;
}while(a<=5);
}
}