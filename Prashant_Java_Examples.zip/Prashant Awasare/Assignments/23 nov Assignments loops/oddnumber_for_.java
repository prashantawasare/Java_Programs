//Q10. Write a program to print all odd number between 200 to 300.
class oddnumber_for_f
{

  public static void main(String args[])
{
   int i=200;
    

 for(i=200;i<=300;i++)
  {
    if(i%2!=0)
    System.out.print(" "+i);
    
} 

    
}
}
