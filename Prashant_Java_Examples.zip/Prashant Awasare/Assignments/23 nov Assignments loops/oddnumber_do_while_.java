//Q6. Write a program to print all odd number between 1 to 100.
class oddnumber_do_while_
{

  public static void main(String args[])
{
   int i=1;
    

do
  {
    if(i%2!=0)
    System.out.print(" "+i);
    i++;
} while(i<=100)

    
}
}
