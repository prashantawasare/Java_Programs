//Q15.Wap to take input a no and print table.


class table
{

  public static void main(String args[])
{
  int i=1,c=2;
while(i<=10)
{
  System.out.println(" "+i*c);
  i++;
}

}

}