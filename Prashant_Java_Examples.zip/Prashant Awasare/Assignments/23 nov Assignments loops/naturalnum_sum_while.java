//Q.7. Write a program to find sum of all natural numbers between 1 to n.
class naturalnum_sum_while
{

  public static void main(String args[])
{

   int i=1,sum=0;
   int n=100;
       
while(i<=100)
{   sum=sum+i;

    
}System.out.print(sum);
    i++;
  
}
}  