//Q.15 Wap to take input a no and print table
class table_dowhile
{

  public static void main(String args[])
{
  int i=1,c=2;
do
{
  System.out.println(" "+i*c);
  i++;
}while(i<=10);

}

}