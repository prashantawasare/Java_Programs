/*Q6.

A B C D E
A B C D
A B C
A B
A*/





class question6
{
   public static void main(String arf[])
 {  int row,col;
    int a=64;
  for(row=5;row>=1;row--)
  {
     for(col=1;col<=row;col++)
   System.out.print ((char)(col+a)+" ");

         
      System.out.println();


        }

       }
}