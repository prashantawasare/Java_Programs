/*Q4.
A A A A A
B B B B
C C C
D D
E*/



class question4
{
   public static void main(String arf[])
 {  int row,col;
    int a=64;
  for(row=1;row<=5;row++)
  {
     for(col=5;col>=row;col--)
   System.out.print ((char)(row+a)+" ");

         
      System.out.println();


        }

       }

   }