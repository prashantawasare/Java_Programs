/*Q8.

E F G H I
D E F G
C D E
B C
A*/




class question8
{
   public static void main(String arf[])
 {  
    
    int row,col;
     int count;
     int a=64;
  for(row=5;row>=1;row--)
  {        count=row;
     for(col=1;col<=row;col++,count++)
    {       
   System.out.print((char)(count+a)+" ");
              
               }
  

         
      System.out.println();

        }

       }

   }