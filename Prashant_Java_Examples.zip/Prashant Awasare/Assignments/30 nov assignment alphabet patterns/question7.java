/*Q7.

A
B A
C B A
D C B A
E D C B A*/








class question7
{
   public static void main(String arf[])
 {  int row,col;
    int a=64;
  for(row=1;row<=5;row++)
  {
     for(col=row;col>=1;col--)
   System.out.print ((char)(col+a)+" ");

         
      System.out.println();


        }

       }
}