/*Q10.
A B C D E
B C D E
C D E
D E
E*/




class question10
{
   public static void main(String arf[])
 {  int row,col;
    int a=64;
  for(row=1;row<=5;row++)
  {
     for(col=row;col<=5;col++)
   System.out.print ((char)(col+a)+" ");

         
      System.out.println();


        }

       }
}