/*Q.3
E
D D
C C C
B B B B
A A A A A*/




class question3
{
   public static void main(String arf[])
 {  int row,col;
    int a=64;
  for(row=5;row>=1;row--)
  {
     for(col=5;col>=row;col--)
   System.out.print ((char)(row+a)+" ");

         
      System.out.println();


        }

       }

   }