
/*Q.9
E D C B A
D C B A
C B A
B A
A*/




class question9
{
   public static void main(String arf[])
 {  int row,col;
    int a=64;
  for(row=5;row>=1;row--)
  {
     for(col=row;col>=1;col--)
   System.out.print ((char)(col+a)+" ");

         
      System.out.println();


        }

       }
}