/*Q1.
A
B B
C C C
D D D D
E E E E E*/




class question
{
   public static void main(String arf[])
 {  int row,col;
    int a=64;
  for(row=1;row<=5;row++)
  {
     for(col=1;col<=row;col++)
   System.out.print ((char)(row+a)+" ");

         
      System.out.println();


        }

       }

   }