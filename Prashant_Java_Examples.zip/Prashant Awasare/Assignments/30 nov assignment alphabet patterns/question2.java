/*Q.2
E E E E E
D D D D
C C C
B B
A*/



class question2
{
   public static void main(String arf[])
 {  int row,col;
    int a=64;
  for(row=5;row>=1;row--)
  {
     for(col=1;col<=row;col++)
   System.out.print ((char)(row+a)+" ");

         
      System.out.println();


        }

       }

   }