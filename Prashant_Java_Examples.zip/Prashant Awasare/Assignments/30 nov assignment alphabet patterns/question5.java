/*Q5.

A
A B
A B C
A B C D
A B C D E*/







class question5
{
   public static void main(String arf[])
 {  int row,col;
    int a=64;
  for(row=1;row<=5;row++)
  {
     for(col=1;col<=row;col++)
   System.out.print ((char)(col+a)+" ");

         
      System.out.println();


        }

       }
}