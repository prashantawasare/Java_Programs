import java.util.*;
import java.util.Random;
  class GameDesigns
{
    public static  void main(String args[])
{



     
   //System.out.println("0.Stone");
   //System.out.println("1.Scissor");
   //System.out.println("2.Paper");




    
   Scanner ob=new Scanner(System.in);
    int yourchoise=ob.nextInt();

    Random re=new Random();
    int computerchoice=re.nextInt(3);

 
    
    if(computerchoice==0 && yourchoise==1 || computerchoice==1 && yourchoise==2 ||computerchoice==2 && yourchoise==1)
    System.out.println("You win"); 
   

   }
}
