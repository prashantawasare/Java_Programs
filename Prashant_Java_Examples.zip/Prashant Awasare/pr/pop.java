class  pop
{
   public static  void main(String args[])
{
  int i,j;
   for(i=1;i<=9;i++)
{


    for(j=i;j<=9;j++)
    System.out.print(" ");
    for(j=1;j<=i;j++)
    
    
    


 
   if(i==9  || j==i || j==1 && j!=0)
   System.out.print(" ");
  

  System.out.println();
}

}

}