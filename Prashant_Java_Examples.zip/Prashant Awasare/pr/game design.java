import java.util.Scanner;
import java.util.Random;
class  gamedesign
{
  public static void main(String args[])
{
   Scanner ob=new Scanner(System.in);


    System.out.println("0.stone\n1.Scissor\n2.paper");
  System.out.println("enter your choice");
 int your_choice=ob.nextInt();


  Random re=new Random(3);

 int computer_choice=ob.nextInt();




  if(computer_choice==your_choice)
{ System.out.println("Match draw");}

   else if(your_choice==0 && computer_choice==1)
   { System.out.println("you win");
     System.out.println("stone break the scissor");}

   else if(your_choice==1 && computer_choice==2)
   { System.out.println("you win");
     System.out.println("scissor cut the paper");}

else if(your_choice==2 && computer_choice==0)
   { System.out.println("you win");
     System.out.println("paper cover the stone");}


   }

}